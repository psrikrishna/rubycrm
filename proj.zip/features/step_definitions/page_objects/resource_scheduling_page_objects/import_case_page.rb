#Import file navigates through all the steps required to import a file and checks for various stages before finally validating imported records.
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class ImportFile < SitePrism::Page

	element :uploadFileName, '#uploadFileNameId'
	element :nextButton, '#wizardFormFooter #buttonNext'
	element :submitButton, '#wizardFormFooter #buttonNext'
	element :finishButton, 'button[accesskey="F"]'
	element :cancelButton, 'button[title*="Cancel the wizard."]'
	element :dataMap, '#crmDataSource > optgroup:nth-child(4) > option:nth-child(9)'
	element :mapRecordTypes, '#file_1 option[value="caaci_qpulseaudit"]'

	#verify map fields
	element :approvalStatus, "#_Attribute_11 option[value='caaci_qpulseapprovalstatus'][selected='selected']"
	element :audType, "#_Attribute_5 option[value='3-Ignore'][selected='selected']"
	element :auditNote, "#_Attribute_6 option[value='caaci_summary'][selected='selected']"
	element :auditStatus, "#_Attribute_4 option[value='caaci_auditstatus'][selected='selected']"
	element :crmCategory, "#_Attribute_2 option[value='caaci_audtypeshort'][selected='selected']"
	element :crmSubCategory, "#_Attribute_1 option[value='new_qsubcategory'][selected='selected']"
	element :leadAuditor, "#_Attribute_7 option[value='caaci_leadauditor'][selected='selected']"
	element :number, "#_Attribute_8 option[value='caaci_number'][selected='selected']"
	element :organisationName, "#_Attribute_10 option[value='caaci_organisationname'][selected='selected']"
	element :referenceNumber, "#_Attribute_13 option[value='caaci_referencenumber'][selected='selected']"
	element :scheduledStartDate, "#_Attribute_12 option[value='caaci_scheduledstartdate'][selected='selected']"
	element :scheduledEndDate, "#_Attribute_3 option[value='new_schedulingenddate'][selected='selected']"
	element :schedulingOfficer, "#_Attribute_9 option[value='caaci_schedullingofficer'][selected='selected']"
	element :infoBalloonText, "#infoBalloonText1"
	element :loadingIcon, "#DialogLoadingDiv"
	element :importLink, "#showImportStatusLink"


element :statusOnMyImports, "#gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(3)"
element :refreshGrid, "#grid_refresh"

#Checks for page to be loaded before performing other actions
def checkPageLoadComplete
	wait_until_loadingIcon_invisible(10)
end

#Uploads a file
	def select_a_file
		wait_for_uploadFileName(10)
		attach_file('uploadFileNameId', File.absolute_path('./Files/RS Phase 3 Data Migration Test.csv'))
		wait_for_ajax
	end

#Clicks next button
	def click_next_button
		wait_for_nextButton(10)
		nextButton.click
		wait_for_ajax
	end

#Clicks Cancel button
	def click_cancel_button
		wait_for_cancelButton(10)
		cancelButton.click
		wait_for_ajax
	end

#Clicks Submit button
	def click_submit_button
		wait_for_submitButton(10)
		submitButton.click
		wait_for_ajax
	end

#Select Monthly Q Pulse option
	def select_monthly_q_pulse_audits
		wait_for_dataMap(10)
		dataMap.click
		wait_for_ajax
	end

#Select  Q Pulse Audit option
	def select_record_types_as_q_pulse_audit
		wait_for_mapRecordTypes(10)
		mapRecordTypes.click
		wait_for_ajax
	end



#Verify the approval status is mapped correctly
def verifyApprovalStatusMapping
	sleep 3
	wait_for_ajax
	wait_for_approvalStatus(10)
		approvalStatus['title']
end

#Returns title attribute of Audit Type
def verifyAuditTypeMapping
		audType['title']
end
#Returns title attribute of Audit Note
def verifyAuditNoteMapping
		auditNote['title']
end
#Returns title attribute of Audit Status
def verifyAuditStatus
	 auditStatus['title']
end
#Returns title attribute of Category
def verifyCrmCategory
	crmCategory['title']
end
#Returns title attribute of subCategory
def verifyCrmSubCategory
	crmSubCategory['title']
end
#Returns title attribute of Lead Auditor
def verifyLeadAuditor
	leadAuditor['title']
end
#Returns title attribute of Number field
def verifyNumber
	number['title']
end
#Returns title attribute of Organiation name
def verifyOrganisationName
	organisationName['title']
end
#Returns title attribute of Reference number
def verifyReferenceNumber
	referenceNumber['title']
end
#Returns title attribute of Scheduled start date
def verifyScheduledStartDate
	scheduledStartDate['title']
end
#Returns title attribute of Scheduled end date
def verifyScheduledEndDate
scheduledEndDate['title']
end
#Returns title attribute of Scheduling Officer
def verifySchedulingOfficer
	schedulingOfficer['title']
end
#Returns text of status
def verifyStatusOfImport
	statusOnMyImports.text
end
#Returns text of information balloon
def getInfoBallooonText
	wait_for_ajax
	infoBalloonText.text
end

#Refershes the grid after import process until Complete status is displayed
def refresh_grid_until_file_import_status_is_complete(status)
 time=0

			while time<360 do
				puts "Current status is -> "+verifyStatusOfImport
				 	 if verifyStatusOfImport==status
					 	return true
				 	 end
					 wait_for_refreshGrid(10)
					 refreshGrid.click

						wait_for_ajax
						time=time+10
			end
			return false
	end


end #of class

#IFrame under Import dialog
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class ImportIFrame < SitePrism::Page
  iframe :importIFrame, ImportFile, '#contentIFrame0'
end

#Embedded IFrame under Import dialog
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class DialogIFrame < SitePrism::Page
	iframe :dialogIFrame, ImportFile, "#InlineDialog_Iframe"
end

#Embedded IFrame under Import dialog
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class WizardIFrame < SitePrism::Page
  iframe :wizardIFrame, ImportFile, '#wizardpageframe'
end

#Embedded IFrame for uploading a file under Import dialog
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class UploadFileFrame < SitePrism::Page
  iframe :uploadFileFrame, ImportFile, '#uploadFileFrame'
end
