
#Popup window that deals with creating service activity after a case is added, rescheduled or cancelled.
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class ServiceActivity < SitePrism::Page

  element :subjectInputDiv, "#subject_container"
  element :subjectInput, "#subject_container > input"
  element :saveIcon, :xpath, "//*[@id='serviceappointment|NoRelationship|Form|Mscrm.Form.serviceappointment.Save-Large']"
  element :closeServiceActivity, :xpath, '//*[@id="serviceappointment|NoRelationship|Form|Mscrm.Form.serviceappointment.Close-Large"]'
  element :serviceInputDiv, :xpath, "//*[@id='serviceid_lookupTable']/tbody/tr/td[1]/div"
  element :serviceInput, '#serviceid_ledit'
  element :start_time_label, '#scheduledstart >tbody'
  element :start_time_input, '#scheduledstart #DateInput'
  element :end_time_label, '#scheduledend > tbody > tr > td.DateTimeUI_RenderDateControl_td.ms-crm-Input-Container > label'
  element :end_time_input, '#scheduledend_d #DateInput'
  element :allDayRadioLabel, '#isalldayevent_c > label'
  element :rebookedDropdown, '#caaci_rebookedreason'
  element :prepPostButton, :xpath, '//*[@id="serviceappointment|NoRelationship|Form|caaci.serviceappointment.ButtonAddPrepAndPost.Button-Large"]'

  element :scheduleAlertSaveButton, "#btnSave"
  element :cancelledSelectReason, "#statusCode"
  element :innerIframeCloseButton, "#butBegin"

  element :disabledPrepPostButton, 'li[id="serviceappointment|NoRelationship|Form|Mscrm.Form.serviceappointment.MainTab.Actions"]  a[class="ms-cui-ctl-large ms-cui-disabled"]'
  element :disabledSaveButton, 'a[class="ms-cui-ctl-large ms-cui-disabled"]:nth-child(1)'

  element :scheduledStartDate, "#scheduledstart_d #DateInput"
  element :scheduledEndDate, "#scheduledend_d #DateInput"
  element :allDayEvent, "#isalldayevent_d input"


  #validations

element :subjectValue, "#subject"
element :serviceValue, "#serviceid_lookupTable"
element :customerValue, "#customers_lookupTable"
element :resourcesValue, "#resources_lookupTable"
element :startDateValue, "#scheduledstart #DateInput"
element :startTimeValue, "#scheduledstartTimeInput"
element :endDateValue, "#scheduledend #DateInput"
element :endTimeValue, "#scheduledendTimeInput"
element :durationValue, "#scheduleddurationminutesSelectInput"
element :contactValue, "table[style*='visible'] input[id*='caaci_meetingorganisedthroughtextdesc']"#These locators end with 2, 4 and 6 depending on workflow; so using id*
element :emailValue, "table[style*='visible'] input[id*='caaci_meetingorganisedthroughemail']"
element :phoneValue, "table[style*='visible'] input[id*='caaci_meetingorganisedthroughphone']"
element :personalRefValue, "#caaci_caapersonalref"
element :jobNumberValue, "#caaci_jobnumber"
element :locationValue, "input[id*='location']"
element :inspectionTypeValue, "#caaci_fotiinspectiontype"
element :aircraftTypeValue, "table[style*='visible'] input[id*='caaci_aircrafttypetextdesc']"
element :categoryValue, "#category"
element :subCategoryValue, "#subcategory"
element :registrationValue, "table[style*='visible'] input[id*='caaci_approvalnumber']"

#disabled elements for cancelled scenarios

element :serviceDisabled, "#serviceid_lookupTable > tbody > tr > td:nth-child(1) > div > ul > li > span"
element :customerDisabled, "#customers_lookupTable > tbody > tr > td:nth-child(1) > div > ul > li > span"
element :resourceseDisabled, "#resources_lookupTable > tbody > tr > td:nth-child(1) > div > ul > li > span"

#Checks whether following UI elements are disabled upon cancellation:
#service, customer, resources, subject, end date, start date,
#contact, email, phone, location, category, subCategory, aircraft type and registration
def check_ui_elements_are_disabled

      return serviceDisabled['contenteditable']=="false" &&
    customerDisabled['contenteditable']=="false" &&
    resourceseDisabled['contenteditable'] =="false" &&
    subjectValue['contenteditable'] =="false" &&
    startDateValue['contenteditable'] =="false" &&
    endDateValue['contenteditable'] =="false" &&
    contactValue['contenteditable'] =="false" &&
    emailValue['contenteditable'] =="false" &&
    phoneValue['contenteditable'] =="false" &&
    locationValue['contenteditable'] =="false" &&
    categoryValue['contenteditable'] =="false" &&
    subCategoryValue['contenteditable'] =="false" &&
    aircraftTypeValue['contenteditable'] =="false" &&
    registrationValue['contenteditable'] =="false"

end

#Checks whether following UI elements are disabled specifically for unannounced scenario upon cancellation:
#service, customer, resources, subject, end date, start date,
#contact, email, phone, location, category, subCategory
def check_ui_elements_are_disabled_for_unannounced

      return serviceDisabled['contenteditable']=="false" &&
    customerDisabled['contenteditable']=="false" &&
    resourceseDisabled['contenteditable'] =="false" &&
    subjectValue['contenteditable'] =="false" &&
    startDateValue['contenteditable'] =="false" &&
    endDateValue['contenteditable'] =="false" &&
    contactValue['contenteditable'] =="false" &&
    emailValue['contenteditable'] =="false" &&
    phoneValue['contenteditable'] =="false" &&
    locationValue['contenteditable'] =="false" &&
    categoryValue['contenteditable'] =="false" &&
    subCategoryValue['contenteditable'] =="false"

end

#Checks whether following UI elements are disabled specifically for FOTI scenario upon cancellation:
#service, customer, resources, subject, end date, start date,
#contact, email, phone, location, category, subCategory, personal reference, job number, aircraft type
def check_ui_elements_are_disabled_for_foti
        return serviceDisabled['contenteditable']=="false" &&
      customerDisabled['contenteditable']=="false" &&
      resourceseDisabled['contenteditable'] =="false" &&
      subjectValue['contenteditable'] =="false" &&
      startDateValue['contenteditable'] =="false" &&
      endDateValue['contenteditable'] =="false" &&
      contactValue['contenteditable'] =="false" &&
      emailValue['contenteditable'] =="false" &&
      phoneValue['contenteditable'] =="false" &&
      locationValue['contenteditable'] =="false" &&
      categoryValue['contenteditable'] =="false" &&
      subCategoryValue['contenteditable'] =="false" &&
      personalRefValue['contenteditable'] =="false" &&
      jobNumberValue['contenteditable'] =="false" &&
      aircraftTypeValue['contenteditable'] =="false"
end

#Checks whether fields metioned in the parameters are populated
  def check_all_relevant_fields_prepopulated_for_foti(subject, customer, resource, startDate, endDate,contact, email, phone,
    personalRef, jobNumber, location, aircraftType, category, subCategory)

      wait_for_ajax

      return subjectValue.value==subject && customerValue.text==customer &&
        resourcesValue.text ==resource &&  startDateValue.value ==startDate &&
        endDateValue.value == endDate &&  contactValue.value == contact &&
          emailValue.value ==email &&  phoneValue.value == phone &&
          personalRefValue.value ==personalRef &&  jobNumberValue.value == jobNumber &&
          locationValue.value == location && aircraftTypeValue.value == aircraftType &&
          categoryValue.value == category &&  subCategoryValue.value ==subCategory

  end

#Checks whether fields metioned in the parameters come pre-populated
  def check_all_relevant_fields_prepopulated(subject, customer, resource, startDate, endDate, contact, email, phone,
    aircarftType, registration, location, category, subCategory)

    return subjectValue.value==title && customerValue.text==customerID &&
      resourcesValue.text ==surveyor &&  startDateValue.value ==startDate &&
      endDateValue.value == endDate &&  contactValue.value == contact &&
        emailValue.value ==email &&  phoneValue.value == phone &&
        registrationValue.value==registration &&
        locationValue.value == location && aircraftTypeValue.value == aircraftType &&
        categoryValue.value == category &&  subCategoryValue.value ==subCategory

end

#Clicks Save icon in service activity
  def click_save_icon
    wait_for_ajax
    wait_for_saveIcon(10)
    saveIcon.click
  end

#Clicks Close icon in service activity
  def click_close_service_activity_icon
    wait_for_ajax
    wait_for_closeServiceActivity(10)
    closeServiceActivity.click
  end

#Activates the subject field
  def click_subject_input
    subjectInputDiv.click
    subjectInput.click
  end

#Completes Service field dropdown
  def fill_service_input(serviceText)
     wait_for_serviceInputDiv(10)
     serviceInputDiv.click
     wait_for_serviceInput

    wait_for_ajax
    serviceInput.set serviceText
    wait_for_ajax

    page.driver.browser.action.send_keys(:return).perform
    wait_for_ajax

    page.driver.browser.action.send_keys(:return).perform
    wait_for_ajax

  end

#enter modified start and end dates
  def modify_start_end_date(modifiedStartDate, modifiedEndDate)

      scheduledStartDate.send_keys [:control, 'a']
      scheduledStartDate.set modifiedStartDate
      wait_for_ajax

      scheduledEndDate.send_keys [:control, 'a']
      scheduledEndDate.set modifiedEndDate
      wait_for_ajax

      allDayEvent.click
      wait_for_ajax

  end

#Check the All day checkbox
  def click_all_day_button
    wait_for_ajax
    wait_for_allDayRadioLabel(10)
    allDayRadioLabel.click
  end

#Clicks Prep and Post icon in service activity
  def click_prep_post_button
    wait_for_ajax
    wait_for_prepPostButton(10)
    prepPostButton.click
    wait_for_ajax
  end

#Select reason for rebooking - reason passed from feature file as parameter to this method
  def choose_rebooked_reason(reason)
    wait_for_ajax
    wait_for_rebookedDropdown(10)
    rebookedDropdown.select(reason)
  end

#Select reason for cancelling - reason passed from feature file as parameter to this method
  def choose_cancelled_reason(reason)
    wait_for_ajax
    wait_for_cancelledSelectReason(10)
    cancelledSelectReason.select(reason)
  end

#Clicks Close button in inner frame
  def click_inner_frame_close_button
    wait_for_ajax
    wait_for_innerIframeCloseButton(10)
    innerIframeCloseButton.click
  end

#Checks if field is populated
  def has_secret_value?(value)
    start_time_input.value == value
  end


end

#IFrame under the Service Activity page
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class IFrameServiceActivity < SitePrism::Page
  iframe :iFrame, ServiceActivity, "div > #contentIFrame"
end

#Embedded IFrame under the Service Activity page
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class InnerServiceIFrame < SitePrism::Page
  iframe :serviceIFrame, ServiceActivity, "InlineDialog_Iframe"
end
