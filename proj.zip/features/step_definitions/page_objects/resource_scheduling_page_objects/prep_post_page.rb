#Part of Service Activity creation
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class PrepPost < SitePrism::Page

  #Main elements

  element :createServiceActivityButton, '#buttonCreatePreAndPostServiceActvities'

  #Prep service elements

  element :prep_subject_input, '#divPrepServiceContainer #textPreServiceSubject'
  element :prep_schedule_input, '#divPrepServiceContainer #textSAPreScheduleOnDate'
  element :prep_time_input, '#divPrepServiceContainer #textSAPreScheduleOnTime'
  element :prep_service_duration, '#divPrepServiceContainer #selectSAPreScheduleDuration'
  element :prep_desired_resources_check, '#divParentServiceResourcesContainerPrepInner > label > input[type="checkbox"]'

  #Post service elements

  element :post_subject_input, '#divPostServiceContainer #textPostServiceSubject'
  element :post_schedule_input, '#divPostServiceContainer #textSAPostScheduleOnDate'
  element :post_time_input, '#divPostServiceContainer #textSAPostScheduleOnTime'
  element :post_service_duration, '#divPostServiceContainer #selectSAPostScheduleDuration'
  element :post_desired_resources_check, '#divParentServiceResourcesContainerPostInner > label > input[type="checkbox"]'

#Clicks Create Service Activity button
  def click_create_service_button
    wait_for_createServiceActivityButton(10)
    createServiceActivityButton.click
  end

end
