#Individual is required to be created for certain scenarios in EPT and Resource Scheduling projects
# Project:: Resource Scheduling and EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class Individual < SitePrism::Page

element :newContact, "span[command*='NewRecordFromGrid']"
element :fullNameLabel, "#fullname_c"

element :firstNameLabel, "#fullname_compositionLinkControl_firstname_c"
element :surNameLabel, "#fullname_compositionLinkControl_lastname_c"

element :firstName, "#fullname_compositionLinkControl_firstname_i"
element :surName, "#fullname_compositionLinkControl_lastname_i"

element :doneButton, "#fullname_compositionLinkControl_flyoutLoadingArea-confirm"

element :saveAndClose, "span[command*='SaveAndClosePrimary']"

element :search, "#crmGrid_findCriteria"

elements :searchResults, "a[id*='gridBodyTable_primaryField']"

element :enteredName, "#fullname > div.ms-crm-Inline-Value > span"

#Search for individual based on firstname and lastname supplied in parameters
    def search_for_individual(firstname, surname)
        search.set firstname + ' ' + surname
        page.driver.browser.action.send_keys(:return).perform
        wait_for_ajax
        searchResults[0].click
        wait_for_ajax
    end


#Returns entered name for validation
    def getEnterdName
        enteredName.text
    end


#Adds new individual
    def add_new_individual
        wait_for_ajax
        wait_for_newContact(10)
        newContact.click
        wait_for_ajax
    end

#Sets individual to firstname and lastname supplied in parameters
    def set_name(first_name, surname)
      wait_for_ajax
      fullNameLabel.click
      wait_for_ajax

      wait_for_firstName
      firstNameLabel.click
      firstName.set first_name
      surNameLabel.click
      surName.set surname

      doneButton.click

      wait_for_ajax


    end

#Clicks Save and close in the popup window
    def click_save_and_close
        saveAndClose.click
    end

end

#IFrame under the Individual page
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class IndividualIFrame < SitePrism::Page
  iframe :individualIFrame, Individual, '#contentIFrame1'
end

#embedded IFrame under the Individual page
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class IndividualSubContentIFrame < SitePrism::Page
  iframe :individualSubContentIFrame, Individual, '#contentIFrame0'
end
