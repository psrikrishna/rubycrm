# The Active Assessment Privileges table is  populated with the Air Operator Certificate and SMS privileges after creating a Safety Review.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AirOperatorCertificate  < SitePrism::Page

element :addChange, "#caa_safetyassessmentcomments_subgrid_addImageButton"
element :linkToSafetyReview, "#caa_safetyassessmentid > div.ms-crm-Inline-Value.ms-crm-Inline-Locked.ms-crm-Inline-Lookup > span.ms-crm-Lookup-Item"

element :complexityRatingLabel, "#caa_complexityrating_c"
element :complexityRating, "select[id='caa_complexityrating_i']"

element :riskFocusLabel, "#caa_riskfocus_c >span >span"
element :riskFocus, "#caa_riskfocus_i"

element :futureOversightLabel, "#caa_futureoversight_c"
element :futureOversight, "select[id='caa_futureoversight_i']"

element :futureOversightRationaleLabel, "#caa_futureoversightrationale_c > span > span"
element :futureOversightRationale, "#caa_futureoversightrationale_c"

element :dateOfEntryLabel, "#caa_date_c"
element :dateOfEntry, "#caa_date"

element :confirmedFutureOversightLabel, "#caa_confirmedfutureoversight_c"
element :confirmedFutureOversight, "select[id='caa_confirmedfutureoversight_i']"

element :approvalCommentsLabel, "#caa_approvalcomments_c>span>span"
element :approvalComments, "#caa_approvalcomments_i"

element :approvalDateLabel, "#caa_approvaldate_c"
element :approvalDate, "#caa_approvaldate"

element :sectorManagerLabel, "#caa_sectormanager_c"
element :sectorManager, "#caa_sectormanager_ledit"

element :saveInFooter, "#savefooter_statuscontrol"

element :entriesInChangesTable, "#caa_safetyassessmentcomments_subgrid_divDataArea table"

element :guidanceNotesLinkForComplexityOversightBaselineAerodromes, "#GuidanceNotes_divDataArea a[title*='Complexity Oversight Baseline - Aerodromes']"
element :guidanceNotesNextPage, "#GuidanceNotes a[title='Load Next Page']"
element :guidanceNotesPreviousPage, "#GuidanceNotes a[title='Load Previous Page']"

#Navigates to next page
def navigate_next_page
    wait_for_ajax
    guidanceNotesNextPage.click
    wait_for_ajax

end

#Navigates to previous page
def navigate_previous_page
    wait_for_ajax
    guidanceNotesPreviousPage.click
    wait_for_ajax
end


#Opens guidance notes
def open_guidance_notes(guidance_notes)
    guidanceNotesLinkForComplexityOversightBaselineAerodromes.click
    wait_for_ajax

end


#Returns number of records in Changes table
def number_of_entries_in_changes_table
      entriesInChangesTable['numrecords'].to_i
end


#Returns to Safety Review page
def click_link_to_safety_review
    linkToSafetyReview.click
    wait_for_ajax
end

#Clicks to add Change
def click_add_change
    addChange.click
    wait_for_ajax
  end

#Creates the Air Operator Certificate fields
  def add_aoc_fields(complexity_rating, proposed_future_oversight,
    proposed_future_oversight_rationale,date_of_entry,confirmed_future_oversight,
  approval_comments,approval_date, sector_manager )

  complexityRatingLabel.click
    wait_for_ajax
    complexityRating.select(complexity_rating)


    futureOversightLabel.click
    wait_for_ajax
    futureOversight.select(proposed_future_oversight)

    futureOversightRationaleLabel.click
    futureOversightRationale.set proposed_future_oversight_rationale

    dateOfEntryLabel.click
    dateOfEntry.set getTodayDate()

    confirmedFutureOversightLabel.click
    wait_for_ajax
    confirmedFutureOversight.select(confirmed_future_oversight)

    approvalCommentsLabel.click
    approvalComments.set approval_comments

    approvalDateLabel.click
    approvalDate.set getTodayDate()

    sectorManagerLabel.click
    wait_for_ajax

      if (has_sectorManager?)
            sectorManager.set sector_manager
            wait_for_ajax
            page.driver.browser.action.send_keys(:tab).perform
            wait_for_ajax
      end

  end

#Clicks the Save icon at bottom right of screen
  def click_save_in_footer
    saveInFooter.click
    wait_for_ajax
    wait_until_saveInFooter_visible
  end


#Returns today's date
  def getTodayDate
    require 'Date'
    today = DateTime.now
    today.strftime("%d/%m/%Y")
  end


end

#IFrame within Air Operator Certificate page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AirOperatorCertificateIFrame < SitePrism::Page
  iframe :airOperatorCertificateIFrame, AirOperatorCertificate, '#contentIFrame0'
end
