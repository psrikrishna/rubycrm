#Base entity for members to be added to Key Personnel
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class Oversight < SitePrism::Page


element :systemUser,"#caa_systemuserid_ledit"
element :systemUserLabel, "#caa_systemuserid_c"

element :systemRole, "#caa_roleid_ledit"
element :systemRoleLabel, "#caa_roleid_c"

element :saveAndClose, "li[id*='SaveAndClose']"

#Creates a new oversight team member
def complete_fields_to_add_oversight_member(user, role)
  wait_for_ajax
  wait_for_systemUserLabel(10)
systemUserLabel.click
wait_for_ajax
systemUser.set user
systemRoleLabel.click
wait_for_ajax
systemRole.set role
wait_for_ajax
  page.driver.browser.action.send_keys(:tab).perform
  wait_for_ajax

end

#Saves and closes popup window
def click_save_and_close
  saveAndClose.click
  wait_for_ajax
end


end

#IFrame under Oversight team member page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class OversightContentIFrame < SitePrism::Page
  iframe :oversightContentIFrame, Oversight, '#contentIFrame0'
end
