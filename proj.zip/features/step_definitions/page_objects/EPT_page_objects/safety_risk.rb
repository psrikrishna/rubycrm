#Add a new Safety Risk to the Active Safety Review of an Aviation Entity in EPT CRM
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyRisk < SitePrism::Page

  element :saveButton, 'li[title*="Save this"] > span > a'
  element :newButton, 'li[title*="New"] > span > a'
  element :aviationEntityTitle, '#caa_aviationentityid div[jawsreadlabel="caa_aviationentityid_c"] span[otypename="caa_aviationentity"]'
  element :deactivateButton, 'li[title*="Deactivate"] > span > a'

  element :titleLabel, "#caa_title_c > span > span"
  element :titleInput, "#caa_title_i"

  element :originLabel, "#caa_origin_c > span > span"
  element :originDropdown, "#caa_origin_i"

  element :eventLabel, "#caa_event_c > span > span"
  element :eventInput, "#caa_event_i"

  element :causeLabel, "#caa_cause_c > span > span"
  element :causeInput, "#caa_cause_i"

  element :effectLabel, "#caa_impact_c > span > span"
  element :effectInput, "#caa_impact_i"

  element :riskDescriptorLabel, "#caa_riskdescriptor_c > span > span"
  element :riskDescriptorInput, "#caa_riskdescriptor_i"

  element :potentialConsequencesLabel, "#caa_potentialconsequence_c > span > span"
  element :potentialConsequencesDropdown, "#caa_potentialconsequence_i"

  element :impactLabel, "#caa_remainingbarriers_c > span > span"
  element :impactDropdown, "#caa_remainingbarriers_i"

  element :riskTypeLabel, "#caa_risktype_c > span > span"
  element :riskTypeDropdown, "#caa_risktype_i"

  element :desiredOutcomeLabel, "#caa_outcomeoption_c > span > span"
  element :desiredOutcomeDropdown, "#caa_outcomeoption_i"

  element :confirmedLabel, "#caa_confirmed_c > span > span"
  element :confirmedSpan, '#caa_confirmed > div[jawsreadlabel="caa_confirmed_c"] > span'


  element :optionsLabel, "#caa_outcomecomment_c > span > span"
  element :optionsTextarea, "#caa_outcomecomment_i"

  element :privilegeTypeLabel, "#caa_relatedprivilegetypes_c > span > span"
  element :privilegeTypeInput, "#caa_relatedprivilegetypes_ledit"
  element :privilegeTypeDoneSpan, '#caa_relatedprivilegetypes > div[jawsreadlabel="caa_relatedprivilegetypes_c"] > span[otypename="caa_privilegetype"]'
  element :privilegeTypeDoneLink, '#caa_privilegetype_subgrid_divDataArea tr[otypename="caa_privilegetype"] nobr > a'


  #expect to be Safety
  element :relatedAreaLabel, "#caa_category_c > span > span"
  element :relatedAreaDropdownSpan, "#caa_category > div > span"

  #expect to be yes
  element :confirmedSpan, 'div[jawsreadlabel="caa_confirmed_c"] > span'

  element :confirmedOnLabel, "#caa_confirmedon_c > span > span"
  element :confirmedOnInput, "#DateInput"

  element :aviationEntityLabel, "#caa_aviationentityid_c > span > span"
  element :aviationEntityInput, "#caa_aviationentityid_ledit"

  element :aviationSafetyReviewLabel, "#caa_safetyassessmentid_c > span > span"
  element :aviationSafetyReviewInput, "#caa_safetyassessmentid_ledit"
  element :aviationSafetyReviewLink, 'div > span[title*="Safety Review"]'
  element :aviationSafetyReviewSpan, 'div[jawsreadlabel="caa_safetyassessmentid_c"] span[otypename="caa_safetyassessment"]'

  element :safetyRiskThemeLabel, "#caa_safetyrisktheme_c > span > span"
  element :safetyRiskThemeInput, "#caa_safetyrisktheme_ledit"
  element :safetyRiskFilledInput, '#caa_safetyrisktheme > div[jawsreadlabel="caa_safetyrisktheme_c"] > span:nth-child(1)'

  element :safetyRiskTitleThemeLabel, "#caa_safetyrisktitletheme_c > span > span"
  element :safetyRiskTitleThemeInput, "#caa_safetyrisktitletheme_ledit"
  element :safetyRiskTitleThemeFilledSpan, '#caa_safetyrisktitletheme > div> span[otypename="caa_safetyrisktheme"]'

  element :addSafetyActionButton, "#MitigationActions_addImageButton"

  element :safetyActionSortByModified, '#MitigationActions_gridBar > tbody > tr > th:nth-child(14) > table > tbody > tr > td > a > nobr'
  element :safetyActionTitle, '#MitigationActions_divDataBody table[ologicalname="caa_safetyriskmitigationaction"] > tbody > tr:nth-child(1) > td:nth-child(2) > nobr'
  element :safetyActionTitleLink, '#MitigationActions_divDataBody table[ologicalname="caa_safetyriskmitigationaction"] > tbody > tr:nth-child(1) > td:nth-child(2) > nobr > a'
  element :safetyActionTargetCompletionDate, '#MitigationActions_divDataBody table[ologicalname="caa_safetyriskmitigationaction"] > tbody > tr:nth-child(1) > td:nth-child(3) > div'
  element :safetyActionActionOwner, '#MitigationActions_divDataBody table[ologicalname="caa_safetyriskmitigationaction"] > tbody > tr:nth-child(1) > td:nth-child(4) > nobr'
  element :safetyActionConfirmed, 'tr[otypename="caa_safetyriskmitigationaction"]:nth-child(1)  > td:nth-child(5) > div'
  element :safetyActionModifiedOnDate, 'tr[otypename="caa_safetyriskmitigationaction"]:nth-child(1)  > td:nth-child(8) > div'

  element :emptySafetyActionTable, "#MitigationActions_divDataArea #gridBodyTable > tbody > tr > td"

  element :deleteSafetyRisk, "#butBegin"
  element :saveInFooter, "#savefooter_statuscontrol"

  element :guidanceNotesLinkForPBOGuidance, "a[title*='PBO Guidance - Risk Assessment (Likely Outcome']"
  element :guidanceNotesNextPage, "#GuidanceNotes a[title='Load Next Page']"
  element :guidanceNotesPreviousPage, "#GuidanceNotes a[title='Load Previous Page']"

#Navigates to next page
  def navigate_next_page
      wait_for_ajax
      guidanceNotesNextPage.click
      wait_for_ajax

  end
#Navigates to previous page
  def navigate_previous_page
      wait_for_ajax
      guidanceNotesPreviousPage.click
      wait_for_ajax
  end

#Opens guidance notes
  def open_guidance_notes(guidance_notes)
      guidanceNotesLinkForPBOGuidance.click
      wait_for_ajax
  end


#clicks new button
  def clickNewButton
    wait_for_newButton(10)
    newButton.click
  end

#Clicks Save button
  def clickSaveButton
    wait_for_saveButton(10)
    saveButton.click
  end

#Clicks Save in bottom right of page
  def clickFooterSave
    wait_for_saveInFooter(10)
    saveInFooter.click
  end

#Opens Aviation Entity
  def clickAviationEntityTitle
    aviationEntityTitle.click
  end

#Enters input title and description as supplied in parameter
  def inputTitleDescription(title, description)
    wait_for_titleLabel(10)
    titleLabel.click
    titleInput.set title

    descriptionLabel.click
    descriptionTextarea.set description
  end

#Sorts by modified date on Safety Action
  def safetyActionSortBy
    wait_for_safetyActionSortByModified(10)
    safetyActionSortByModified.click
    sleep 2
    safetyActionSortByModified.click
  end

#Returns Safety Action 'modified on' date
  def getSafetyActionModifiedOnDate
    safetyActionModifiedOnDate.text
  end

#Sets all fields to complete Safety Risk
  def inputRiskData(origin, event, cause, effect, descriptor, likelihood, impact, riskType, desiredOutcome, options, privilegeType, confirmed, safetyReview, safetyTheme, safetyTitle)

    if has_aviationSafetyReviewSpan?
      puts "already filled"
    else
      aviationSafetyReviewLabel.click
      aviationSafetyReviewInput.set safetyReview
      page.driver.browser.action.send_keys(:return).perform
      sleep 2
      page.driver.browser.action.send_keys(:return).perform
      wait_for_ajax
    end

    if has_safetyRiskFilledInput?
      safetyRiskThemeLabel.click
      sleep 1
      page.driver.browser.action.send_keys(:backspace).perform
      safetyRiskThemeInput.set safetyTheme
    else
      safetyRiskThemeLabel.click
      safetyRiskThemeInput.set safetyTheme
    end
    sleep 2
    page.driver.browser.action.send_keys(:return).perform
    sleep 2
    page.driver.browser.action.send_keys(:return).perform
    wait_for_ajax

    if has_safetyRiskTitleThemeFilledSpan?
      safetyRiskTitleThemeLabel.click
      sleep 1
      page.driver.browser.action.send_keys(:backspace).perform
      safetyRiskTitleThemeInput.set safetyTitle
    else
      safetyRiskTitleThemeLabel.click
      safetyRiskTitleThemeInput.set safetyTitle
    end
    sleep 2
    page.driver.browser.action.send_keys(:return).perform
    sleep 2
    page.driver.browser.action.send_keys(:return).perform
    wait_for_ajax

    originLabel.click
    originDropdown.select(origin)

    eventLabel.click
    eventInput.set event

    causeLabel.click
    causeInput.set cause

    effectLabel.click
    effectInput.set effect

    riskDescriptorLabel.click
    riskDescriptorInput.set descriptor

    potentialConsequencesLabel.click
    potentialConsequencesDropdown.select(likelihood)

    impactLabel.click
    impactDropdown.select(impact)

    riskTypeLabel.click
    riskTypeDropdown.select(riskType)

    desiredOutcomeLabel.click
    desiredOutcomeDropdown.select(desiredOutcome)

    if confirmedSpan.text == "No"
      confirmedLabel.click
    end

    optionsLabel.click
    optionsTextarea.set options

    confirmedOnLabel.click
    confirmedOnInput.set confirmed

    if has_privilegeTypeDoneLink?
      puts "Don't modify"
    else
      privilegeTypeLabel.click
      privilegeTypeInput.set privilegeType
      sleep 2
      page.driver.browser.action.send_keys(:return).perform
      sleep 2
      page.driver.browser.action.send_keys(:return).perform
      sleep 2
    end



  end

#Adds a Safety Action
  def addSafetyAction
    wait_for_addSafetyActionButton(10)
    addSafetyActionButton.click
  end

#Clicks Safety Action title
  def clickSafetyActionTitle
    wait_for_safetyActionTitleLink(10)
    safetyActionTitleLink.click
  end

#Deactivate Safety Risk
  def deactivate_safety_risk
    wait_for_deactivateButton(10)
    deactivateButton.click
  end

#Click Safety Review Link
  def click_safety_review_link
    wait_for_aviationSafetyReviewLink(10)
    aviationSafetyReviewLink.click
  end

#Clicks Delete button
  def click_delete_button
    wait_for_deleteSafetyRisk(10)
    deleteSafetyRisk.click
  end

end

#IFrame under Safety Risk page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyRiskPageIFrame < SitePrism::Page
  iframe :safetyRiskIFrame, SafetyRisk, "contentIFrame0"
end

#Inline dialog IFrame under Safety Risk page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyRiskInlineDialogIframe < SitePrism::Page
  iframe :inlineDialogIFrame, SafetyRisk, "#InlineDialog_Iframe"
end
