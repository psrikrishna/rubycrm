#Activating a new Safety Review within an Aviation Entity on EPT CRM, to enable Oversight Team members to modify it.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyReview < SitePrism::Page

  element :formType, "#header_crmFormSelector span"

  #add new safety review elements
  element :startDate, "#caa_reviewstartdate_i #DateInput"
  element :startDateLabel, "#caa_reviewstartdate_c"
  element :endDate, "#caa_reviewenddate_i #DateInput"
  element :endDateLabel, "#caa_reviewenddate_c"

  element :auditDate, "#caa_auditdate_i #DateInput"
  element :auditDateLabel, "#caa_auditdate_c"

  element :ammDateInput, "#caa_ammdate_i #DateInput"
  element :ammDateLabel, "#caa_ammdate_c > span > span"

  element :enteredStartDate, "#caa_reviewstartdate > div > span"
  element :enteredEndDate, "#caa_reviewenddate > div > span"
  # element :enteredAuditDate, "#caa_auditdate > div > span"
  element :enteredAMMDate, "#caa_ammdate > div > span"

  #Safety Risk Elements
  element :closeInlineDialogButton, "#btnCross"

  element :safetyRiskModifiedOn, '#caa_safetyrisk_subgrid_gridBar th[fieldname="createdon"]'
  element :safetyRiskTitle, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(2) > nobr > a'
  element :safetyRiskRating, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(3) > div'
  element :safetyRiskType, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(4) > nobr'
  element :safetyRiskLikelihood, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(5) > nobr'
  element :safetyRiskImpact, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(6) > nobr'
  element :safetyRiskOutcome, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(7) > nobr'
  element :safetyRiskAssociatedAction, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(8) > div'
  element :safetyRiskOrigin, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(9) > nobr'
  element :safetyRiskPrivilegeType, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(10) > div'
  element :safetyRiskCreatedOnDate, 'table[ologicalname="caa_safetyrisk"] > tbody > tr:nth-child(1) > td:nth-child(13) > div'

  element :safetyRiskEmptyTable, "#caa_safetyrisk_subgrid_divDataArea #gridBodyTable > tbody > tr > td"

  element :aviationEntityTitle, 'div > span[otypename="caa_aviationentity"]'
  element :saveSafetyReview, "li[command*='SavePrimary']"

  element :aviationEntityLink, "#caa_aviationentityid > div.ms-crm-Inline-Value.ms-crm-Inline-Lookup > span.ms-crm-Lookup-Item"
  elements :safetyAssessmentPrivileges, "#caa_safetyassessmentprivileges_subgrid_divDataArea a[id*='gridBodyTable_primaryField']"

  # Accountanble Workflow Elements
  # element :runWorkflow, 'img[alt="Run Workflow"]' Deprecated Workflow Element
  element :moreCommandsButton, "#moreCommands > span > a"
  element :startDialogButton, 'img[alt="Start Dialog"]'
  element :sortByProcessName, 'a[title="Sort by Process Name"]'
  element :preAccountCheckbox, '#gridBodyTable > tbody > tr.ms-crm-List-Row > td:nth-child(3) > nobr'
  element :postAccountCheckbox, 'input[title="Create Post AM Email"]'
  element :addButton, "#butBegin"
  element :confirmDropdown, 'select[id*="InteractionStep"]'
  element :nextButton, "#butNext"
  element :finishButton, "#butFinish"

  element :omEntityLabel, "#caa_omentitysummary_c > span > span"
  element :omEntityTextarea, "#caa_omentitysummary_i"
  element :omEntityInputSavedSpan, '#caa_omentitysummary > div[jawsreadlabel="caa_omentitysummary_c"] > span'
  element :omEntityDateLabel, "#caa_omapprovaldate_c > span > span"
  element :omEntityDataInput, 'table[id="caa_omapprovaldate_i"] > tr > td > #DateInput'
  element :omEntityDateSavedSpan, '#caa_omapprovaldate > div[jawsreadlabel="caa_omapprovaldate_c"] > span'


  element :safetyRiskButton, "body > button"

  element :newSafetyRiskButton, "#btnNew"
  element :guidanceNotes, "table[name='GuidanceNotes']"

  #two deprecated elements from Systest
  # element :smOversightLabel, "#caa_sectormanagerfutureoversight_c > span > span"
  # element :smOversightTextarea, "#caa_sectormanagerfutureoversight_i"
  element :smApprovalLabel, "#caa_sectormanagerapprovalcomments_c > span > span"
  element :smApprovalTextarea, "#caa_sectormanagerapprovalcomments_i"
  element :smApprovalSavedTextSpan, '#caa_sectormanagerapprovalcomments > div[jawsreadlabel="caa_sectormanagerapprovalcomments_c"] > span'
  element :smApprovalDateLabel, "#caa_sectormanagerapprovaldate_c > span > span"
  element :smApprovalDateInput, "#caa_sectormanagerapprovaldate_i > tr > td > input"
  element :smApprovalDateSavedSpan, '#caa_sectormanagerapprovaldate > div[jawsreadlabel="caa_sectormanagerapprovaldate_c"] > span'

  # ------- Amend Safety Review Details ------

  element :entityOverviewLabel, "#caa_aircraftinformation_c > span > span"
  element :entityOverviewTextarea, "#caa_aircraftinformation_i"
  element :organisationalChartLabel, "#caa_organisationcharturl_c > span > span"
  element :organisationalChartInput, "#caa_organisationcharturl_i"

  # ---------- AssessmentPrivilege Element --------
  element :airOperatorCertificateLink, 'nobr[title="Air Operator Certificate "] > a'

  element :internalReviewMeeting, "#caa_irmeetingid > div.ms-crm-Inline-Value.ms-crm-Inline-Lookup > span.ms-crm-Lookup-Item"
  element :accountableManagerMeeting, "#caa_ammeetingid > div.ms-crm-Inline-Value.ms-crm-Inline-Lookup > span.ms-crm-Lookup-Item"
  element :safetyReviewCurrentStatus, "#header_statuscode"
  element :safetyReviewStatusDropdown, "select[id='header_statuscode_i']"
  element :saveInFooter, "#savefooter_statuscontrol"

  element :preAccountEmailLink, 'div[jawsreadlabel="caa_pre_ammeetingemailid_c"] > span[title*="Pre Accountable Manager"]'
  element :postAccountEmailLink, 'div > span[title*="Post Accountable Manager"]'
  element :emailBodyLineTwo, "body > p:nth-child(3) > span > font"
  element :emailSaveButton, "#savefooter_statuscontrol"
  element :regardingEmailLabel, "#regardingobjectid_c > span > span"
  # element :regardingEmailLink, "#regardingobjectid_lookupDiv > ul > li > span > span"
  element :regardingEmailLink, '#regardingobjectid > div[jawsreadlabel="regardingobjectid_c"] > span[role="link"]'

  element :postAMMeetingInput, "#DlgHdBodyContainer #gridBodyTable tr:nth-child(4) > td:nth-child(1)"

  element :addChangesToCurrentPeriod, "#ChangesToCurrentPeriod_addImageButton"
  element :addOversightTeamMember, "#OversightTeamMembers_addImageButton"
  element :addKeyPersonnelTeamMember, "#ActiveKeyPersonnel_addImageButton"
  elements :teamMembers, "#OversightTeamMembers_divDataArea a"

  element :aocLink, "#caa_safetyassessmentprivileges_subgrid a[title*='Air Operator Certificate']"

  element :verifyComplexityRating, "#caa_safetyassessmentprivileges_subgrid_span #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(6) > nobr"
  element :verifyProposedFutureOversight, "#caa_safetyassessmentprivileges_subgrid_span #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(7) > nobr"

#buttons
  element :addApprovedMaintenanceContractor, "#caa_approvedsubcontractor_subgrid_addImageButton"
  element :addPrimarySubContractor, "#caa_primarysubcontractor_subgrid_addImageButton"

  #textboxes
  element :approvedMaintenanceContractor, "#lookup_caa_approvedsubcontractor_subgrid_ledit"
  element :primarySubContractor, "#lookup_caa_primarysubcontractor_subgrid_ledit"

  #verify
  elements :enteredApprovedMaintenanceContractor, "#caa_approvedsubcontractor_subgrid a[id*='gridBodyTable_primaryField']"
  elements :enteredPrimarySubContractor,"#caa_primarysubcontractor_subgrid a[id*='gridBodyTable_primaryField']"
  elements :enteredKeyPersonnel, "#ActiveKeyPersonnel [id*='gridBodyTable_primaryField']"

  # -------- add maintenance contractor elements ----------
  element :contractorInputMagnifyingGlass, "#lookup_caa_approvedsubcontractor_subgrid_lookupTable img"
  element :addNewOrganisationForContractor, "#Dialog_lookup_caa_approvedsubcontractor_subgrid_i_IMenu a[title*='Create']"

  element :subcontractorInputMagnifyingGlass, "#lookup_caa_primarysubcontractor_subgrid_lookupTable img"
  element :addNewOrganisationForSubcontractor, "#Dialog_lookup_caa_primarysubcontractor_subgrid_i_IMenu a[title*='Create']"

  element :inlineOrgName, "#name_i"
  element  :inlineOrgNameLabel, "#name_c"

  element :inlinePhone, "#telephone1_i"
  element :inlinePhoneLabel, "#telephone1_c"

  element :inlineStreet, "#address1_line1_i"
  element :inlineStreetLabel, "#address1_line1_c"

  element :inlineCity, "#address1_city_i"
  element :inlineCityLabel, "#address1_city_c"

  element :inlinePostcode, "#address1_postalcode_i"
  element :inlinePostcodeLabel, "#address1_postalcode_c"

  element :saveInlineOrgApproved, "#globalquickcreate_save_button_lookup_caa_approvedsubcontractor_subgrid_i_lookup_quickcreate"
  element :saveInlineOrgPrimary, "#globalquickcreate_save_button_lookup_caa_primarysubcontractor_subgrid_i_lookup_quickcreate"

  #ept 28
  element :notesLink, '#header_notescontrol > a[title="NOTES"]'
  element :notesDiv, "#createNote"
  element :notesTextarea, "#createNote_notesTextBox"
  element :attachButton, '#createNote button[title="Attach"]'
  element :chooseFileButton, "#Attachments #userFile"
  element :doneButton, '#createNote #postButton'
  elements :createdAttachmentLink, ' #tab1 #attachSpacer div[id*="attachment_"] > a[title*="ept"]'

  element :approvedSubContractorTableEntries, "#caa_approvedsubcontractor_subgrid_divDataArea #gridBodyTable"

  element :guidanceNotes, "table[name='GuidanceNotes'] #gridBodyTable"

  element :currentReviewPeriodTable, "#ChangesToCurrentPeriod_divDataArea table"
  element :nextReviewPeriodTable, "#ChangestoNextPeriod_divDataArea table"

  element :newAssessmentPrivilege, "#caa_safetyassessmentprivileges_subgrid_addImageButton"

#Returns Safety risk table contents
def getSafetyRiskTableContent
  wait_for_ajax
  wait_for_safetyRiskEmptyTable(10)
  safetyRiskEmptyTable.text
end

#Clicks new Assessment Prvilege
  def open_new_assessment_privilege
      newAssessmentPrivilege.click
  end

#Returns number of entries in current changes table
  def number_of_entries_in_current_changes_table
        currentReviewPeriodTable['numrecords'].to_i
  end
#Returns number of entries in current changes table
  def number_of_entries_in_next_changes_table
        nextReviewPeriodTable['numrecords'].to_i
  end

#Returns control to aviation entity page
  def click_aviation_entity_title
    wait_for_aviationEntityTitle(10)
    aviationEntityTitle.click
  end

#Adds new organisation for approved maintenance
  def add_new_organisation_for_approved_maintenance

       wait_for_addApprovedMaintenanceContractor(10)
       addApprovedMaintenanceContractor.click
      wait_for_approvedMaintenanceContractor(10)
      wait_for_contractorInputMagnifyingGlass(10)

      contractorInputMagnifyingGlass.click
      wait_for_ajax
      wait_for_addNewOrganisationForContractor(10)

      addNewOrganisationForContractor.click
      wait_for_ajax

  end

#Adds new organisation for primary subcontractor
  def add_new_organisation_for_primary_subcontractor

      wait_for_addPrimarySubContractor(10)
      addPrimarySubContractor.click

       wait_for_primarySubContractor(10)
       primarySubContractor.click

      wait_for_subcontractorInputMagnifyingGlass(10)

      subcontractorInputMagnifyingGlass.click
      wait_for_ajax
      wait_for_addNewOrganisationForSubcontractor(10)

      addNewOrganisationForSubcontractor.click
      wait_for_ajax

  end

#Adds a new inline organisation
  def complete_new_inline_organsation (inline_org, inline_phone, inline_street, inline_city, inline_postcode)


      inlineOrgNameLabel.click

      if inline_org=="{Random}"

        $INLINE_ORGANISATION=generate_random_string(5)
        inlineOrgName.set $INLINE_ORGANISATION
      else
        inlineOrgName.set $inline_org
      end

      inlinePhoneLabel.click
      inlinePhone.set inline_phone

      inlineStreetLabel.click
      inlineStreet.set inline_street

      inlineCityLabel.click
      inlineCity.set inline_city

      inlinePostcodeLabel.click
      inlinePostcode.set inline_postcode

  end

#Saves inline organisation for approved maintenance
      def click_save_for_inline_org_approved
        saveInlineOrgApproved.click
        wait_for_ajax
      end

#Saves inline organisation for primary subcontractor
      def click_save_for_inline_org_primary
        saveInlineOrgPrimary.click
        wait_for_ajax
      end

#Returns entered Approved Maintenance Contractor
  def getEnteredApprovedMaintenanceContractor
    enteredApprovedMaintenanceContractor[0].text
  end

#Returns entered Primary Sub Contractor
  def getEnteredPrimarySubContractor
    enteredPrimarySubContractor[0].text
  end

#Retuns entered Key Personnel
  def getEnteredKeyPersonnel
    sleep 3
    enteredKeyPersonnel[0].text
  end

#Completes fields to add approved maintenance contractor
  def complete_fields_to_add_approved_maintenance_contractor(org)
       wait_for_addApprovedMaintenanceContractor(10)
       addApprovedMaintenanceContractor.click
       wait_for_approvedMaintenanceContractor(10)
       approvedMaintenanceContractor.set org

       page.driver.browser.action.send_keys(:tab).perform
       wait_for_ajax
  end


#Completes fields to add prim subcontractor
  def complete_fields_to_add_primary_subcontractor(org)
    wait_for_addPrimarySubContractor(10)
    addPrimarySubContractor.click
    wait_for_primarySubContractor(10)
    primarySubContractor.set org

        page.driver.browser.action.send_keys(:tab).perform
        wait_for_ajax

  end

#Returns complexity rating
  def getComplexityRating
    verifyComplexityRating.text
  end

#Returns proposed oversight
  def getProposedOversight
    verifyProposedFutureOversight.text
  end

#Clicks on Air Operator Ceritificate
  def click_aoc_link
      aocLink.click
  end

#Returns team member record count
  def getTeamMemberRecordCount
    wait_for_teamMembers(10)
    teamMembers.empty?
  end

#Returns control to aviation entity link
  def return_to_aviation_entity_link
    aviationEntityLink.click
  end


#Completes a safety review with start date and emd date specified in parameters
  def add_a_safety_review(start_date, end_date)
    startDateLabel.click
    startDate.set start_date

    endDateLabel.click
    endDate.set end_date
    # ammDateLabel.click
    # wait_for_ammDateInput(10) #atest
    # ammDateInput.set ammDate #atest

    # audit date no longer exists in updated environment ATEST
     # auditDateLabel.click
     # wait_for_ajax
     # auditDate.set audit_date


    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

  end

#Clicks Save icon in the top ribbon bar
  def click_save_under_ribbon
    page.driver.browser.action.move_to(saveSafetyReview.native).click.perform
    saveSafetyReview.click
    wait_for_ajax
  end

#Validates assessment privleges are populated
  def verifyActiveAssessmentPrivilegesArePopulated
    wait_for_ajax
    wait_for_safetyAssessmentPrivileges(20)
  end

#Returns first assessment privlege
  def activeAssessmentPrivilegesEntry1
    safetyAssessmentPrivileges[0].text
  end

#Returns 2nd assessment privlege
  def activeAssessmentPrivilegesEntry2
    safetyAssessmentPrivileges[1].text
  end

#Returns 3rd assessment privlege
  def activeAssessmentPrivilegesEntry3
    safetyAssessmentPrivileges[2].text
  end



  # ----------- EPT 26 and 27 ------------
#Clicks Start Dialog button
  def startWorkflow
    wait_for_moreCommandsButton(10)
    moreCommandsButton.click

    wait_for_startDialogButton(10)
    startDialogButton.click
  end

#Clicks Pre Account checkbox
  def clickPreAccountCheckbox
    wait_for_preAccountCheckbox(10)
    preAccountCheckbox.click
  end

#Clicks Post Account checkbox
  def clickPostAccountCheckbox
    wait_for_postAccountCheckbox(10)
    postAccountCheckbox.click
  end

#Clicks Add button
  def clickAddButton
    wait_for_addButton(10)
    addButton.click
  end

#Selects dropdown value specified in parameter
  def selectConfirmDropdown(confirm)
    wait_for_confirmDropdown(10)
    confirmDropdown.select(confirm)
  end

#Clicks Next button
  def clickNextButton
    wait_for_nextButton(10)
    nextButton.click
  end

#Clicks Finish button
  def clickFinishButton
    wait_for_finishButton(10)
    finishButton.click
  end

#Returns start data eneterd
  def getEnteredStartDate
    enteredStartDate.text
  end

#Returns end data eneterd
  def getEnteredEndDate
    enteredEndDate.text
  end

#Returns amm data eneterd
  def getEnteredAMMDate
    enteredAMMDate.text
  end

#Opens pre account email
  def openPreAccountEmail
    wait_for_preAccountEmailLink(10)
    preAccountEmailLink.click
  end

#Opens post account email
  def openPostAccountEmail
    wait_for_postAccountEmailLink(10)
    postAccountEmailLink.click
  end


#Returns internal review meeting text
  def getInternalReviewMeetingText
    internalReviewMeeting.text
  end

#Returns accountable manager  meeting text
  def getAccountableManagerMeetingText
    accountableManagerMeeting.text
  end

#Returns current status of safety reivew
  def getSafetyReviewCurrentStatus
    wait_for_ajax
    wait_for_safetyReviewCurrentStatus(10)
    safetyReviewCurrentStatus.text
  end

#Changes status to value specified in parameter
  def changeStatusTo(status)
    safetyReviewCurrentStatus.click
    wait_for_ajax
    safetyReviewStatusDropdown.select(status)
  end

#Returns internal review meeting text
  def getInternalReviewMeeting
    wait_for_ajax
    internalReviewMeeting.text
  end

#Returns accountable manager  meeting text
  def getAccountableManagerMeeting
    wait_for_ajax
    accountableManagerMeeting.text
  end

  # -------------------- Safety Risk Elements ------------------
#Clicks Safety Risk button
  def click_safety_risk_button
    wait_for_safetyRiskButton(10)
    safetyRiskButton.click
  end

#Clicks new Safety Risk button
  def click_new_safety_risk_button
    wait_for_newSafetyRiskButton(10)
    newSafetyRiskButton.click
  end

#Clicks Save at the bottom right of page
  def click_save_in_footer
    wait_for_saveInFooter(10)
    saveInFooter.click
    wait_for_ajax
  end

#Appends text to email body
  def appendEmailBody(text)
    wait_for_emailBodyLineTwo(10)
    emailBodyLineTwo.set(text)
  end

#Clicks save email
  def saveEmail
    wait_for_emailSaveButton(10)
    emailSaveButton.click
    wait_for_ajax
  end

#Clicks 'regarding email' link
  def clickRegardingEmailLink
    # wait_for_regardingEmailLabel(10)
    # regardingEmailLabel.click
    wait_for_regardingEmailLink(10)
    regardingEmailLink.click

  end

#Clicks Post AM Meeting link
  def checkPostAMMetting
    wait_for_postAMMeetingInput(10)
    postAMMeetingInput.click
  end

#Adds data and date specified in parameters
  def addDataOmEntity(data, date)
    wait_for_omEntityLabel(10)
    omEntityLabel.click
    wait_for_omEntityTextarea(10)
    omEntityTextarea.set data
    sleep 3
    wait_for_omEntityDateLabel(10)
    omEntityDateLabel.click
    sleep 2
    omEntityDateLabel.click
    wait_for_omEntityDataInput(10)
    omEntityDataInput.set date

    omEntityLabel.click
    wait_for_ajax
  end

#Adds approval and date specified in parameters
  def addSMData(approval, date)
    # wait_for_smOversightLabel(10)
    # smOversightLabel.click
    # smOversightTextarea.set oversight
    wait_for_smApprovalLabel(10)
    smApprovalLabel.click
    wait_for_smApprovalTextarea(10)
    smApprovalTextarea.set approval
    sleep 2
    wait_for_smApprovalDateLabel(10)
    smApprovalDateLabel.click
    sleep 2
    smApprovalDateLabel.click
    wait_for_smApprovalDateInput(10)
    smApprovalDateInput.set date

  end

#Clicks Add Changes to Current Period
  def clickAddChangesToCurrentPeriod
      addChangesToCurrentPeriod.click
  end

#Clicks Add Oversight team member
  def clickAddOversightTeamMember
    addOversightTeamMember.click
    wait_for_ajax
  end

  #Clicks Add Key Personnel team member
  def clickAddKeyPersonnelTeamMember
    addKeyPersonnelTeamMember.click
    wait_for_ajax
  end

#Returns form type
  def getFormType
    formType.text
  end

  #----------- Safety Risk Methods --------------------

#Clicks Safety Risk title
  def clickSafetyRiskTitle
    wait_for_safetyRiskTitle(10)
    safetyRiskTitle.click
  end

#Sorts safety risk by 'Modified on' column
  def safetyRiskSortByModifiedOn
    wait_for_safetyRiskModifiedOn(10)
    safetyRiskModifiedOn.click
    wait_for_ajax
    sleep 1
    safetyRiskModifiedOn.click
    wait_for_ajax
  end

#Closes the diaplog box
  def close_inline_dialog
    wait_for_closeInlineDialogButton(10)
    closeInlineDialogButton.click
  end

#Returns date created of the safety risk
  def getSafetyRiskCreatedOnDate
    safetyRiskCreatedOnDate.text
  end




 #------------- Amend Safety Review Details ---------------

# def getOverviewHoverText

#end

# def getChartHoverText
# end

#Adds overview and chart data as specified in parameters
  def addTextOverviewAndOrganisationalChart(overview, chart)
    wait_for_entityOverviewLabel(10)
    entityOverviewLabel.click
    entityOverviewTextarea.set overview
    sleep 2
    wait_for_organisationalChartLabel(10)
    organisationalChartLabel.click
    wait_for_organisationalChartInput(10)
    organisationalChartInput.set chart
  end

# ------------- @ept 28 ----------------------------
#Clicks Notes link
  def open_notes
    wait_for_notesLink(10)
    notesLink.click
  end

#Adds text specified in parameter to Notes field
  def add_text_to_notes(notes)
    wait_for_notesDiv(10)
    notesDiv.click
    wait_for_notesTextarea(10)
    notesTextarea.click
    notesTextarea.set notes
    wait_for_ajax
  end

#Clicks Attach button
  def click_attach_button
    wait_for_attachButton(10)
    attachButton.click
  end

#Uploads a PDF file located in project's 'Files' folder
  def upload_test_pdf
    attach_file("userFile", File.absolute_path("./Files/ept28 Test PDF.pdf"))
    wait_for_ajax
  end

#Clicks Done button
  def click_done_button
    wait_for_doneButton(10)
    doneButton.click
  end

#Verifies Guidance Notes
  def check_guidance_notes
    wait_for_guidanceNotes(10)
      guidanceNotes.visible?
  end

end

#Safety Review Inline Dialog IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class InlineDialogIframe < SitePrism::Page
  iframe :dialogIFrame, SafetyReview, "#InlineDialog_Iframe"
end

#Safety Review embedded Inline Dialog IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class InlineDialog1 < SitePrism::Page
  iframe :dialogSubFrame, SafetyReview, "#InlineDialog1_Iframe"
end

#Main IFrame in the Safety Review page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyReviewIFrame < SitePrism::Page
  iframe :safetyReviewIFrame, SafetyReview, '#contentIFrame0'
end

#Embedded IFrame in the Safety Review Content IFrame page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyReviewSubContentIFrame < SitePrism::Page
  iframe :safetyReviewSubContentIFrame, SafetyReview, '#contentIFrame1'
end

#Safety Review Email Body IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyEmailBodyIFrame < SitePrism::Page
  iframe :safetyEmailBodyIFrame, SafetyReview, "#descriptionIFrame"
end

#Safety Risk IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class SafetyRiskButtonIFrame < SitePrism::Page
  iframe :safetyRiskButtonIFrame, SafetyReview, "#WebResource_addSafety"
end

#IFrame when creating new organisation under Safety Review for Apprvoed Contractors
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class NewOrganisationWithinSafetyReviewApproved  < SitePrism::Page
  iframe :newOrganisationWithinSafetyReviewApproved, SafetyReview, "#lookup_caa_approvedsubcontractor_subgrid_i_lookup_quickcreate"
end

#IFrame when creating new organisation under Safety Review for Primary Contractors
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class NewOrganisationWithinSafetyReviewPrimary  < SitePrism::Page
  iframe :newOrganisationWithinSafetyReviewPrimary, SafetyReview, "#lookup_caa_primarysubcontractor_subgrid_i_lookup_quickcreate"
end

#IFrame for notes attachment under Safety Review
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class NotesAttachmentIFrame <SitePrism::Page
  iframe :notesAttachmentIFrame, SafetyReview, '#createNote_attachFileIframe'
end
