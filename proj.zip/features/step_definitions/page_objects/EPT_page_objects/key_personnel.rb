#Key Personnel can be added to Safety Review once they are part of the Oversight team
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class KeyPersonnel < SitePrism::Page

element :individualLabel, "#caa_individualid_c"
element :individual, "#caa_individualid_ledit"

element :roleLabel, "#caa_keypersonnelroleid_c"
element :role, "#caa_keypersonnelroleid_ledit"

element :saveAndClose, "span[command*='SaveAndClosePrimary']"

#Adds a key personnel
def add_key_personnel (individual_kp, role_kp)
    individualLabel.click
    wait_for_ajax
    individual.set individual_kp
    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

    roleLabel.click
    wait_for_ajax
    role.set role_kp
    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

end

#Clicks Save and closes the popup window
def click_save_and_close
    saveAndClose.click
    wait_for_ajax
end

end

#IFrame under the Key Personnel page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class KeyPersonnelIFrame < SitePrism::Page
  iframe :keyPersonnelIFrame, KeyPersonnel, '#contentIFrame0'
end
