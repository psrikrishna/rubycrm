#The Privilege created is visible in the Privileges table, with the Name, Privilege Type, Valid From and Valid To values
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class Privilege < SitePrism::Page

  element :name, "#caa_name_i"
  element :nameLabel, "#caa_name_c"

  element :desc,"#caa_description_i"
  element :descLabel, "#caa_description_c > span > span"

  element :fromDate,"#caa_validfrom_i input"
  element :fromDateLabel, "#caa_validfrom_c"

  element :toDate,"#caa_validto_i input"
  element :toDateLabel, "#caa_validto_c"

  element :businessAreaLabel, "#caa_privilegebusinessarea_c > span > span"
  element :businessAreaDropdown, "#caa_privilegebusinessarea_i"

  element :privilegeType,"#caa_privilegetypeid_ledit"
  element :privilegeTypeLabel, "#caa_privilegetypeid_c"

  element :savePrivilege, "li[command*='SavePrimary']"
  element :saveAndClosePrivilege, "li[command*='SaveAndClose']"

#Adds a privilege
  def add_a_privilege(privilegeName,privilegeDesc,validFrom,validTo, businessArea)
    $PRIVILEGE_NAME=generate_random_string(10)
    nameLabel.click

    if (privilegeName.eql?"{Random}")
        name.set $PRIVILEGE_NAME
    else
        name.set privilegeName
    end

   descLabel.click
   desc.set privilegeDesc

  fromDateLabel.click
  fromDate.set validFrom

  toDateLabel.click
  toDate.set validTo

  if has_businessAreaLabel?
    businessAreaLabel.click
    businessAreaDropdown.select businessArea
  end

  end

#Clicks save privilege
  def click_save_privilege
    savePrivilege.click
  end

#Saves and closes Privilege popup window
  def click_save_and_close_privilege
    saveAndClosePrivilege.click
  end

#Sets privilege to specified parameter
  def set_privilege(privilege)
    privilegeTypeLabel.click
    privilegeType.set(privilege)
    privilegeTypeLabel.click
  end

end

#IFrame under Privilege page
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class PrivilegeContentIFrame < SitePrism::Page
  iframe :privilegeContentIFrame, Privilege, '#contentIFrame0'
end
