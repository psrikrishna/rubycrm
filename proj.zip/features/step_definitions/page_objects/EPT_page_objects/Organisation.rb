#The Organisation Page Object is the base entity under which all other EPT entities are created.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class Organisation < SitePrism::Page


element :name, "#name_i"
element :nameLabel, "#name_c"

element :addr1, "#address1_line1_i"
element :addr1Label, "#address1_line1_c"

element :addr2, "#address1_line2_i"
element :addr2Label, "#address1_line2_c"

element :addr3, "#address1_line3_i"
element :addr3Label, "#address1_line3_c"

element :city, "#address1_city_i"
element :cityLabel, "#address1_city_c"

element :county, "#address1_stateorprovince_i"
element :countyLabel, "#address1_stateorprovince_c"

element :postCode, "#address1_postalcode_i"
element :postCodeLabel, "#address1_postalcode_c"

element :country, "#new_countrys_ledit"
element :countryLabel, "#new_countrys_c"

element :email, "#emailaddress1_i"
element :emailLabel, "#emailaddress1_c"

element :phone, "#telephone1_i"
element :phoneLabel, "#telephone1_c"

element :area, "#caa_aviationareaid_ledit"
element :areaLabel, "#caa_aviationareaid_c"

element :sector, "#caa_aviationsectorid_ledit"
element :sectorLabel, "#caa_aviationsectorid_c"

element :leadPrivilege, "#caa_leadprivilegeid_ledit"
element :leadPrivilegeLabel, "#caa_leadprivilegeid_c"

element :relatedRecordsLink, '#tab2 > div > div:nth-child(2) > a'
element :addPrivilegeButton, "#caa_privilege_section_addImageButton"

element :saveIconBelowRibbon, "li[command*='SavePrimary'] > span > a > img"

element :saveIcon, "#savefooter_statuscontrol"

#Uses minimum required fields to create an organisation. It assigns a random name to organisation that starts with 'auto' followed by a random string.
      def complete_required_fields_to_save_an_organisation(orgName,orgAddress1, orgAddress2, orgAddress3, orgCity, orgCounty, orgPostcode,orgCountry,orgEmail,orgPhone)
        $ORGANISATION=generate_random_string(10)
      nameLabel.click
      if (orgName.eql?"{Random}")
          name.set $ORGANISATION
      else
          name.set orgName
      end


      addr1Label.click
      addr1.set orgAddress1

      addr2Label.click
      addr2.set orgAddress2

      addr3Label.click
      addr3.set orgAddress3

      cityLabel.click
      city.set orgCity

      countyLabel.click
      county.set orgCounty

      postCodeLabel.click
      postCode.set orgPostcode

      countryLabel.click
      country.set orgCountry

      emailLabel.click
      email.set orgEmail

      phoneLabel.click
      phone.set orgPhone

      end

#Adds additional fields to orgainsation - Aviation Area and Aviation Sector supplied from feature file
      def complete_remaining_fields_to_save_an_organisation(aviationArea,aviationSector)
        areaLabel.click
        wait_for_ajax
        area.set aviationArea
        wait_for_ajax

        sectorLabel.click
        wait_for_ajax
        sector.set aviationSector
        wait_for_ajax

        sectorLabel.click #to switch focus and save entered value
        wait_for_ajax
      end

#Opens the Privileges window
      def open_privilege_window
        if has_no_addPrivilegeButton?
          relatedRecordsLink.click
        end
        addPrivilegeButton.click
      end

#Clicks the Save icon at the bottom of page
      def click_save_below_ribbon
        saveIconBelowRibbon.click
      end

#Sets the lead privilege with random text
      def set_lead_privilege(privilege)
          leadPrivilegeLabel.click
          if privilege.eql?"{Random}"
            leadPrivilege.set $PRIVILEGE_NAME
          else
          leadPrivilege.set privilege
          end
      end

#Clicks the Save icon in the ribbon
      def click_save_icon
        wait_until_saveIcon_visible(10)
        saveIcon.click
      end

end

#IFrame within the Organisation page object
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class OrgContentIFrame < SitePrism::Page
  iframe :orgContentIFrame, Organisation, '#contentIFrame0'
end

#IFrame embedded within the Organisation and OrgContentIFrame page object
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class OrgSubContentIFrame < SitePrism::Page
  iframe :orgSubContentIFrame, Organisation, '#contentIFrame1'
end
