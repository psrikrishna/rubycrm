# Aviation Entity is the child entity after creating an Organisation within EPT CRM.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AviationEntity < SitePrism::Page

element :formType, "#header_crmFormSelector span"
element :nameLabel, "#caa_name_c"
element :name, "#caa_name_i"

element :primaryOrganisation, "#caa_primaryorganisationid_ledit"
element :primaryOrganisationLabel, "#caa_primaryorganisationid_c"

element :leadPrivilegeLabel, "#caa_leadprivilegequickviewform_caa_leadprivilegequickviewform_account_caa_leadprivilegeid_c"
#element :leadPrivilege, "#caa_leadprivilegequickviewform_caa_leadprivilegequickviewform_account_caa_leadprivilegeid_c"

element :nameEntered, "#caa_name > div.ms-crm-Inline-Value > span"
element :orgEntered, "#caa_primaryorganisationid_d"

element :caaCode, "#header_caa_code > div.ms-crm-Inline-Value.ms-crm-HeaderTile.ms-crm-Inline-Locked > span"
element :ssiCode, "#header_caa_ssiconfidencelevelid > div.ms-crm-Inline-Value.ms-crm-HeaderTile.ms-crm-Inline-EmptyValue.ms-crm-Inline-Locked.ms-crm-Inline-Lookup"
element :smsCode, "#header_caa_smsconfidencelevelid > div.ms-crm-Inline-Value.ms-crm-HeaderTile.ms-crm-Inline-EmptyValue.ms-crm-Inline-Locked.ms-crm-Inline-Lookup"

#Safety Risk Elements
element :safetyRiskPlusButton, "#ActiveSafetyRisks_addImageButtonImage"

element :safetyRiskModifiedOn, "#ActiveSafetyRisks_gridBar > tbody > tr:nth-child(1) > th:nth-child(22) > table > tbody > tr > td > a"
element :safetyRiskTitle, '#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(2) > nobr'
element :safetyRiskEntity, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(3) > nobr"
element :safetyRiskRating, '#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(4) > div'
element :safetyRiskReview, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(5) > nobr"
element :safetyRiskLikelihood, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(6) > nobr"
element :safetyRiskImpact, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(7) > nobr"
element :safetyRiskDesiredOutcome, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(8) > nobr"
element :safetyRiskAssociatedAction, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(9) > div"
element :safetyRiskOrigin, "#ActiveSafetyRisks_divDataBody #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(10) > nobr"

element :safetyAssessmentsSection, "#SafetyAssessments_titleText"
element :safetyRisksSection, "#ActiveSafetyRisks_titleText"
element :entPrivilegesSection, "#OrganisationPrivileges_titleText"
element :orgSection, "#Organisations_titleText"
element :oversightTeamSection, "#ActiveOversightTeam_titleText"
element :keyPersonnelSection, "#ActiveKeyPersonnel_titleText"
element :activitiesSection, "a[title='ACTIVITIES']"
element :notesSection, "a[title='NOTES']"
element :addSafetyReview, "#SafetyAssessments_addImageButton"

  element :searchRecordsInput, "#crmGrid_findCriteria"
  element :matchingRecord, "a[id*='gridBodyTable_primaryField']"
  elements :safetyReviews,"#SafetyAssessments_divDataBody a[id*='gridBodyTable_primaryField']"

element :firstSafetyReviewName, 'table[ologicalname="caa_safetyassessment"] > tbody > tr:nth-child(1) > td:nth-child(2)'
element :firstSafetyReviewStatus, "#SafetyAssessments_divDataArea #gridBodyTable > tbody > tr > td:nth-child(9) > div"

element :deactivate, "li[command*='Deactivate']"

#Deactivates a safety review
def deactivateSafetyReview
    deactivate.click
    wait_for_ajax
    wait = Selenium::WebDriver::Wait.new ignore: Selenium::WebDriver::Error::NoAlertPresentError
    alert = wait.until { page.driver.browser.switch_to.alert }
    alert.accept
end

#Get first safety review status
def getFirstSafetyReviewStatus
    firstSafetyReviewStatus.text
end

#Creates an Aviation Entity
def complete_mandatory_fields_to_create_aviation_entity(entity_name, primary_org)
  $AVIATION_ENTITY=generate_random_string(10)

    nameLabel.click
    if entity_name=="{Random}"
        name.set $AVIATION_ENTITY
    else
        name.set entity_name
    end

    primaryOrganisationLabel.click

    if primary_org=="{Random}"
        primaryOrganisation.set $ORGANISATION
    else
        primaryOrganisation.set primary_org
    end

    wait_for_ajax

    primaryOrganisationLabel.click


end

#Opens first safety review
def click_safety_review_name
  wait_for_firstSafetyReviewName(10)
  firstSafetyReviewName.click
end

#Opens new Safety Review popup window
def open_safety_review_window
  wait_for_addSafetyReview(10)
    addSafetyReview.click
end

#Get text from Entity name
def getEntityName
  nameEntered.text
end

#Get text from Organisation
def getOrgName
  orgEntered.text
end

#Get text from CAA code
def getCaaCode
  caaCode.text
end

#Get text from SSI Code
def getSsiCode
  ssiCode.text
end

#Get text from SMS code
def getSmsCode
  smsCode.text
end

#Clicks on + button to add Safety Risk
def click_safety_risk_plus_button
  wait_for_safetyRiskPlusButton(10)
  safetyRiskPlusButton.click
end

#Get text from Safety Assessment section
def getSafetyAssessmentsSection
  (safetyAssessmentsSection.text).upcase
end

#Get text from Safety Risk section
def getSafetyRisksSection
  (safetyRisksSection.text).upcase
end

#Get text from Privileges section
def getEntPrivilegesSection
  (entPrivilegesSection.text).upcase
end

#Get text from Organisation section
def getOrgSection
  (orgSection.text).upcase
end

#Get text from Oversight team section
def getOversightTeamSection
  (oversightTeamSection.text).upcase
end

#Get text from Key Personnel section
def getKeyPersonnelSection
  (keyPersonnelSection.text).upcase
end

#Get text from Activities section
def getActivitiesSection
  (activitiesSection.text).upcase
end

#Get text from Notes section
def getNotesSection
  (notesSection.text).upcase
end

#Searches for aviation entity by supplied parameter
def search_aviation_entity(entity)
  wait_for_searchRecordsInput(10)
  searchRecordsInput.set entity
  page.driver.browser.action.send_keys(:return).perform
  wait_for_ajax
end

#Opens aviation entity
def open_aviation_entity(entity)
  wait_for_ajax
  wait_for_matchingRecord(10)
  page.driver.browser.action.move_to(matchingRecord.native).click.perform
  wait_for_ajax
end

#Opens a safety review
def open_safety_review
wait_for_safetyReviews(10)
safetyReviews[0].click
end

#Returns form type
def getFormType
  formType.text
end

#----------- Safety Risk Methods --------------------

#Open Safety Risk
def clickSafetyRiskTitle
  wait_for_safetyRiskTitle(10)
  safetyRiskTitle.click
end

#sort Safety Risk by 'Modified On' column
def safetyRiskSortByModifiedOn
  wait_for_safetyRiskModifiedOn(10)
  safetyRiskModifiedOn.click
  sleep 1
  safetyRiskModifiedOn.click
end




end

#IFrame under Aviation Entity
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AviationEntityContentIFrame < SitePrism::Page
  iframe :aviationEntityContentIFrame, AviationEntity, '#contentIFrame0'
end

#Embedded IFrame under Aviation Entity IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AviationEntitySubContentIFrame < SitePrism::Page
  iframe :aviationEntitySubContentIFrame, AviationEntity, '#contentIFrame1'
end

#Embedded IFrame under Aviation Entity SubContent IFrame
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
 class AviationInlineDialogIFrame < SitePrism::Page
   iframe :aviationDialogIFrame, AviationEntity, "InlineDialog_Iframe"
 end
