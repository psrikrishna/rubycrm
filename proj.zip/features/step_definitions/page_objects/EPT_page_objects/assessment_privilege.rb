# The Assessment Privilege is an entity under a Safety Review.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AssessmentPrivilege < SitePrism::Page

element :assessmentTypeLabel, "#caa_privilegetypeid_c"
element :assessmentType, "#caa_privilegetypeid_ledit"

element :assessmentDescLabel, "td[id*='caa_privilegetypedescription_c'] img"
element :assessmentDesc, "#caa_privilegetypedescription_i"

element :teamMemberLabel, "#caa_safetyoversightteammemberid_c"
element :teamMember, "#caa_safetyoversightteammemberid_ledit"

element :sectorManagerLabel, "#caa_sectormanager_c"
element :sectorManager, "#caa_sectormanager_ledit"

  element :saveAndClose, "li[id*='SaveAndClose']"

#Adds an Assessment Privlege
def add_assessment_privilege(type, desc, member, manager)
    wait_for_assessmentTypeLabel(10)
    assessmentTypeLabel.click
    wait_for_ajax
    assessmentType.set type

    assessmentDescLabel.click
      wait_for_ajax
    assessmentDesc.set desc

    teamMemberLabel.click
    wait_for_ajax
    teamMember.set member

    sectorManagerLabel.click
    wait_for_ajax
    sectorManager.set manager
    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

end

#Clicks save and closes popup window
def click_save_and_close
saveAndClose.click

end

end

#IFrame within Assessment Privlege
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class AssessmentPrivilegeIFrame < SitePrism::Page
  iframe :assessmentPrivilegeIFrame, AssessmentPrivilege, '#contentIFrame0'
end
