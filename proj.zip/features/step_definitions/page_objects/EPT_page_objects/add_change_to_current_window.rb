#Log Changes that are anticipated in the Current Period or Next Period within an Aviation Entity,
#via the front page of the Active Safety Review and/or via an Active Assessment Privilege, on EPT CRM.
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera

class AddChangeToCurrentPeriod < SitePrism::Page

  element :change, "#caa_name_i"
  element :changeLabel, "#caa_name_i"

  element :teamMember, "#caa_safetyoversightteammemberid_ledit"
  element :teamMemberLabel, "#caa_safetyoversightteammemberid_c"

  element :period, "select[id='caa_period_i']"
  element :periodLabel, "#caa_period_c"

  element :description, "#caa_comment_i"
  element :descriptionLabel, "#caa_comment_c>span>span"

  element :assessmentPrivilegeLabel, "#caa_safetyassessmentprivilegeid_c > span > span"
  element :assessmentPrivilegeInput, "#caa_safetyassessmentprivilegeid_ledit"
  element :assessmentPrivilegeSpan, '#caa_safetyassessmentprivilegeid > div > span:nth-child(1)'

  element :saveAndClose, "li[id*='SaveAndClose']"


#Completes minimum required fields for current period
  def complete_required_fields_to_add_changes_to_current_period(var_change, oversight_team_member, var_period, var_description, assessment_privilege)
    changeLabel.click
    change.set var_change

    teamMemberLabel.click
    wait_for_ajax
    teamMember.set oversight_team_member

    periodLabel.click
    wait_for_ajax
    period.select(var_period)

    descriptionLabel.click
    wait_for_ajax
    description.set var_description

    if has_assessmentPrivilegeSpan?
      print "Inside Privilege"
    else
      wait_for_assessmentPrivilegeLabel(10)
      assessmentPrivilegeLabel.click
      assessmentPrivilegeInput.set assessment_privilege
    end
  end

#Save and close the Add changes to Current Period window
  def click_save_and_close
    saveAndClose.click
    wait_for_ajax
  end


end

#IFrame within the Add changes to Current Period window
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera

class AddChangeToCurrentPeriodContentIFrame < SitePrism::Page
  iframe :addChangeToCurrentPeriodContentIFrame, AddChangeToCurrentPeriod, '#contentIFrame0'
end
