# --------------------- Schedule Case Steps -----------------------------------------

When /^I click the add icon to create a new case$/ do
  @homeIFrame.homeIframe do |parent_frame|
    @dashboardIFrame.dashboardIframe do |child_frame|
       child_frame.click_add_case

     end
  end
end

And /^I complete the Identify stage with the following details:$/ do |table|
  #In @two_audits scenario, title is given a unique identifier using a random string. However the variable $random_string is not created until that scenario is run and so is equal to nil until that point.
  @newCase.check_random_string
  #Global data stored as Hash
  $global_data = table.rows_hash

#read data from the data table and example
    title           = $global_data["Title"]
    customerID      = @newCase.checkIndividualOrOrganisation($global_data["Customer ID"]) # If customer ID is Individual, assign the generated random name
    caseType        = $global_data["Case Type"]
    caseCategory    = $global_data["Case Category"]
    subCategory     = $global_data["Sub Category"]
    reference       = $global_data["Reference"]
    approvalNumber  = $global_data["Approval Number"]

        @addCaseIFrame.addCaseIFrame do |frame|
      
          frame.complete_required_fields_in_identify_stage(title, customerID, caseType, caseCategory, subCategory, reference, approvalNumber="12345678")
          frame.click_save_icon

                    expect(frame.getHeaderTitleIdentifyStage).to eq (title + $random_string)
                    expect(frame.getHeaderSubCategoryIdentifyStage).to eq subCategory
                    expect(frame.getHeaderCustomerIdentifyStage).to eq customerID
                    expect(frame.getHeaderCategoryIdentifyStage).to include caseCategory
                    #Using include rather than equal becuase dropdown selection and display don't match
                    # for example, FOTI becomes FOTI Airplane after selection
#Counter to check number of runs
          $looped += 1
        end
end

And /^I complete the Assign stage$/ do
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.click_navigate_first_stage
    expect(frame.getAssignStageTitle).to eq Status::ASSIGN_ACTIVE
    expect(frame.getTitleAssignStage).to eq ($global_data["Title"] +  $random_string)
    expect(frame.getCustomerAssignStage).to eq $global_data["Customer ID"]
    expect(frame.getSubCategoryAssignStage).to eq $global_data["Sub Category"]
    expect(frame.getCategoryAssignStage).to include $global_data['Case Category']
    #Using include rather than equal becuase dropdown selection and display don't match
    # for example, FOTI becomes FOTI Airplane after selection

    frame.complete_required_fields_in_assign_stage

  end
end

And /^I complete the Information stage with the following details:$/ do |table|
  $test_number="2"
  page.driver.browser.navigate.refresh
  wait_for_ajax
  $global_data = $global_data.merge(table.rows_hash)

  contactName     = $global_data["Contact Name"]
  salutation      = $global_data["Salutation"]
  email           = $global_data["Email"]
  phone           = $global_data["Phone"]
  caaRef          = $global_data["CAA Personal Ref"]
  jobNumber       = $global_data["Job number"]
  location        = $global_data["Location"]
  inspectionType  = $global_data["FOTI Inspection Type"]
  reqDate         = $global_data["Requested Date"]
  inspector       = $global_data["Inspector"]
  aircarftType    = $global_data["Aircarft Type"]
  registration    = $global_data["Registration"]
  taskType        = $global_data["Task Type"]
  surveyor        = $global_data["Surveyor"]
  possibleDate    = $global_data["Possible Date"]
  agreedStartDate = $global_data["Agreed Start Date"]
  agreedEndDate   = $global_data["Agreed End Date"]


  @addCaseIFrame.addCaseIFrame do |frame|

    if $global_data['Case Category'] == Status::CATEGORY_FOTI_DROPDOWN #different set of fields for FOTI Category

      frame.complete_required_fields_in_information_stage_for_foti(contactName, salutation, email, phone,
        caaRef, jobNumber, location, inspectionType, reqDate,
        inspector, aircarftType, agreedStartDate, agreedEndDate)

     else
         frame.complete_required_fields_in_information_stage(contactName, salutation, email, phone,
      aircarftType,registration, location, taskType,
        surveyor, possibleDate, agreedStartDate, agreedEndDate)
        wait_for_ajax

        expect(frame.getInformationStageTitle).to eq Status::INFORMATION_ACTIVE

         expect(frame.getHeaderSurveyorName).to eq surveyor
    end


    frame.click_navigate_next_stage
    wait_for_ajax

  end
end

Then /^I am on the Complete stage with "(.*?)" status and "(.*?)" as status reason$/ do |status, status_reason|

  wait_for_ajax

        @addCaseIFrame.addCaseIFrame do |frame|
          expect(frame.completeStageTitle.text).to eq Status::COMPLETE_ACTIVE
          expect(frame.statusReasonCompleteStage.text).to eq status_reason
          expect(frame.statusCompleteStage.text).to eq status
          expect(frame.titleCompleteStage.text).to eq $global_data["Title"] + $random_string
          expect(frame.caseTypeCodeCompleteStage.text).to eq $global_data["Case Type"]
          expect(frame.qPulseRefCompleteStage.text).to eq $global_data["Reference"]
          expect(frame.subcategoryCompleteStage.text).to eq $global_data["Sub Category"]
          expect(frame.customerCompleteStage.text).to eq $global_data["Customer ID"]

                    if ($onUnannouncedScenario!=1) #Check validations only for non-unannounced scenarios as there is no status for unannounced scenario

                                  if  ($UNALLOCATED_CASE) #If creating a new case from cancelled case, status will be 'Not Set';else it will display Succeeded
                                      expect(frame.allocatedByCompleteStage.text).to eq Status::NOT_SET_STATUS
                                      $UNALLOCATED_CASE=false #Reset status to false
                                  else
                                      expect(frame.allocatedByCompleteStage.text).to eq Status::ALLOCATED_BY_STATUS
                                  end
                    end

        end

end

When /^I Add a Service Activity$/ do

  title           = $global_data["Title"]
  customerID      = $global_data["Customer ID"]
  caseType        = $global_data["Case Type"]
  caseCategory    = $global_data["Case Category"]
  subCategory     = $global_data["Sub Category"]
  reference       = $global_data["Reference"]
  approvalNumber  = $global_data["Approval Number"]
  contactName      = $global_data["Contact Name"]
  salutation       = $global_data["Salutation"]
  email            = $global_data["Email"]
  phone            = $global_data["Phone"]
  caaRef           = $global_data["CAA Personal Ref"]
  jobNumber        = $global_data["Job number"]
  location         = $global_data["Location"]
  inspectionType   = $global_data["FOTI Inspection Type"]
  reqDate          = $global_data["Requested Date"]
  inspector        = $global_data["Inspector"]
  aircarftType     = $global_data["Aircarft Type"]
  registration     = $global_data["Registration"]
  location         = $global_data["Location"]
  taskType         = $global_data["Task Type"]
  surveyor         = $global_data["Surveyor"]
  possibleDate     = $global_data["Possible Date"]
  agreedStartDate  = $global_data["Agreed Start Date"]
  agreedEndDate    = $global_data["Agreed End Date"]

  @newCase.add_service_activity

  $serviceActivityWindow = window_opened_by do
    @newCase.addServiceActivity.click
    sleep 3
  end

  $parent_window=page.driver.browser.window_handles.last

      within_window $serviceActivityWindow do
                  @serviceIFrame.iFrame do |frame|
                    wait_for_ajax


                                    if $global_data['Case Category']==Status::CATEGORY_FOTI_DROPDOWN
                                      frame.check_all_relevant_fields_prepopulated_for_foti(title, customerID,
                                        inspector, agreedStartDate, agreedStartDate,
                                        contactName, email, phone,
                                        caaRef, jobNumber, location, aircarftType, Status::CATEGORY_FOTI_DISPLAY, subCategory)
                                    else
                                      frame.check_all_relevant_fields_prepopulated(title, customerID,
                                        surveyor, agreedStartDate, agreedStartDate,
                                        contactName, email, phone,
                                        aircarftType, registration, location, caseCategory, subCategory)
                                    end

                            frame.fill_service_input(subCategory)

                    end


              @service.click_save_icon

              @innerServiceIFrame.serviceIFrame do |frame|
                frame.scheduleAlertSaveButton.click
              end
      end

end



And /^I add a Prep and Post activities$/ do

  within_window $serviceActivityWindow do

      prepPostWindow = window_opened_by do
        @service.click_prep_post_button
      end

      within_window prepPostWindow do
        wait_for_ajax
        @prepPost.click_create_service_button
        page.driver.browser.switch_to.alert.accept
        wait_for_ajax
      end

  end
end

When /^I return to the case$/ do
  wait_for_ajax
  close_current_window
  switch_to_parent_window
end

Then /^I must see case status as "(.*?)"$/ do |status|
  page.driver.browser.navigate.refresh
  wait_for_ajax
  time_out = 5
  while time_out != 0 do
      @addCaseIFrame.addCaseIFrame do |frame|
        if frame.has_no_statusCompleteStage?
          page.driver.browser.navigate.refresh
        end
        if frame.get_case_status == status
          time_out = 0
        else
          time_out -= 1
          page.driver.browser.navigate.refresh
          sleep 5
        end
      end
  end
end

Then /^I must see case status reason as "(.*?)"$/ do|status_reason|
  time_out = 5
  while time_out != 0 do
    @addCaseIFrame.addCaseIFrame do |frame|
      if frame.get_case_status_reason == status_reason
        time_out = 0
      else
        time_out -= 1
        page.driver.browser.navigate.refresh
        sleep 5
      end
    end
  end
end

And /^I must see the Service Activity, Prep and Post activities and email associated to case$/ do
  @addCaseIFrame.addCaseIFrame do |frame|
    expect(frame).to have_prepActivity
    expect(frame).to have_postActivity
    expect(frame).to have_validateOutGoingEmail
  end
end

# ------------------------ Reschedule Scenario Steps -------------------------------

When /^I open the previous case$/ do

  @home.load

  @homeIFrame.homeIframe do |parent_frame|
    @dashboardIFrame.dashboardIframe do |child_frame|
      child_frame.click_search_records_input
      child_frame.sort_by_created_on_under_allocated_scheduling_cases
      child_frame.open_most_recent_allocated_case
    end
  end
  wait_for_ajax
end

And /^I modify the agreed start date and agreed end date in the scheduling checklist:$/ do |table|

  $global_data = $global_data.merge(table.rows_hash)

  @addCaseIFrame.addCaseIFrame do |frame|
    frame.click_information_stage
    wait_for_ajax
    page.driver.browser.navigate.refresh
  end
  @addCaseIFrame.addCaseIFrame do |frame|
    wait_for_ajax

    modifiedStartDate = $global_data["Modified start date"]
    modifiedEndDate   = $global_data["Modified end date"]

    frame.modify_start_and_end_date(modifiedStartDate, modifiedEndDate)
    frame.click_navigate_next_stage
  end


end

And /^I reschedule the service activity$/ do
  time_out = 5
        while time_out != 0 do
          @addCaseIFrame.addCaseIFrame do |frame|
                  if frame.has_preRescheduleServiceThumbnail?
                    time_out = 0
                  else
                    time_out -= 1
                    page.driver.browser.navigate.refresh
                    sleep 10
                  end
                end
          end

          @addCaseIFrame.addCaseIFrame do |frame|
                $scheduledServiceActivityWindow = window_opened_by do
                      frame.open_pre_scheduled_service_activity
                      wait_for_ajax
                end
          end

    within_window $scheduledServiceActivityWindow do
      @serviceIFrame.iFrame do |frame|

        modifiedStartDate = $global_data["Modified start date"]
        modifiedEndDate   = $global_data["Modified end date"]

        frame.modify_start_end_date(modifiedStartDate, modifiedEndDate)
      end
    end
# During unannounced and foti scenarios, the confirmation email will generate a starting and end. During a normal schedule there will be a start and end date. During a reschedule, this becomes and all day event. Therefore the validation must change to account for it. This variable tells the test to validate for a rescheduled test.
  $rescheduled = 1
end

And /^I select a rebooked reason and select save:$/ do |table|
  within_window $scheduledServiceActivityWindow do
    $global_data = $global_data.merge table.rows_hash
    reason = $global_data["Rebooked Reason"]
    @serviceIFrame.iFrame do |frame|
      frame.choose_rebooked_reason(reason)
      wait_for_ajax
    end
    @service.click_save_icon
    wait_for_ajax
    @innerServiceIFrame.serviceIFrame do |frame|
      wait_for_ajax
      frame.wait_for_scheduleAlertSaveButton(10)
      frame.scheduleAlertSaveButton.click
      sleep 2
    end
    close_current_window
    switch_to_parent_window
  end
end

And /^I will not see Prep and Post activities associated to case$/ do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.has_no_prepActivity?
    frame.has_no_postActivity?
  end
end

And /^I open the service activity to create a Prep and Post activity$/ do
  @addCaseIFrame.addCaseIFrame do |frame|
    $scheduledServiceActivityWindow = window_opened_by do
      frame.open_after_rechedule_service_activity
      wait_for_ajax
    end
  end
  within_window $scheduledServiceActivityWindow do
    wait_for_ajax
    prepPostWindow = window_opened_by do
      @service.click_prep_post_button
    end

    within_window prepPostWindow do
      wait_for_ajax
      @prepPost.click_create_service_button
      page.driver.browser.switch_to.alert.accept
      wait_for_ajax
    end
  end
end

# --------------------- Cancel Case Steps ------------------------------------------------

And /^I open the Service Activity and click close$/ do
  time_out = 5
  while time_out != 0 do
    @addCaseIFrame.addCaseIFrame do |frame|
      wait_for_ajax
      if frame.has_preRescheduleServiceThumbnail?
        time_out = 0
      else
        time_out -= 1
        page.driver.browser.navigate.refresh
        sleep 10
      end
    end
  end
  @addCaseIFrame.addCaseIFrame do |frame|
    $scheduledServiceActivityWindow = window_opened_by do
      frame.open_pre_scheduled_service_activity
    end
  end
  within_window $scheduledServiceActivityWindow do
    wait_for_ajax
    @service.click_close_service_activity_icon
  end
end

And /^I select a reason to close the service activity:$/ do |table|
  $global_data = $global_data.merge(table.rows_hash)
    cancelledReason = $global_data["Cancelled Reason"]
    within_window $scheduledServiceActivityWindow do
      @innerServiceIFrame.serviceIFrame do |frame|
        frame.choose_cancelled_reason(cancelledReason)
        frame.click_inner_frame_close_button
        wait_for_ajax
      end
      # During unannounced and foti scenarios, the confirmation email will generate a starting and end. During a normal schedule there will be a start and end date. Therefore the validation must change to account for it. This variable tells the test to validate for a scheduled test
        $rescheduled = 0
    end
end

And /^I see service activity elements disabled$/ do
  within_window $scheduledServiceActivityWindow do
    expect(@service).to have_disabledPrepPostButton
    expect(@service).to have_disabledSaveButton

      @serviceIFrame.iFrame do |frame|
        case $global_data['Case Category']
          when Status::CATEGORY_FOTI_DROPDOWN
            expect(frame.check_ui_elements_are_disabled_for_foti).to eq true
          when Status::UNANNOUNCED
          when Status::INTERMEDIATE
            expect(frame.check_ui_elements_are_disabled_for_unannounced).to eq true
          else
              expect(frame.check_ui_elements_are_disabled).to eq true
          end
      end
  end
end

Then /^I refresh the page until I see case status as "(.*?)" and status reason as "(.*?)"$/ do |status, status_reason|
  wait_for_ajax
  time_out = 5
  while time_out != 0 do
    @addCaseIFrame.addCaseIFrame do |frame|
      if frame.statusReasonCompleteStage.text == status_reason && frame.statusCompleteStage.text == status
        time_out = 0
      else
        time_out -= 1
        page.driver.browser.navigate.refresh
      end
    end
  end
  @addCaseIFrame.addCaseIFrame do |frame|
    expect(frame.statusReasonCompleteStage.text).to eq status_reason
    expect(frame.statusCompleteStage.text).to eq status
  end
end

# -------------- Two Audits Scenario Steps --------------------------------

And /^I add a unique identifier to the title$/ do
  $random_string = generate_random_string(8)
  $identifier =  $global_data['Title'] + $random_string
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.add_unique_title_identifier($identifier)
  end
end

And /^I link the parent case$/ do
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.input_parent_case($identifier)
    frame.click_save_icon
    sleep 5
  end
end

And /^I see that the information stage has been linked to the parent case$/ do
  wait_for_ajax
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.click_save_icon
    frame.click_navigate_next_stage
  end
end

And /^I must see no email has been generated$/ do
  @addCaseIFrame.addCaseIFrame do |frame|
    expect(frame).to have_no_outGoingEmail
  end
  wait_for_ajax
end

And /^I search for the parent case$/ do
  @homeIFrame.homeIframe do |parent_frame|
    @dashboardIFrame.dashboardIframe do |child_frame|
      child_frame.find_case_working_on($identifier)
      page.driver.browser.action.send_keys(:return).perform
      wait_for_ajax
      child_frame.click_case_working_on
    end
  end
end

And /^I open the email, validate the details and click send:$/ do |table|

  @email_data = table.rows_hash
  recipient = @email_data["cc Recipient"]
  testEmail = @email_data["cc Email"]
  bodyText  = @email_data["Email Body Text"]

  page.driver.browser.navigate.refresh
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.open_confirmation_email
  end
  page.driver.browser.navigate.refresh
  @emailIFrame.emailIFrame do |frame|

    frame.add_email_to_cc(testEmail)

    @emailBodyIFrame.emailBodyIFrame do |innerFrame|
      innerFrame.add_text_to_body(bodyText)
    end
    expect(frame.emailStatusReason.text).to eq Status::EMAIL_STATUS
    frame.click_save_icon
  end

  wait_for_ajax
  @newCase.send_email
end

Then /^I can see the child case in the subgrid of the complete stage$/ do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @addCaseIFrame.addCaseIFrame do |frame|
    expect(frame).to have_childCaseSubgrid
  end
end



# -------------- Import Scenario Steps ------------------------------------


And /^I access the import data section$/ do
  @mainNavBar.access_import_data_tab
end


And /^I select a file for import$/ do
  wait_for_ajax
  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|
      @uploadFileFrame.uploadFileFrame do |upload_frame|
        upload_frame.select_a_file
      end
      child_frame.click_next_button
    end
  end
end
#

And /^I review the file upload summary$/ do
  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|
      child_frame.click_next_button
    end
  end
end


And /^I select the Data Map as \"([^\"]*)\"$/ do |dataMapSelection|
  if dataMapSelection.eql? "Monthly Q-Pulse Audits"
    @dialogIFrame.dialogIFrame do |parent_frame|
      @wizardIFrame.wizardIFrame do |child_frame|
        child_frame.select_monthly_q_pulse_audits
        child_frame.click_next_button
      end
    end
  end
end

And /^I map the record types to \"([^\"]*)\"$/ do |recordType|
  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|
      child_frame.select_record_types_as_q_pulse_audit
      child_frame.click_next_button
    end
  end
end


And /^I verify the map fields$/ do |table|

  @map_data = table.rows_hash

  approvalStatus    = @map_data["Approval Status"]
  audType           = @map_data["Aud type"]
  audNote           = @map_data["Audit Note"]
  auditStatus       = @map_data["Audit Status"]
  crmCategory       = @map_data["CRM Category"]
  crmSubCategory    = @map_data["CRM Sub-Category"]
  leadAuditor       = @map_data["Lead Auditor"]
  number            = @map_data["number"]
  orgName           = @map_data["Organisation Name"]
  refNumber         = @map_data["Reference Number"]
  startDate         = @map_data["Scheduled Start Date"]
  endDate           = @map_data["Scheduled End Date"]
  schedulingOfficer = @map_data["Scheduling Officer"]

  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|

      expect(child_frame.verifyApprovalStatusMapping).to eq approvalStatus
      expect(child_frame.verifyAuditTypeMapping).to  eq audType
      expect(child_frame.verifyAuditNoteMapping).to eq audNote
      expect(child_frame.verifyAuditStatus).to eq auditStatus
      expect(child_frame.verifyCrmCategory).to eq crmCategory
      expect(child_frame.verifyCrmSubCategory).to eq crmSubCategory
      expect(child_frame.verifyLeadAuditor).to eq leadAuditor
      expect(child_frame.verifyNumber).to eq number
      expect(child_frame.verifyOrganisationName).to eq orgName
      expect(child_frame.verifyReferenceNumber).to eq refNumber
      expect(child_frame.verifyScheduledStartDate).to eq endDate
      expect(child_frame.verifyScheduledEndDate).to eq  startDate
      expect(child_frame.verifySchedulingOfficer).to eq schedulingOfficer

      child_frame.click_next_button
      page.driver.browser.switch_to.alert.accept
    end

  end
end


And /^I review the mapping summary$/ do
  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|
      wait_for_ajax
      child_frame.click_next_button
    end
  end
end

 And /^I click Submit$/ do
  @dialogIFrame.dialogIFrame do |parent_frame|
    @wizardIFrame.wizardIFrame do |child_frame|
      child_frame.click_submit_button
      child_frame.checkPageLoadComplete
    end
  end
end

And /^I click Finish$/ do
  page.driver.browser.navigate.refresh
  page.driver.browser.switch_to.alert.accept
end


Then /^the My imports refreshes the status to \"([^\"]*)\"$/ do |status|
  @importIFrame.importIFrame do |frame|
    expect(frame.refresh_grid_until_file_import_status_is_complete(status)).to eq true
  end
end

And /^I sort the Allocated Scheduling Cases by \"([^\"]*)\"$/ do |criteria|
  if criteria.eql? "Created On"
    @homeIFrame.homeIframe do |parent_frame|
      @dashboardIFrame.dashboardIframe do |child_frame|
        child_frame.sort_by_created_on_under_allocated_scheduling_cases
      end
    end
  end
end

Then /^I can verify imported data with title \"([^\"]*)\"$/ do |title|
 @homeIFrame.homeIframe do |parent_frame|
   @dashboardIFrame.dashboardIframe do |child_frame|
     sleep 10
      expect(child_frame.verify_imported_data(title)).to eq true
    end
 end
end


# ----------------- Unannounced Scenario ------------------------

And /^I complete the Unnanounced Information Stage with the following details$/ do | table |
  @data = table.rows_hash
  #Assign to global data for reuse
  $data=@data
  #Se unannounced flag to true
  $onUnannouncedScenario=1

  qPulseStatus     = @data["Q-Pulse Status"]
  contactName      = @data["Contact Name"]
  salutation       = @data["Salutation"]
  email            = @data["Email"]
  phone            = @data["Phone"]
  surveyor         = @data["Surveyor"]
  dueDate          = @data["Recommended Due Date"]
  qPulseStartDate  = @data["Q-Pulse Start Date"]
  qPulseEndDate    = @data["Q-Pulse End Date"]
  auditDuration    = @data["Audit Duration"]
  location         = @data["Location"]
  possibleDate     = @data["Possible Date"]
  agreedStartDate  = @data["Agreed Start Date"]
  agreedEndDate    = @data["Agreed End Date"]

  page.driver.browser.navigate.refresh
  @addCaseIFrame.addCaseIFrame do |frame|
    wait_for_ajax
    frame.complete_required_fields_in_unannounced_information_stage(qPulseStatus, contactName, salutation, email, phone, surveyor, dueDate, qPulseStartDate, qPulseEndDate, auditDuration, location,  possibleDate, agreedStartDate, agreedEndDate)

    expect(frame.getHeaderSurveyorName).to eq surveyor

    frame.click_navigate_next_stage
    wait_for_ajax
  end
end

When /^I open the confirmation email, validate the details and press send$/ do |table|
  @data=table.rows_hash
  surveyor          = @data["Surveyor"]
  inspector         = @data["Inspector"]
  startDate         = @data["Agreed Start Date"]
  endDate           = @data["Agreed End Date"]
  modifiedStartDate = @data["Modified start date"]
  modifiedEndDate   = @data["Modified end date"]
  location          = $global_data["Location"]
  orgName           = $global_data["Customer ID"]
  reference         = $global_data["Reference"]
  caaRef            = $global_data["CAA Personal Ref"]
  jobNumber         = $global_data["Job number"]

  page.driver.browser.navigate.refresh

  @addCaseIFrame.addCaseIFrame do |frame|
    frame.open_confirmation_email
  end

  wait_for_ajax
  page.driver.browser.navigate.refresh
  wait_for_ajax

  @emailIFrame.emailIFrame do |frame|
            case $global_data['Case Category']
                when Status::CATEGORY_FOTI_DROPDOWN
                  page.should have_content(inspector)
                else
                  page.should have_content(surveyor)
            end

    expect(frame.emailStatusReason.text).to eq Status::EMAIL_STATUS

    #email body validations
              @emailBodyIFrame.emailBodyIFrame do |innerFrame|
          # During unannounced and foti scenarios, the confirmation email will generate a starting and end.
          #During a normal schedule there will be a start and end date.
          #During a reschedule, this becomes and all day event. For a cancelled event there is no date. Therefore the validation must change to account for it.
                    page.should have_content(location)

                    case $global_data['Case Category']

                      when Status::CATEGORY_FOTI_DROPDOWN
                        page.should have_content(caaRef)
                        page.should have_content(jobNumber)
                        page.should have_content(inspector)
                      else
                        page.should have_content(orgName)
                        page.should have_content(reference)
                        page.should have_content(surveyor)
                      end

                              if $rescheduled == 1
                                page.should have_content(innerFrame.reformat_date_for_email_validation(modifiedStartDate))
                                page.should have_content(innerFrame.reformat_date_for_email_validation(modifiedEndDate))
                              else
                                page.should have_content(innerFrame.reformat_date_for_email_validation(startDate))
                                page.should have_content(innerFrame.reformat_date_for_email_validation(endDate))
                              end
                end
        end
  @newCase.send_email
  sleep 2
  wait_for_ajax

end

And /^I populate the following fields$/ do |table|
  @data = table.rows_hash
  dueDate          = @data["Recommended Due Date"]
  agreedStartDate  = @data["Agreed Start Date"]
  agreedEndDate    = @data["Agreed End Date"]
  surveyor         = @data["Surveyor"]
  page.driver.browser.navigate.refresh
  @addCaseIFrame.addCaseIFrame do |frame|
    frame.fillInDates(dueDate, agreedStartDate, agreedEndDate)

    expect(frame.getHeaderSurveyorName).to eq surveyor
    frame.click_navigate_next_stage
    wait_for_ajax
  end
end
#---------------------------------- foti steps ---------------------------


Then /^I create an individual with name$/ do |table|

  $global_data=$global_data.merge(table.rows_hash)

  $ind_first_name    = $global_data["First Name"]
  $ind_surname       = $global_data["Surname"]

        @mainNavBar.access_individual_tab
        @individual.add_new_individual
        wait_for_ajax

        if $ind_first_name=="{random}"
            $ind_first_name=generate_random_string(5)
        end

        if $ind_surname=="{random}"
            $ind_surname=generate_random_string(5)
        end

            @individualIFrame.individualIFrame do |frame|
                frame.set_name($ind_first_name, $ind_surname)
             end

       @individual.click_save_and_close
         wait_for_ajax

end

Then /^I open the cancelled case$/ do
  @homeIFrame.homeIframe do |parent_frame|
    @dashboardIFrame.dashboardIframe do |child_frame|
       child_frame.search_unallocated_cases( $global_data["Customer ID"])
     end
  end
  $UNALLOCATED_CASE=true
end

Then /^I must see case status on Identity page as "(.*?)"$/ do |status|
      @addCaseIFrame.addCaseIFrame do |frame|
        expect(frame.getUnassignedStatusReason).to eq status
      end
end

And /^I Assign the case to myself$/ do

    @newCase.click_assign_case_to_self

      @addCaseInlineDialogIFrame.addCaseInlineDialogIFrame do |child_frame|
        child_frame.accept_assign_to_self
      end
end

And /^I verify the following fields are empty in the Information stage:$/ do |table|
  page.driver.browser.navigate.refresh
  @addCaseIFrame.addCaseIFrame do |frame|

    wait_for_ajax
    # expect(frame.getInformationStageTitle).to eq Status::INFORMATION_ACTIVE

      expect(frame.verify_empty_values_for_start_date).to eq true
      expect(frame.verify_empty_values_for_end_date).to eq true

  end

end

And /^I populate the following fields are empty in the Information stage:$/ do |table|

  agreedStartDate  = $global_data["Agreed Start Date"]
  agreedEndDate    = $global_data["Agreed End Date"]


  @addCaseIFrame.addCaseIFrame do |frame|

        wait_for_ajax
        frame.complete_start_and_end_dates(agreedStartDate,agreedEndDate)

    frame.click_navigate_next_stage
    wait_for_ajax

  end
end
