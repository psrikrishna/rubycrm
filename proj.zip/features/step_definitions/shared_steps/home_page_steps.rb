Given /^I am on the home page$/ do
  @home.load
  wait_for_ajax
end
