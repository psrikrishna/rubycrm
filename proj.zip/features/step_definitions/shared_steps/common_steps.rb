#Generates random string of length specified in parameter
def generate_random_string(x)
  "auto" + (0...x).map { (65 + rand(26)).chr }.join
end

#Closes current window
def close_current_window
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  page.driver.browser.close
end

#Switches to parent window
def switch_to_parent_window
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
end
