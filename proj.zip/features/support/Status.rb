#
# Project:: Resource Scheduling
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class Status
  #Flag to distinguish unallocated and allocated cases
$UNALLOCATED_CASE=false
#Label description for Assign stage
  ASSIGN_ACTIVE    =  "Assign (Active)"
  #Label description for Info stage
  INFORMATION_ACTIVE= "Information (Active)"
  #Label description for Complete stage
  COMPLETE_ACTIVE=    "Complete (Active)"
  #Label description for Allocated field
  ALLOCATED_BY_STATUS="Succeeded"
  #Label description for import success message
  IMPORT_SUCCESS="Your data has been submitted for import."
  #Label description for email status
  EMAIL_STATUS = "Draft"
  #Text for selecting FOTI as category
  CATEGORY_FOTI_DROPDOWN="FOTI"
  #Text displayed on UI after selecting FOTI
  CATEGORY_FOTI_DISPLAY="FOTI Airplane"
  #Text displayed when status is not set
  NOT_SET_STATUS="Not Set"
  #Text displayed for unannounced scenario
  UNANNOUNCED = "Unannounced/Out of Hours"
    #Text displayed for intermediate scenario
  INTERMEDIATE = "Intermediate 2nd Site"
end
