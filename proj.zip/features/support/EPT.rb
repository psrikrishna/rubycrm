#
# Project:: EPT
# Organisation:: CAA
# Author:: Krishna Peddinti, Nick Rothera
class EPT


# global variables for EPT. Allows you to run tests independently. If this entity contains no safety review, run EPT3 first before running any other test.
#Fallback Organisation name
$ORGANISATION="autoWLHXFBMXUS"
#Fallback Privilege name
$PRIVILEGE_NAME="autoCFKIGJKJZK"
#Fallback Avitation Entity
$AVIATION_ENTITY="autoQZQRVAWGQE"

# Variables for @ept21, if run independently.
#Default Safety Theme
$safetyTheme = "Governance"
#Default Safety Title
$safetyTitle = "Accountable Manager"
#Default risk Type
$riskType = "Tolerate"
#Default Likelihood text
$likelihood = "Possible"
#Impact text description
$impact = "Medium"
#Origin's text description
$origin = "Aviation Entity"
#Outcome's text description
$outcome = "Improve"
#Privilege type dropdown text selection
$privilegeType = "Part 145 - Maintenance"

#constants in EPTPortal
#Aviation Entity text description
AVIATION_ENTITY_FORM_NAME="AVIATION ENTITY"
#Safety Review text description
SAFETY_REVIEW_FORM_NAME="SAFETY REVIEW"

end
