
<a id="sectionOne"></a>
# Projects and Tools

Test automation for CRM, EPT, portal (others still to be explored).  

## Required Tools
1. **Ruby 2.2 and above, without Devkit - https://rubyinstaller.org/downloads/ **
2. **Chrome Driver - Latest Version**]
3. **Git Tools - 2.16.1-32-bit https://git-scm.com/download/win**
4. **Atom - https://atom.io/**
5. **All gems within the gemfile**

## Framework uses the following features:
- Page Object modeling using Site Prism for easy maintenance and extendability<br>
- Cucumber to drive user acceptance tests
- Screenshots for failed tests
- Report generation with timestamp to maintain audit trail

## Pre-requisites for running the project:

- **chromedriver** should be in system PATH
- **ruby** installed and in the system PATH
- `gem install bundle` should be run via the CLI to help install gems and dependencies
- `bundle install` should be run via the CLI to install gems and dependencies

<a id="consoleCommands"></a>
Running the project:

Make sure the CLI is in the root of project. Run the project from CLI using the following command:

	cucumber

This will run every feature file within the project. If you want to run a particular feature use the command


	cucumber features/feature_folder/name_of_feature_file.feature


You can also run particular scenarios within a feature file using the tag command <a id="scenarioCommandLine"></a>  


	cucumber --tag @tag_name


An HTML report with the current date and time is generated in the project root folder along with screenshots if there are any failures.

<a id="sectionTwo"></a>
# Reading the report

## Passed Report:


![Generated Report](../images/report_example.PNG)

1. How many tests have passed, failed or been skipped, as well as how long it took for the test to finish.  

2. Which scenario was run.  

3. Step Definitions written in the Gherkin Format

4. Examples table where the details inputted in each work flow are contained. Each test can have as many examples tables as desired, each containing different information. The test will then repeat until all tables have been completed.

## Failed Report:

 ![Generated Report](../images/failing_test.PNG)

5. How many tests have passed, failed or been skipped, as well as how long it took for the test to finish.

6. What caused the test to fail, location of where the error ocurred in the code.

<a id="sectionThree"></a>
# Page Object Model

![Folder Layout](../images/folder_layout.PNG)

1. **Features**: Feature files contain a high level overview of what features will be run, and the scenarios within that feature. For example, resource scheduling is a feature which contains a scheduling scenario, a cancelling scenario, a rescheduling scenario and an import scenario. [Click to see Feature File contents](#partOne)

2. **Step Definitions**: The files within the step definitions folder will contain the steps that take you through a work flow, e.g. *Given I am on the home page, And I add a new case, When I input the details, And I press save, Then I should see case as booked*
Inside of these steps will be the methods taken from the files within pages that will take you through the workflow. [Click to see Step Definition contents](#partTwo)   

3. **Pages**: All files within the pages folder represent a page on the site being tested. For example the <strong> service_activity_page.rb </strong> represents the page opened when you want to add a service activity.   
Inside the page.rb files you will find the html identifier for each element, e.g. inputs, labels, buttons. You will also find methods to interact with the elements, e.g. clicking save, inputting a name, choosing from a dropdown list. [Click to see Page Files contents](#partThree)


<a id="sectionFour"></a>
# File Contents

<a id="partOne"></a>
## Feature File  ![Generated Report](../images/feature_contents.PNG)
  1. **The name of the feature** - The name of your feature should encompass what the different scenarios will be testing.
  2. **Scenario Tag** - Scenario tags allow you to run that specific scenario in the terminal [(*See Project and Tools for more info*)](#scenarioCommandLine).
  3. **Scenario Outline** - This is where you define what the scenario is surrounding this test. Scenarios with an outline will contain an examples step with a table. This table allows you to run the test multiple times with different types of data. You may create scenarios without an outline that will only be run once and any input data will come from within the step or pages files.
  4. **Step Table** - This is the business readable Gherkin language. Each step correlates to an action within the work flow. Step tables are where you define data you want to input within the test. The values within the <> will become the titles of the examples table. Any data without <> will be what is inputted in the test.
  5. **Examples Table** - This is where you input the data that correlates with the step tables created above. The bottom row correlates to the data type specified on the top row. You may create as many rows as required and the test will repeat until all data variations have been run.

<a id="partTwo"></a>
## Step Definition File ![Generated Report](../images/step_defs_file.PNG)

 1. **The Step Definition** - The feature file will look in the step definition files for the step definition it is currently on. If the step definition in the feature file has a **Step Table**, then we put **|table|** to access that data. The first step uses *Regular Expression (/^ $/)*, which tells the feature file to only look for step definitions which match it exactly.   
 The second step works the same way but without using regular expression
 2. **Accessing Step Table Data** - In order to access the data, we need to format the **Step Table**. The method `rows_hash` transforms the data into a usable form. We can then set variables equal the data placed in the **Examples Table**. e.g. `contactName = testname` **[(As seen in the examples table from the feature file above)](#partOne)**.
 3. **Page Method** - **[(See env.rb below for more information on how it is linked)](#partFour).** Once defined in **env.rb**, the **Step Definition** knows to look in the pages files for methods to complete tasks. This particular method is performed inside an iFrame, therefore the method is inside a frame block **[(see pages file below for more information)](#partThree).** <a id="stepDefIFrameExample"></a>

 <a id="addServiceActivity"></a>
## Step Definition File Continued ![Generated Report](../images/step_defs_file_two.PNG)

 4. **The Step Definition** - Same as the step definitions above but without a table.
 5. **Page Method** - **[(See env.rb below for more information on how it is linked)](#partFour)**. This method take place on the page and therefore is **not** inside a frame block.  
 6. **Pop Up Window Method** - During some work flows a pop up window will appear. In order to direct the automated test to this window, we must make a variable equal to the action that opens that window (e.g. click a button).  
 We then continue inside that variable which tells our test to move away from the main browser.

<a id="partThree"></a>
## Pages File ![Generated Report](../images/pages_file.PNG)
1. **Page Class** - Each page refers to a real page on the CRM system. Therefore we name them accordingly. **AddCase** refers to the page containing the identity, assign, information and complete stage forms. Each page inherits methods from SitePrism which allows us to do things like switch to pop up windows, perform methods inside of iFrames and much more. [In env.rb you can see how we can linked it](#partFour) [
2. **Page Element** - This is how the test located elements on a webpage. **These particular elements are found using the its ID**. Finding elements by ID makes it strong against page changes or updates.
3. **Page Element** - **These particular elements are found using HTML**. This makes it fast to locate, however it makes it weak against web changes or updates. The CRM system often makes it difficult to locate elements, or will create elements with the same locator, making this the only way to locate these elements.

	## Pages File Continued![Generated Report](../images/pages_file_two.PNG)
4. **Fill Inputs Method** -  In order to access and add data to inputs we have to get the data we want to input (which in this case are dates), click the label next to the input box in to make it visible to the test and then type in the data using **set**. The reason we click on the label next to the input rather than accessing the input directly is because they are contained within a ***hidden div***. While visible to the eye, this makes it invisible to selenium.
5. **Click Button Method** - This is an example of how to click a button. [You can see it being used here](#addServiceActivity) The reason we use the `wait_for` method is because often the page may load slowly, and interacting with the page can sometimes cause other element to become invisible for a short period. This method tells the test to wait 10 seconds before breaking.
6. **Get Text Method** -  Sometimes we want to check that the text on the page is what we expect (e.g. Making sure an email is a 'draft' rather than 'sent'). We can do this using the `.text` method on the element we want to get the text from.
7. **Validation Method** - Sometimes we want to check that certain elements are displayed on the page. In this example, we are checking that a prep activity has been created.

	## Pages File Continued ![Pages File IFrame](../images/pages_file_three.PNG)
<a id="pageIFrameExample"></a>
8. **IFrame Class** - The iFrame class takes 4 parameters. The Type **(iframe)**, what you want to call it **(:nameOfIFrame)**, which **Page Class** you want to inherit methods and elements from, and the **ID** of the iFrame.

<a id="partFour"></a>
## ENV.rb File ![ENV.rb](../images/env_file_one.PNG)
1. **Ruby Gems** - Gems are pre built pieces of code we can use to make our lives easier. For example, **Capybara** and **Site Prism** turns difficult to read selenium methods (e.g.  

		 WebElement element = driver.findElement(By.id("gbqfd"));   
		 JavascriptExecutor executor = (JavascriptExecutor)driver;   
		 executor.executeScript("arguments[0].click();", element);
)
and turns it into `element.click`  
2. **Environmental Variables** - Your computer stores your credentials (username = name@caa.co.uk, password = password123). For testing purposes we often need to use credentials of someone else who has access to the pages we want to test. DOTENV allows us to override the credentials on the computer being used.
3. **Capybara Configuration** - Before the tests can run, we need to configure Capybara to run. First we need to tell it which **webdriver** we are going to use, which in this case is **selenium**. We also need to tell it the url of the site we are testing.
4. **World Method** - This makes Capybara methods and configuration available throughout the test folder.
5. **Driver Configuration** - We need to tell the driver which browser we want to test, which in this case is **Chrome**. We can also add in other  options, such as maximising the screen when we start the test and disabling extensions so that they do not interfere.




## ENV.rb File Continued ![ENV.rb](../images/env_file_two.PNG)

6. **Before Hook** - Sometimes there are variables we want to to set up before specific scenarios. We can do this using a **Before Hook**. In this case we are setting up these variables before every scenario, but we can be more specific by using [**tags**](#partOne).
7. **Test Variables**
 * **$random_string** - During the resource scheduling feature, there are certain scenarios that require us to add a random string to the end of the title of the audit so we can search for it later. During validations, we want to make sure the title is correct, but these validations are the same across multiple scenarios, and sometimes a random string won't have been added to the audit title. Therefore we set it here as blank, so for tests without a random string it won't cause the validation to fail.
 * **$rescheduled** -  During the rescheduling scenario we modify the start and end dates of the audit. Therefore during the test we set this variable to 1, so that during the validations the test knows to look for the modified dates rather than the initially set dates.
 * **$global_data** - [From the examples table in the feature files](#partOne) we can see this data is used across different scenarios. Therefore to make it more reusable we created this variable rather than create new data variables.
8. **Page Instance Variables** - We need to access the elements and methods from the page files from within our step definition files. Therefore we set up **Instance Variable** = to the Class of the page we want to use. [See if getting used here](#addServiceActivity)
9. **IFrame Instant Variables** - [As seen in the pages file](#pageIFrameExample) iFrames are there own class contained within a **Page Class**. They inherit all the contents of the **Page Class**, such as their elements and methods. Therefore we need to create instant variable for them as well. [Example of how frames are used within the step definition files)[#stepDefIFrameExample]

<a id="sectionFive"></a>
# Manual Tester Workflow

<a id="secFivePartOne"></a>
## Downloading the Test Pack

To start, follow this link [https://caavso.visualstudio.com/_git/Test%20Automation](https://caavso.visualstudio.com/_git/Test%20Automation).  
This will take you to where the project folders are stored. To access them, you must be added to the project by the project owner.

![VSO Clone Repo](../images/VSO.PNG)


Click on clone, found in the top right corner. This will open the link needed to store the repository on your computer. Copy the link.  

Go to your desktop and click start. ![Open CMD from start](../images/cmd.png)

Type CMD into the Start search bar and open the application.   
Inside CMD, cd into your project folder.

![Copy link](../images/project_clone.png)

Type `git clone <project_link>` . This will download the project into the folder.

<a id="secFivePartTwo"></a>
## Running the whole Test Pack


Now go back to Start and find and open Atom.

![Add Project](../images/atom_project.png)

Click Open Folder and find the project you have just cloned.   
It should now look like this.
![Project Open](../images/atom_with_project.png)  

This is the root of the project. When you run the test pack, you must make sure CMD is in the root. It should look like this.

![CMD in Root](../images/cmd_root.png)

Type `cucumber` to run the full Test Pack. This will run every Feature and Scenario through a test window created in Chrome. While the test is running don't use the computer as it may cause the test to lose its focus on chrome and cause the test to fail.

## Running Specific Features/Scenarios.

[Details on which commands to run in CMD can be found here](#consoleCommands).

Sometimes you don't want to run the full test pack and only a specific feature or scenario. To find the name of the Feature you want to run or the Tag for the scenario you want to run, first open Atom and open the Features Folder.

![Atom Features Open](../images/atom_features.png)

1. We are only interested in the Folders that are labelled after the different areas of the system we are testing, which in this Example is EPT and Resource Scheduling. In the future there may be more areas.
   * There is no need to go into the Support folder or the Step Definition Folder.
   * [To run the Specific features see the command here](#consoleCommands)  
 For Example: ![Run a feature](../images/cmd_run_feature.png)
2. This is a Feature Tag. Instead of running the command from 1, you can instead use the [Tag Command](#scenarioCommandLine). This will then run that entire Feature.
3. This will run the Scenario it is above. Use the [Tag Command](#scenarioCommandLine) to run.

<a id="secFivePartThree"></a>
## Generating the Report

[See Reading the Report for more information](#sectionTwo)

After each test is run, a report is generated automatically.
![How to open the report](../images/open_report.png).

The report is written in HTML so it does not make much sense until opened in the browser. There are two ways to do this.   
1. Right click and click 'Copy Project Path'. Paste it into the browser url and it will open the report.
2. ![CMD Report](../images/cmd_report.png) Type report.html in CMD while at the root of the project and it will open the report for you.

**NOTE**: *The report generates the most recent test that has run. If you want to keep the report you will have to move it and save it under a new name or it will be overwritten*.
