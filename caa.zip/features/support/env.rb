require 'dotenv/load'
require 'rubygems'
require 'cucumber'
require 'selenium-webdriver'
require 'rspec'
require 'capybara'
require 'capybara/cucumber'
require 'capybara/rspec'
require 'site_prism'
require 'pry'
require "date"
require 'stamp'

Dotenv.load
Dotenv.overload
$username = ENV["USERNAME"]
$password = ENV["PASSWORD"]

include RSpec::Matchers

Capybara.configure do |config|
  config.default_driver=:selenium
  Capybara.app_host = 'https://lgwdevcrm01.dev.internal/atest/main.aspx'
  Capybara.default_max_wait_time=3
end
World(Capybara)

Capybara.register_driver :selenium do |app|
  options = Selenium::WebDriver::Chrome::Options.new
   options.add_argument('--ignore-certificate-errors')
   options.add_argument('--disable-popup-blocking')
   # options.add_argument('--disable-extensions')
   options.add_argument('--test-type')
   options.add_argument('--start-maximized')
   Capybara::Selenium::Driver.new(app, :browser => :chrome, options: options)
end

Before do |scenario|
  # ---------- Test Variables -------------
  $random_string = ""
  $rescheduled = 0
  $global_data=Hash.new

  #-------Resource Schedulng ---------
  @home = Home.new
  @newCase=AddCase.new
  @mainNavBar=MainNavBar.new
  @service=ServiceActivity.new
  @prepPost = PrepPost.new
  @individual= Individual.new

  # ----Resource Scheduling iFrames-------
  @addCaseIFrame=AddCaseIFrame.new
  @homeIFrame=HomeIframe.new
  @dashboardIFrame=DashboardIframe.new #DashboardIframe is subframe within HomeIframe
  @serviceIFrame = IFrameServiceActivity.new
  @innerServiceIFrame = InnerServiceIFrame.new
  @emailIFrame = EmailIFrame.new
  @emailBodyIFrame = EmailBodyIFrame.new
  @importFile=ImportFile.new
  @importIFrame=ImportIFrame.new
  @dialogIFrame=DialogIFrame.new
  @wizardIFrame=WizardIFrame.new
  @uploadFileFrame=UploadFileFrame.new
  @individualIFrame=IndividualIFrame.new
  @addCaseInlineDialogIFrame=AddCaseInlineDialogIFrame.new
  @individualSubContentIFrame=IndividualSubContentIFrame.new


  #-------EPT------
  @ept=EPTPortal.new
  @safetyReview = SafetyReview.new
  @organisation=Organisation.new
  @aviationEntity=AviationEntity.new
  @privilege=Privilege.new
  @safetyReview=SafetyReview.new
  @addChangeToCurrentPeriod=AddChangeToCurrentPeriod.new
  @oversight=Oversight.new
  @airOperatorCertificate=AirOperatorCertificate.new
  @safetyRisk = SafetyRisk.new
  @SafetyAction = SafetyAction.new
  @keyPersonnel=KeyPersonnel.new
  @publishedArticle=PublishedArticle.new
  @assessmentPrivilege=AssessmentPrivilege.new

  #-----EPT iFrames-------
  @eptIFrame = EPTIFrame.new
  @orgContentIFrame=OrgContentIFrame.new
  @orgSubContentIFrame=OrgSubContentIFrame.new
  @privilegeContentIFrame=PrivilegeContentIFrame.new
  @aviationEntityContentIFrame=AviationEntityContentIFrame.new
  @aviationEntitySubContentIFrame=AviationEntitySubContentIFrame.new
  @aviationInlineDialogIFrame = AviationInlineDialogIFrame.new
  @safetyRiskPageIFrame = SafetyRiskPageIFrame.new
  @safetyRiskButtonIFrame = SafetyRiskButtonIFrame.new
  @safetyRiskDialogIFrame = SafetyRiskInlineDialogIframe.new
  @safetyReviewIFrame=SafetyReviewIFrame.new
  @safetyReviewSubContentIFrame=SafetyReviewSubContentIFrame.new
  @safetyActionIFrame = SafetyActionIFrame.new
  @inlineIFrame = InlineDialogIframe.new
  @subInlineIFrame = InlineDialog1.new
  @safetyEmailBodyIFrame = SafetyEmailBodyIFrame.new
  @addChangeToCurrentPeriodContentIFrame= AddChangeToCurrentPeriodContentIFrame.new
  @oversightContentIFrame=OversightContentIFrame.new
  @airOperatorCertificateIFrame=AirOperatorCertificateIFrame.new
  @newOrganisationWithinSafetyReviewPrimary= NewOrganisationWithinSafetyReviewPrimary.new
  @newOrganisationWithinSafetyReviewApproved= NewOrganisationWithinSafetyReviewApproved.new
  @notesAttachmentIFrame = NotesAttachmentIFrame.new
  @keyPersonnelIFrame=KeyPersonnelIFrame.new
  @publishedArticleIFrame=PublishedArticleIFrame.new
  @assessmentPrivilegeIFrame=AssessmentPrivilegeIFrame.new

end


def wait_for_ajax(timeout = Capybara.default_max_wait_time)
  sleep (timeout) do
    page.evaluate_script 'jQuery.active == 0'
  end
end

After do |scenario|
    if !((page.driver.browser.window_handles.last).eql? page.driver.browser.window_handles.first)
      close_current_window
      switch_to_parent_window
    end
end
# if (scenario.failed?)
#
#   page.save_screenshot("#{scenario.__id__}.png")
#   embed("#{scenario.__id__}.png", "image/png", "Screenshot")
# end

#end
