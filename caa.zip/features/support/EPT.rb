class EPT

# global variables for EPT. Allows you to run tests independently. If this entity contains no safety review, run EPT3 first before running any other test.
$ORGANISATION="autoWLHXFBMXUS"
$PRIVILEGE_NAME="autoCFKIGJKJZK"
$AVIATION_ENTITY="autoBVSJQVJXFJ"

# Variables for @ept21, if run independently.
$safetyTheme = "Governance"
$safetyTitle = "Accountable Manager"
$riskType = "Tolerate"
$likelihood = "Possible"
$impact = "Medium"
$origin = "Aviation Entity"
$outcome = "Improve"
$privilegeType = "Part 145 - Maintenance"

#constants in EPTPortal
AVIATION_ENTITY_FORM_NAME="AVIATION ENTITY"
SAFETY_REVIEW_FORM_NAME="SAFETY REVIEW"

end
