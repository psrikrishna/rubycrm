class Status
  
$UNALLOCATED_CASE=false

  ASSIGN_ACTIVE    =  "Assign (Active)"
  INFORMATION_ACTIVE= "Information (Active)"
  COMPLETE_ACTIVE=    "Complete (Active)"
  ALLOCATED_BY_STATUS="Succeeded"
  IMPORT_SUCCESS="Your data has been submitted for import."
  EMAIL_STATUS = "Draft"
  CATEGORY_FOTI_DROPDOWN="FOTI"
  CATEGORY_FOTI_DISPLAY="FOTI Airplane"
  NOT_SET_STATUS="Not Set"
  UNANNOUNCED = "Unannounced/Out of Hours"
  INTERMEDIATE = "Intermediate 2nd Site"
end
