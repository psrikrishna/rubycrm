# ---------------------- EPT 1 ---------------------

Given("I access the Safety Performance Homepage") do
  @home.load
  @ept.navigate_to_safety_performance
  wait_for_ajax
end

Given("I access the EPT portal") do
  @home.load
  wait_for_ajax
  @ept.navigate_to_ept
  wait_for_ajax
end

And("I add a new organisation") do
  @ept.access_new_organisation
end

And("I complete all the required fields to save new organisation") do |table|
  @data = table.rows_hash

  $global_data=@data

    orgName     = @data["Organisation Name"]
    orgAddress1 = @data["Address Line1"]
    orgAddress2 = @data["Address Line2"]
    orgAddress3 = @data["Address Line3"]
    orgCity     = @data["City"]
    orgCounty   = @data["County"]
    orgPostcode = @data["Postcode"]
    orgCountry  = @data["Country"]
    orgEmail    = @data["Contact method - email"]
    orgPhone    = @data["Contact method - phone"]

    @orgContentIFrame.orgContentIFrame do |frame|
      frame.complete_required_fields_to_save_an_organisation(orgName,orgAddress1, orgAddress2, orgAddress3, orgCity, orgCounty, orgPostcode,orgCountry,orgEmail,orgPhone)
    end

end


And("I complete the remaining required fields to save new organisation") do |table|
  @data = table.rows_hash

  aviationArea=@data["Aviation Area"]
  aviationSector=@data["Aviation Sector"]


  @orgContentIFrame.orgContentIFrame do |frame|
          frame.complete_remaining_fields_to_save_an_organisation(aviationArea,aviationSector)
  end

end

When("I click Save under ribbon bar") do
  @organisation.click_save_below_ribbon
end

When("I click Save under Privilege ribbon bar") do
  within_window $addPrivilegeWindow do
        @privilege.click_save_privilege
  end

end

When("I click Save and Close under Privilege ribbon bar") do
  within_window $addPrivilegeWindow do
        @privilege.click_save_and_close_privilege
  end
end

When("I add a new Privilege") do |table|
    @data = table.rows_hash
    privilegeName =@data["Privilege Name"]
    privilegeDesc =@data["Privilege Description"]
    validFrom     =@data["Valid From"]
    validTo       =@data["Valid To"]
    businessArea  =@data["Business Area"]


          $addPrivilegeWindow = window_opened_by do
              @orgContentIFrame.orgContentIFrame do |frame|
                  frame.open_privilege_window
              end
          end

          $parent_window=page.driver.browser.window_handles.last


          within_window $addPrivilegeWindow do

            # wait = Selenium::WebDriver::Wait.new ignore: Selenium::WebDriver::Error::NoAlertPresentError
            # alert = wait.until { page.driver.browser.switch_to.alert }
            # alert.accept
            #
            @home.accept_alert


                @privilegeContentIFrame.privilegeContentIFrame do |frame|
                    frame.add_a_privilege(privilegeName,privilegeDesc,validFrom,validTo, businessArea)
                end

        end

end



And("I select a type for Privilege Type") do |table|
  @data = table.rows_hash
  privilegeType=@data["Privilege Type"]

    within_window $addPrivilegeWindow do

      @privilegeContentIFrame.privilegeContentIFrame do |frame|
          frame.set_privilege(privilegeType)
      end

    end
end
Then("I can set the Lead Privilege field") do |table|
  @data = table.rows_hash
  leadPrivilege=@data["Lead Privilege"]

  switch_to_parent_window

  @orgContentIFrame.orgContentIFrame do |frame|
    frame.set_lead_privilege(leadPrivilege)
  end

end



When("I click Save in the Organisation page") do
  @orgContentIFrame.orgContentIFrame do |frame|
          frame.click_save_icon
  end
end

# ---------------------- EPT 2 -------------------------------

Given("I add a new aviation entity") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @ept.access_new_aviation_entity
end

Given("I complete all the required fields to save new aviation entity") do |table|
  @data = table.rows_hash
  $global_data=@data

    aviationEntityName     =  @data["Aviation Entity Name"]
    primaryOrganisation     = @data["Primary Organisation"]

        @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |child_frame|
            child_frame.complete_mandatory_fields_to_create_aviation_entity(aviationEntityName, primaryOrganisation)
    end
end

Then("I can validate the aviation entity entered values") do |table|
    @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |child_frame|

              if $global_data["Aviation Entity Name"].eql?"{Random}"
                expect(child_frame.getEntityName).to eq  $AVIATION_ENTITY
              else
              expect(child_frame.getEntityName).to eq   $global_data["Aviation Entity Name"]
              end

              if $global_data["Primary Organisation"].eql?"{Random}"
                expect(child_frame.getOrgName).to eq $ORGANISATION
              else
              expect(child_frame.getOrgName).to eq  $global_data["Primary Organisation"]
              end
    end
end

Then("I can see a code assigned to Aviation Entity") do
  @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |child_frame|
    expect(child_frame.getCaaCode.empty?).to eq false
  end
end

Then("I can see no values for SSI and SMS fields") do
  @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |child_frame|
    expect(child_frame.getSsiCode).to eq "--"
    expect(child_frame.getSmsCode).to eq "--"
  end
end

Then("I can see the following sections") do |table|
  @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |child_frame|
      data = table.raw.flatten

    expect(child_frame.getSafetyAssessmentsSection).to eq data[0]
    expect(child_frame.getSafetyRisksSection).to eq data[1]
    expect(child_frame.getEntPrivilegesSection).to eq data[2]
    expect(child_frame.getOversightTeamSection).to eq data[3]
    expect(child_frame.getActivitiesSection).to eq data[4]
    expect(child_frame.getNotesSection).to eq data[5]
    expect(child_frame.getOrgSection).to eq data[6]
    expect(child_frame.getKeyPersonnelSection).to eq data[7]



    # deprecated systest validations

    # expect(child_frame.getOrgPrivilegesSection).to eq data[2]
    # expect(child_frame.getOrgSection).to eq data[3]
    # expect(child_frame.getOversightTeamSection).to eq data[4]
    # expect(child_frame.getKeyPersonnelSection).to eq data[5]
    # expect(child_frame.getActivitiesSection).to eq data[6]
    # expect(child_frame.getNotesSection).to eq data[7]

  end

end

# ----------------------------- @ept 3 ---------------------------------

And ("I open the aviation entity created in scenario 2") do
  page.driver.browser.navigate.refresh
  wait_for_ajax

  @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|
    frame.search_aviation_entity($AVIATION_ENTITY)
    frame.open_aviation_entity($AVIATION_ENTITY)
  end
end


Given("I complete all the required fields to save new safety review") do |table|

  @data = table.rows_hash
  $safety_review_dates= @data
  review_start_date   = @data["Review Start Date"]
  review_end_date     = @data["Review End Date"]

  # ammDate             = @data["AMM Date"]#ATEST

  # audit date does not exist in new ATEST environment
  # audit_date          = @data["Audit Date"] #systest


    $addSafetyReviewWindow = window_opened_by do
      wait_for_ajax
        @aviationEntitySubContentIFrame.aviationEntitySubContentIFrame do |frame|
            frame.open_safety_review_window
        end
    end

    $parent_window=page.driver.browser.window_handles.last


    within_window $addSafetyReviewWindow do
            wait_for_ajax
            page.driver.browser.navigate.refresh
            wait_for_ajax
          @safetyReviewIFrame.safetyReviewIFrame do |frame|


            frame.add_a_safety_review(review_start_date,review_end_date)

          end

  end

end

And("I click Save under safety review ribbon bar") do
  within_window $addSafetyReviewWindow do
      wait_for_ajax
    @safetyReview.click_save_under_ribbon
  end
end

Then("I can validate the safety review entered values") do |table|


    review_start_date   = $safety_review_dates["Review Start Date"]
    review_end_date     = $safety_review_dates["Review End Date"]
    # audit date no longer exists in new environment ATEST
     # audit_date          = $safety_review_dates["Audit Date"]
     # amm_date            = $safety_review_dates["AMM Date"]

      wait_for_ajax

      within_window $addSafetyReviewWindow do

                @safetyReviewIFrame.safetyReviewIFrame do |frame|
                    expect(frame.getEnteredStartDate).to eq review_start_date
                    expect(frame.getEnteredEndDate).to eq review_end_date
                    # expect(frame.getEnteredAMMDate).to eq amm_date
                end
      end
end

Then("the Active Assessment Privileges table is populated with below entries") do |table|

data = table.raw.flatten

  within_window $addSafetyReviewWindow do
            wait_for_ajax
            @safetyReviewIFrame.safetyReviewIFrame do |frame|
                frame.verifyActiveAssessmentPrivilegesArePopulated
                expect(frame.activeAssessmentPrivilegesEntry1).to eq data[0]
                expect(frame.activeAssessmentPrivilegesEntry2).to eq data[1]
            end

  end
end

Then("the Safety Review Emails and Meetings table is populated with below entries") do |table|

data = table.raw.flatten
within_window $addSafetyReviewWindow do
          wait_for_ajax

          @safetyReviewIFrame.safetyReviewIFrame do |frame|
              expect(frame.getInternalReviewMeeting).to include data[0]
              expect(frame.getAccountableManagerMeeting).to include data[1]
        end

end
end

Then("I click on Aviation Entity link to return to aviation entity page") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  within_window $addSafetyReviewWindow do
          wait_for_ajax
        @safetyReviewIFrame.safetyReviewIFrame do |frame|
            frame.return_to_aviation_entity_link
        end
  end
  switch_to_parent_window

  wait_for_ajax
    @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|
        expect(frame.getFormType).to eq  EPT::AVIATION_ENTITY_FORM_NAME
    end

end

# --------------------- @ept 4 -----------------------------------------------=

Given("I open the safety review created in an earlier test") do
  page.driver.browser.navigate.refresh
  wait_for_ajax

  @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|

    frame.click_safety_review_name

  end
end

# ----------------------- EPT 6 ------------------------------------------------

And("I click to add an approved maintenance contractor") do
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.clickAddMaintenanceContractor
  end
end

And("I add a new ogranisation") do
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.clickAddMaintenanceContractorMagnifyingGlass
    frame.organisationGrid.clickAddOrganisation
    sleep 10
  end

end

# ------------------------- @ ept 15 ----------------------------

 And("I add an oversight team member") do |table|

   @data = table.rows_hash

   oversight_team_member = @data["Oversight Team Member"]
   team_member_role = @data["Role of Team Member"]

     wait_for_ajax


       @safetyReviewIFrame.safetyReviewIFrame do |frame|
              if (frame.getTeamMemberRecordCount)
                $createOversight=true
              else
                $createOversight=false
              end
       end


     if ($createOversight)

         $addOversightTeamMemberWindow = window_opened_by do
                @safetyReviewIFrame.safetyReviewIFrame do |frame|
                 frame.clickAddOversightTeamMember
               end
         end
            wait_for_ajax
           $parent_window=page.driver.browser.window_handles.last

           within_window $addOversightTeamMemberWindow do
             page.driver.browser.navigate.refresh
             wait_for_ajax
                          @oversightContentIFrame.oversightContentIFrame do |frame|
                                wait_for_ajax
                                frame.complete_fields_to_add_oversight_member(oversight_team_member, team_member_role)
                            end
                            @oversight.click_save_and_close
                            wait_for_ajax
           end


           switch_to_parent_window

           wait_for_ajax
   end

 end


 Then("I complete required fields to add new entry for Changes to Current Period") do |table|
   @data = table.rows_hash

   change                 = @data["Change"]
   oversight_team_member  = @data["Oversight Team Member"]
   period                 = @data["Current Period"]
   description            = @data["Description"]
   privilege              = @data["Assessment Privilege"]

     wait_for_ajax

     $addChangeToCurrentPeriodWindow = window_opened_by do
        @safetyReviewIFrame.safetyReviewIFrame do |frame|
         frame.clickAddChangesToCurrentPeriod
       end
     end

     $parent_window=page.driver.browser.window_handles.last

     within_window $addChangeToCurrentPeriodWindow do
       page.driver.browser.navigate.refresh
       wait_for_ajax
         @addChangeToCurrentPeriodContentIFrame.addChangeToCurrentPeriodContentIFrame do |frame|
           frame.complete_required_fields_to_add_changes_to_current_period(change, oversight_team_member, period, description, privilege)
         end
     end

 end



 And("I click Save and Close in the Change to period") do
   within_window $addChangeToCurrentPeriodWindow do
       @addChangeToCurrentPeriod.click_save_and_close
   end
   wait_for_ajax
   switch_to_parent_window
   wait_for_ajax
 end

 And("I open the associated Air Operator Certificate") do
   page.driver.browser.navigate.refresh
  wait_for_ajax
    @safetyReviewIFrame.safetyReviewIFrame do |frame|
     frame.click_aoc_link
   end
 end

 And("I complete required fields to add new entry for CHANGES DURING CURRENT OR NEXT REVIEW PERIOD") do |table|
   @data = table.rows_hash

   change                 = @data["Change"]
   oversight_team_member  = @data["Oversight Team Member"]
   period                 = @data["Next Period"]
   description            = @data["Description"]
   privilege              = @data["Assessment Privilege"]

     wait_for_ajax

     $addChangeToCurrentPeriodWindow = window_opened_by do
       @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
         frame.click_add_change
       end
     end

     $parent_window=page.driver.browser.window_handles.last

     within_window $addChangeToCurrentPeriodWindow do
       page.driver.browser.navigate.refresh
       wait_for_ajax
         @addChangeToCurrentPeriodContentIFrame.addChangeToCurrentPeriodContentIFrame do |frame|
           frame.complete_required_fields_to_add_changes_to_current_period(change, oversight_team_member, period, description, privilege)
         end
     end

 end

 And("I can see both the entries for current and next period in Air Operator Certificate page") do
   @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
     expect(frame.number_of_entries_in_changes_table).to eq 2
   end
 end

 And("I can see both the entries for current and next period in Safety Review page") do
    @safetyReviewIFrame.safetyReviewIFrame do |frame|
      expect(frame.number_of_entries_in_current_changes_table).to eq 1
      expect(frame.number_of_entries_in_next_changes_table).to eq 1
    end
 end

 And("I scroll up the screen and click on the link displayed in the Safety Review field") do
     @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
         frame.click_link_to_safety_review
     end

     wait_for_ajax

 end

 Then("the system returns me to the Active Safety Review") do
   wait_for_ajax
   page.driver.browser.navigate.refresh

     @safetyReviewIFrame.safetyReviewIFrame do |frame|
         expect(frame.getFormType).to eq  EPT::SAFETY_REVIEW_FORM_NAME
     end
 end

 Then("the Test Change I have just entered is visible") do
     # do something
 end


Then /^I can change the safety review status to \"([^\"]*)\"$/ do |status|
    wait_for_ajax
    @safetyReviewIFrame.safetyReviewIFrame do |frame|
        frame.changeStatusTo(status)
    end

end

Then("I can save the safety review by clicking bottom save icon") do
  wait_for_ajax
    @safetyReviewIFrame.safetyReviewIFrame do |frame|
        frame.click_save_in_footer
      end
      wait_for_ajax
end

# -------------------------- @ept 16b ----------------------------------

Given("I select the following entries for Air Operator Certificate") do |table|

     @data = table.rows_hash
     $aocData=@data

  complexity_rating                       =  @data["Complexity Rating"]

  proposed_future_oversight               =  @data["Proposed Future Oversight"]
  proposed_future_oversight_rationale     =  @data["Proposed Future Oversight Rationale"]
  date_of_entry                           =  @data["Date of Entry"]
  confirmed_future_oversight              =  @data["Confirmed Future Oversight"]
  approval_comments                       =  @data["Approval Comments"]
  approval_date                           =  @data["Approval Date"]
  sector_manager                          =  @data["Sector Manager"]

  wait_for_ajax

          @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
              frame.add_aoc_fields(complexity_rating, proposed_future_oversight,
                proposed_future_oversight_rationale,date_of_entry,confirmed_future_oversight,
              approval_comments,approval_date, sector_manager )
          end

end

Given("I can save the Air Operator Ceritificate changes by clicking bottom save icon") do
  wait_for_ajax
    @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
        frame.click_save_in_footer
      end
      wait_for_ajax
end

Then("I can view and verify the following fields populated unser Safety Review") do |table|
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
      expect(frame.getComplexityRating).to eq $aocData['Complexity Rating']
      expect(frame.getProposedOversight).to eq $aocData['Proposed Future Oversight']
  end
end

# --------------------- EPT 19a -------------------------------

And("I click the Add New Safety Risk plus button") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|
     $addSafetyRiskWindow = window_opened_by do
       frame.click_safety_risk_plus_button
     end
  end

  # @inlineIFrame.dialogIFrame do |frame|
  #   $addSafetyRiskWindow = window_opened_by do
  #     frame.click_new_safety_risk_button
  #   end
  # end
end

When("I fill the the Safety Risk with the following data") do |table|

  $safetyRiskData   = table.rows_hash
  # $title            = $safetyRiskData["Title"]
  $origin           = $safetyRiskData["Origin"]
  $event            = $safetyRiskData["Event"]
  $cause            = $safetyRiskData["Cause"]
  $effect           = $safetyRiskData["Effect"]
  $descriptor       = $safetyRiskData["Descriptor"]
  $likelihood       = $safetyRiskData["Likelihood"]
  $impact           = $safetyRiskData["Impact"]
  $riskType         = $safetyRiskData["Risk Type"]
  $outcome          = $safetyRiskData["Outcome"]
  $options          = $safetyRiskData["Options"]
  $privilegeType    = $safetyRiskData["Privilege Type"]
  $related          = $safetyRiskData["Related"]
  $confirmedOn      = $safetyRiskData["Confirmed On"]
  $confirmed        = $safetyRiskData["Confirmed"]
  $safetyTheme      = $safetyRiskData["Safety Theme"]
  $safetyTitle      = $safetyRiskData["Safety Title"]

  within_window $addSafetyRiskWindow do

  wait_for_ajax
    @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
      frame.inputRiskData($origin, $event, $cause, $effect, $descriptor, $likelihood, $impact, $riskType, $outcome, $options, $privilegeType, $confirmedOn, $AVIATION_ENTITY, $safetyTheme, $safetyTitle)

    end
    @safetyRisk.clickSaveButton

  end
end

Then("I return to the main page and see the new Safety Risk I have created") do
  wait_for_ajax
  within_window $addSafetyRiskWindow do
    @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
      frame.clickAviationEntityTitle
    end
    close_current_window
  end

  page.driver.browser.navigate.refresh
  wait_for_ajax
  @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|
    frame.safetyRiskSortByModifiedOn
    expect(frame.safetyRiskTitle.text).to eq $safetyTheme + " - " + $safetyTitle
    expect(frame.safetyRiskEntity.text).to eq $AVIATION_ENTITY
    expect(frame.safetyRiskLikelihood.text).to eq $likelihood
    expect(frame.safetyRiskImpact.text).to eq $impact
    expect(frame.safetyRiskDesiredOutcome.text).to eq $outcome
    expect(frame.safetyRiskAssociatedAction.text).to eq "No"
    expect(frame.safetyRiskOrigin.text).to eq $origin

  end
end



# ----------------------- EPT 19b ------------------------------------------------------------

And("I select the Add new Safety Risk Button") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
    @safetyRiskButtonIFrame.safetyRiskButtonIFrame do |child_frame|
      $addSafetyRiskWindow = window_opened_by do
        child_frame.click_safety_risk_button
      end
    end
  end
end

Then("I return to the Safety Review and see the new Safety Risk I have created") do
  wait_for_ajax
  within_window $addSafetyRiskWindow do
    @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
      frame.clickAviationEntityTitle
    end
    close_current_window
  end

  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.safetyRiskSortByModifiedOn
    frame.safetyRiskSortByModifiedOn
    expect(frame.safetyRiskTitle.text).to eq $safetyTheme + " - " + $safetyTitle
    expect(frame.safetyRiskType.text).to eq $riskType
    expect(frame.safetyRiskLikelihood.text).to eq $likelihood
    expect(frame.safetyRiskImpact.text).to eq $impact
    expect(frame.safetyRiskOutcome.text).to eq $outcome
    expect(frame.safetyRiskAssociatedAction.text).to eq "No"
    expect(frame.safetyRiskOrigin.text).to eq $origin
    expect(frame.safetyRiskPrivilegeType.text).to eq $privilegeType
  end
end


# -------------------- @ept 20 -------------------------------------

And("I select a safety risk") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @aviationEntityContentIFrame.aviationEntityContentIFrame do |frame|
    frame.safetyRiskSortByModifiedOn
    frame.clickSafetyRiskTitle
  end
end

# ------------------------- @ept 21 ----------------------------------------------------------------------------

And("I select the safety risk created in a previous scenario") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.safetyRiskSortByModifiedOn
    # expect(frame.safetyRiskTitle.text).to eq $safetyTheme + " - " + $safetyTitle
    # expect(frame.safetyRiskType.text).to eq $riskType
    # expect(frame.safetyRiskLikelihood.text).to eq $likelihood
    # expect(frame.safetyRiskImpact.text).to eq $impact
    # expect(frame.safetyRiskOutcome.text).to eq $outcome
    # expect(frame.safetyRiskOrigin.text).to eq $origin
    # expect(frame.safetyRiskPrivilegeType.text).to eq $privilegeType
    frame.safetyRiskTitle.click
  end
end

And("I add a safety action") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    $addSafetyActionWindow = window_opened_by do
      frame.addSafetyAction
    end
  end
end

When("I fill in the safety action with the following data") do |table|
  $action_data = table.rows_hash
  $actionTitle = $action_data["Action Title"]
  $actionDescription = $action_data["Action Description"]
  $raisedBy = $action_data["Risk Raised By"]
  $actionOwner = $action_data["Action Owner"]
  $targetDate  = $action_data["Target Completion"]
  wait_for_ajax

  within_window $addSafetyActionWindow do
    page.driver.browser.navigate.refresh
    wait_for_ajax
    @safetyActionIFrame.safetyActionIFrame do |frame|
      frame.inputSafetyActionData($actionTitle, $actionDescription, $raisedBy, $actionOwner, $targetDate)
      frame.click_save_in_footer
      wait_for_ajax
    end
    close_current_window
  end
end

Then("I should find the safety actions grid populated with the new safety action") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    frame.safetyActionSortBy
    expect(frame.safetyActionTitle.text).to eq $actionTitle
    expect(frame.safetyActionTargetCompletionDate.text).to eq $targetDate
    expect(frame.safetyActionConfirmed.text).to eq "Yes"
    expect(frame.safetyActionActionOwner.text).to eq $actionOwner
  end
end

# ------------------------ @ ept 22 ----------------------------------------------------------

And("I select the safety action created in a previous scenario") do

  wait_for_ajax

  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    frame.safetyActionSortBy
    frame.clickSafetyActionTitle
    wait_for_ajax
  end
end

When("I modify the contents of the safety action") do |table|
  page.driver.browser.navigate.refresh
  wait_for_ajax
  $action_data = table.rows_hash
  $actionTitle = $action_data["Action Title"]
  $actionDescription = $action_data["Action Description"]
  $raisedBy = $action_data["Risk Raised By"]
  $actionOwner = $action_data["Action Owner"]
  $targetDate  = $action_data["Target Completion"]

  @safetyActionIFrame.safetyActionIFrame do |frame|
    frame.inputSafetyActionData($actionTitle, $actionDescription, $raisedBy, $actionOwner, $targetDate)
    frame.click_safety_risk_title
  end
end


# ------------------- @ept 23 --------------------------------------

When("I mark the safety action as complete") do
  @SafetyAction.click_mark_complete
  wait_for_ajax
end

Then("I should no longer see the safety action displayed") do
  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    expect(frame.emptySafetyActionTable.text).to eq "No Safety Action records found."
  end
end

# --------------------- @ 24 --------------------------------------

When("I modify the the Safety Risk with the following data") do |table|
  $safetyRiskData   = table.rows_hash
  # $title            = $safetyRiskData["Title"]
  $origin           = $safetyRiskData["Origin"]
  $event            = $safetyRiskData["Event"]
  $cause            = $safetyRiskData["Cause"]
  $effect           = $safetyRiskData["Effect"]
  $descriptor       = $safetyRiskData["Descriptor"]
  $likelihood       = $safetyRiskData["Likelihood"]
  $impact           = $safetyRiskData["Impact"]
  $riskType         = $safetyRiskData["Risk Type"]
  $outcome          = $safetyRiskData["Outcome"]
  $options          = $safetyRiskData["Options"]
  $privilegeType    = $safetyRiskData["Privilege Type"]
  $related          = $safetyRiskData["Related"]
  $confirmedOn      = $safetyRiskData["Confirmed On"]
  $confirmed        = $safetyRiskData["Confirmed"]
  $safetyTheme      = $safetyRiskData["Safety Theme"]
  $safetyTitle      = $safetyRiskData["Safety Title"]


  wait_for_ajax
    @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
      frame.inputRiskData($origin, $event, $cause, $effect, $descriptor, $likelihood, $impact, $riskType, $outcome, $options, $privilegeType, $confirmedOn, $AVIATION_ENTITY, $safetyTheme, $safetyTitle)
      frame.clickFooterSave

    end


end

Then("I return to the Safety Review and see the modified data") do

  wait_for_ajax
  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    frame.click_safety_review_link
  end

  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.safetyRiskSortByModifiedOn
    frame.safetyRiskSortByModifiedOn
    expect(frame.safetyRiskTitle.text).to eq $safetyTheme + " - " + $safetyTitle
    expect(frame.safetyRiskType.text).to eq $riskType
    expect(frame.safetyRiskLikelihood.text).to eq $likelihood
    expect(frame.safetyRiskImpact.text).to eq $impact
    expect(frame.safetyRiskOutcome.text).to eq $outcome
    expect(frame.safetyRiskAssociatedAction.text).to eq "Yes"
    expect(frame.safetyRiskOrigin.text).to eq $origin
    expect(frame.safetyRiskPrivilegeType.text).to eq $privilegeType
  end
end

# --------------------- @ept 25 ----------------------

When("I deactivate the safety risk") do
  @safetyRisk.deactivate_safety_risk
  sleep 2
  # page.driver.browser.action.send_keys(:return).perform
  page.driver.browser.switch_to.alert.accept
  wait_for_ajax
  # @safetyRiskDialogIFrame.inlineDialogIFrame do |frame|
  #   wait_for_ajax
  #   frame.click_delete_button

  # end
  @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
    frame.click_safety_review_link
  end
end

Then("I should no longer see the safety risk displayed") do
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    expect(frame.safetyRiskEmptyTable.text).to eq "No Safety Risk records found."
  end
end



# ------------------------ Run the pre-Accountable Manager workflow -------------------------------------------

And("I click run workflow") do
  wait_for_ajax
  @safetyReview.startWorkflow

end

And("I add the Pre Accountable Manager Email") do
  @inlineIFrame.dialogIFrame do |frame|
    frame.clickPreAccountCheckbox
    @addEmailWindow = window_opened_by do
      frame.clickAddButton
    end
  end
  within_window @addEmailWindow do
    wait_for_ajax
    @safetyReview.selectConfirmDropdown("Yes")
    @safetyReview.clickNextButton
    @safetyReview.clickNextButton
    wait_for_ajax
    @safetyReview.clickFinishButton
  end

end

And("I open the created Pre Accountable Manager Email") do |table|
  @accountable_data = table.rows_hash
  $safetyReviewStartDate = @accountable_data["Review Start Date"]
  $safetyReviewEndDate = @accountable_data["Review End Date"]
  page.driver.browser.navigate.refresh
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    expect(frame.preAccountEmailLink.text).to eq "Pre Accountable Manager Meeting for #{$AVIATION_ENTITY} Safety Review #{$safetyReviewStartDate} - #{$safetyReviewEndDate}"
    frame.openPreAccountEmail
  end
end

And("I add a date to the email body") do
  @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
    @safetyEmailBodyIFrame.safetyEmailBodyIFrame do |child_frame|
      child_frame.appendEmailBody("As part of the CAA's Performance Based Oversight Programme, this is to confirm that a meeting has been arranged #{$safetyReviewEndDate}")
    end
  end
end

Then("I save the email and return to the main active safety review screen") do
  @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
    parent_frame.saveEmail
    parent_frame.clickRegardingEmailLink
  end
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
    expect(parent_frame.aviationEntityTitle.text).to eq $AVIATION_ENTITY
    expect(parent_frame.getEnteredStartDate).to eq  $safetyReviewStartDate
    expect(parent_frame.getEnteredEndDate).to eq  $safetyReviewEndDate
  end
end

#--------------------- EPT 27 --------------------------------

And("I add the Post AM Meeting Email") do
  @inlineIFrame.dialogIFrame do |frame|
    # frame.clickPostAccountCheckbox
    @addEmailWindow = window_opened_by do
      frame.clickAddButton
    end
  end
  within_window @addEmailWindow do
    wait_for_ajax
    @safetyReview.selectConfirmDropdown("Yes")
    @safetyReview.clickNextButton
    @safetyReview.clickNextButton
    wait_for_ajax
    @safetyReview.clickFinishButton
  end
end

And("I open the created Post Accountable Manager Email") do |table|
  @accountable_data = table.rows_hash
  $safetyReviewStartDate = @accountable_data["Review Start Date"]
  $safetyReviewEndDate = @accountable_data["Review End Date"]
  page.driver.browser.navigate.refresh
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    expect(frame.postAccountEmailLink.text).to eq "Post Accountable Manager Meeting for #{$AVIATION_ENTITY} Safety Review #{$safetyReviewStartDate} - #{$safetyReviewEndDate}"
    frame.openPostAccountEmail
  end
end

# ------------------------- EPT 28 -----------------------------------

And("I add some text to the notes section") do |table|
  @note_data = table.rows_hash
  note = @note_data["Notes Text"]
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    wait_for_ajax
    frame.open_notes
    frame.add_text_to_notes(note)
  end
end

When("I attach a PDF") do
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.click_attach_button
    wait_for_ajax
    @notesAttachmentIFrame.notesAttachmentIFrame do |attachment_frame|
      attachment_frame.upload_test_pdf
    end
    frame.click_done_button
  end
end

Then("I should see the note") do |table|
  @note_verification_data = table.rows_hash
  fileName = @note_verification_data["Attachment Name"]
  note     = @note_verification_data["Notes Text"]
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    expect(frame.createdAttachmentLink[0].value).to eq fileName
  end
end

# ----------------------------- EPT 29 -------------------------------------

And("I enter enter some data into the Manager Sign Off Section") do |table|
  @data = table.rows_hash
  $signOffData = @data["Sign Off Data"]
  $signOffDate = @data["Sign Off Date"]
  wait_for_ajax
@safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.addDataOmEntity($signOffData, $signOffDate)
  end
end

Then("I click the save icon in the footer") do
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.click_save_in_footer
    wait_for_ajax

  end
end

And("I can see the OM data has been saved") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    expect(frame.omEntityInputSavedSpan.text).to eq $signOffData
    expect(frame.omEntityDateSavedSpan.text).to eq $signOffDate
  end
end

# -------------------------- EPT 30 ------------------------
When("I enter some data into the SM Sign Off Section") do |table|
  @data = table.rows_hash
  $approval  = @data["SM Approval"]
  $date      = @data["SM Approval Date"]
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |frame|
    frame.addSMData($approval, $date)
  end
end

And("I can see the SM data has been saved") do
  page.driver.browser.navigate.refresh
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |frame|

    expect(frame.smApprovalSavedTextSpan.text).to eq $approval
    expect(frame.smApprovalDateSavedSpan.text).to eq $date

    frame.addSMData(approval, date)

  end
end


# ---------------------- EPT 31 ---------------------------

When("I add text to the detail inputs") do |table|
  @data = table.rows_hash
  overviewText = @data["Overview Text"]
  chartURL     = @data["Chart URL"]
  wait_for_ajax
  @safetyReviewIFrame.safetyReviewIFrame do |frame|

    frame.addTextOverviewAndOrganisationalChart(overviewText, chartURL)
  end
end

# --------------- EPT 36 ---------------

And("I access the entity documents page") do
  @mainNavBar.accessEntityDocuments
  sleep 5
end

    And("I complete all the required fields to save new Approved Maintenance Contractors") do |table|

        @safetyReviewIFrame.safetyReviewIFrame do |frame|
          frame.complete_fields_to_add_approved_maintenance_contractor($ORGANISATION)
        end

    end


And("I complete all the required fields to save new Primary Sub-Contractors") do |table|
      @safetyReviewIFrame.safetyReviewIFrame do |frame|
            frame.complete_fields_to_add_primary_subcontractor($ORGANISATION)
      end


end

Then("I validate the entered approved maintenance contractor value") do

  page.driver.browser.navigate.refresh
  wait_for_ajax
        @safetyReviewIFrame.safetyReviewIFrame do |frame|

          expect(frame.getEnteredApprovedMaintenanceContractor).to eq $ORGANISATION

        end
end

Then("I validate the entered primary subcontractor value") do
          @safetyReviewIFrame.safetyReviewIFrame do |frame|
                expect(frame.getEnteredPrimarySubContractor).to eq $ORGANISATION
        end
end

Then("I validate the entered approved maintenance contractor value with new organisation") do

  page.driver.browser.navigate.refresh
  wait_for_ajax
        @safetyReviewIFrame.safetyReviewIFrame do |frame|

          expect(frame.getEnteredApprovedMaintenanceContractor).to eq $INLINE_ORGANISATION

        end
end

Then("I validate the entered primary subcontractor value with new organisation") do
          @safetyReviewIFrame.safetyReviewIFrame do |frame|
                expect(frame.getEnteredPrimarySubContractor).to eq $INLINE_ORGANISATION
        end
end



And("I create a new Approved Maintenance Contractors by creating new organisation")do |table|

      @data = table.rows_hash
      org         = @data["Organisation Name"]
      phone       = @data["Main Phone"]
      street      = @data["Street 1"]
      city        = @data["City"]
      postcode    = @data["Postal Code"]


                @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
                      parent_frame.add_new_organisation_for_approved_maintenance
                end

                @newOrganisationWithinSafetyReviewApproved.newOrganisationWithinSafetyReviewApproved do |child_frame|
                      child_frame.complete_new_inline_organsation(org, phone, street, city, postcode)
                end

                @safetyReview.click_save_for_inline_org_approved
  end

  And("I create a new Primary Sub-Contractors by creating new organisation")do |table|

        @data = table.rows_hash
        org         = @data["Organisation Name"]
        phone       = @data["Main Phone"]
        street      = @data["Street 1"]
        city        = @data["City"]
        postcode    = @data["Postal Code"]


                  @safetyReviewIFrame.safetyReviewIFrame do |parent_frame|
                        parent_frame.add_new_organisation_for_primary_subcontractor
                  end

                  @newOrganisationWithinSafetyReviewPrimary.newOrganisationWithinSafetyReviewPrimary do |child_frame|
                        child_frame.complete_new_inline_organsation(org, phone, street, city, postcode)
                  end

                  @safetyReview.click_save_for_inline_org_primary

    end

    When("I search for the Individual")do

    @individualSubContentIFrame.individualSubContentIFrame do |frame|
          frame.search_for_individual($ind_first_name, $ind_surname)
    end

    end


    Then("I can view the details of the Individual")do

    @individualIFrame.individualIFrame do |frame|
          expect(frame.getEnterdName).to eq $ind_first_name + ' '+ $ind_surname
    end

    end


    Then("I add the individual created as a key personnel team member")do |table|

          @data = table.rows_hash
          role  = @data["Role"]


                    $addKeyPersonnelWindow = window_opened_by do
                           @safetyReviewIFrame.safetyReviewIFrame do |frame|
                            frame.clickAddKeyPersonnelTeamMember
                          end
                    end

          wait_for_ajax
          $parent_window=page.driver.browser.window_handles.last

                    within_window $addKeyPersonnelWindow do

                        page.driver.browser.navigate.refresh
                        wait_for_ajax

                        @keyPersonnelIFrame.keyPersonnelIFrame do |parent_frame|
                              parent_frame.add_key_personnel($ind_first_name + ' '+ $ind_surname, role)
                        end

                        @keyPersonnel.click_save_and_close

                    end

  end

  Then("I validate the entered key personnel value") do

                @safetyReviewIFrame.safetyReviewIFrame do |frame|
                  expect(frame.getEnteredKeyPersonnel).to eq $ind_first_name+' '+$ind_surname
                end
  end

  Then("I can view the guidance notes") do
    @safetyReviewIFrame.safetyReviewIFrame do |frame|
      expect(frame.check_guidance_notes).to eq true

    end
  end

  Given /^I can open the (.*) AOC Guidance Notes$/ do |guidance_notes|

          $notesWindow = window_opened_by do
            @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
                      frame.open_guidance_notes(guidance_notes)
            end
          end
  end

  Given /^I can open the (.*) Safety Risk Guidance Notes$/ do |guidance_notes|
  $riskWindow = window_opened_by do
    @safetyRiskPageIFrame.safetyRiskIFrame do |frame|
              frame.open_guidance_notes(guidance_notes)
    end
  end
end

When("I close the AOC Guidance Notes") do
  within_window $notesWindow do
      close_current_window
  end

  switch_to_parent_window
end

When("I close the Safety Risk Guidance Notes") do
  within_window $riskWindow do
      close_current_window
  end

  switch_to_parent_window
end

Then("I move to the next page of the AOC Guidance Notes") do
  @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
            frame.navigate_next_page
  end
end

Then("I can move back to page one of the AOC Guidance Notes") do
  @airOperatorCertificateIFrame.airOperatorCertificateIFrame do |frame|
            frame.navigate_previous_page
  end
end

And /^I access the articles section$/ do
  @mainNavBar.access_articles_tab
end

  Given /^I can open the (.*) Published Article$/ do |article|

      $articlesWindow = window_opened_by do

        page.driver.browser.navigate.refresh
        wait_for_ajax

              @publishedArticleIFrame.publishedArticleIFrame do |frame|
                      frame.open_published_article
              end

      end
  end

  When("I close the Published Article") do
    within_window $articlesWindow do
        close_current_window
    end

    switch_to_parent_window
  end

  Then /^I verify the status is set to \"([^\"]*)\"$/ do |status|

    page.driver.browser.navigate.refresh
    wait_for_ajax

      @aviationEntityContentIFrame.aviationEntityContentIFrame do |child_frame|
        expect(child_frame.getFirstSafetyReviewStatus).to eq status
      end
  end

Then("I deactivate the safety review") do
      @aviationEntity.deactivateSafetyReview
end

And("I complete all the required fields to save new assessment privilege") do |table|
  @data = table.rows_hash
  type         = @data["Privilege Type"]
  desc          =@data["Description"]
  member       = @data["Oversight Team Member"]
  manager      = @data["Sector Manager"]


  $newAssessmentPrivilegeWindow = window_opened_by do

          @safetyReviewIFrame.safetyReviewIFrame do |frame|
                  frame.open_new_assessment_privilege
          end

  end

  within_window   $newAssessmentPrivilegeWindow do

            page.driver.browser.navigate.refresh
            wait_for_ajax

            @assessmentPrivilegeIFrame.assessmentPrivilegeIFrame do |parent_frame|
                  parent_frame.add_assessment_privilege(type, desc, member, manager)
            end

            @assessmentPrivilege.click_save_and_close
            wait_for_ajax
    end

    switch_to_parent_window
    wait_for_ajax

end

Then("the Active Assessment Privileges table is updated with below entries") do |table|

data = table.raw.flatten

page.driver.browser.navigate.refresh
wait_for_ajax

  within_window $addSafetyReviewWindow do
            wait_for_ajax
            @safetyReviewIFrame.safetyReviewIFrame do |frame|
                frame.verifyActiveAssessmentPrivilegesArePopulated
                expect(frame.activeAssessmentPrivilegesEntry1).to eq data[0]
                expect(frame.activeAssessmentPrivilegesEntry2).to include data[1]
                expect(frame.activeAssessmentPrivilegesEntry3).to eq data[2]
            end

  end
end
