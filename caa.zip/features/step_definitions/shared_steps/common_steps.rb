def generate_random_string(x)
  "auto" + (0...x).map { (65 + rand(26)).chr }.join
end

def close_current_window
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  page.driver.browser.close
end

def switch_to_parent_window
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
end
