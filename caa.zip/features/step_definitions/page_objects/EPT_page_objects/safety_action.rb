class SafetyAction < SitePrism::Page

  element :markComplete, 'li[title*="Mark Complete"] > span > a'

  element :titleLabel, "#subject_c > span > span"
  element :titleInput, "#subject_i"

  element :descriptionLabel, "#caa_description_c > span > span"
  element :descriptionTextarea, "#caa_description_i"

  element :riskRaisedByLabel, "#caa_actionowner_c > span > span"
  element :riskRaisedByDropdown, "#caa_actionowner_i"

  element :actionOwnerLabel, "#ownerid_c > span > span"
  element :actionOwnerInput, "#ownerid_ledit"
  element :filledActionOwnerInput, '#ownerid > div[jawsreadlabel="ownerid_c"] > span:nth-child(1)'

  element :targetCompletionDateLabel, "#scheduledend_c > span > span"
  element :targetCompletionDateInput, "#scheduledend_i #DateInput"

  #only need to click the label to turn confirmed to yes
  element :confirmedLabel, "#caa_confirmed_c > span > span"
  element :confirmedSpan, '#caa_confirmed > div[jawsreadlabel="caa_confirmed_c"] > span'

  #save is within SafetyActionIFrame
  element :footerSave, "#savefooter_statuscontrol"
  element :safetyRiskTitle, '#caa_safetyriskid > div > span[role="link"]'

  def click_save_in_footer
    footerSave.click
  end

  def inputSafetyActionData(title, description, raisedBy, owner, date)
    wait_for_titleLabel(10)
    titleLabel.click
    titleInput.set title

    descriptionLabel.click
    descriptionTextarea.set description

    riskRaisedByLabel.click
    riskRaisedByDropdown.select raisedBy

    if has_filledActionOwnerInput?
      puts "Already Filled"
    else
      actionOwnerLabel.click
      actionOwnerInput.set owner
      page.driver.browser.action.send_keys(:return).perform
      sleep 1
      page.driver.browser.action.send_keys(:return).perform
      wait_for_ajax
    end

    wait_for_targetCompletionDateLabel(10)
    targetCompletionDateLabel.click
    targetCompletionDateInput.set date

    if confirmedSpan.text == "No"
      confirmedLabel.click
    end

    wait_for_ajax

  end

  def click_safety_risk_title
    wait_for_safetyRiskTitle(10)
    safetyRiskTitle.click
  end

  def click_mark_complete
    wait_for_markComplete(10)
    markComplete.click
  end


end


class SafetyActionIFrame < SitePrism::Page
  iframe :safetyActionIFrame, SafetyAction, "contentIFrame0"
end
