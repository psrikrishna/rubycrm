class EPTPortal < SitePrism::Page

  element :mainRibbon, "#Tab1 .navTabButtonArrowDown"
  element :safetyPerformanceSecondaryRibbon, ".navActionButtonContainer[title='Safety Performance']"
  element :safetyPerformanceDropDown, "#TabRS .navTabButtonLink .navTabButtonArrowDown"
  element :organisationsSubMenu, "#nav_accts.navActionButton[title='Organisations']"
  element :aviationEntitySubMenu, "#nav_accts.navActionButton[title='Aviation']"
  element :newRecordOrganisation, "li[id*='NewRecord']"


  def navigate_to_safety_performance
    wait_for_ajax

    wait_for_mainRibbon(10)
    mainRibbon.click
    wait_for_ajax

    wait_for_safetyPerformanceSecondaryRibbon(10)
    safetyPerformanceSecondaryRibbon.click
    wait_for_ajax
  end

  def access_new_organisation

    wait_for_safetyPerformanceDropDown(10)
    safetyPerformanceDropDown.click
    wait_for_ajax

    organisationsSubMenu.click
    wait_for_ajax
#    page.driver.browser.action.move_to(newRecordOrganisation.native).click.perform
    newRecordOrganisation.click
    wait_for_ajax
    page.driver.browser.navigate.refresh
    wait_for_ajax
  end

  def access_new_aviation_entity
    page.driver.browser.action.move_to(newRecordOrganisation.native).click.perform
    wait_for_ajax
    newRecordOrganisation.click
    wait_for_ajax
  end

end

class EPTIFrame < SitePrism::Page
  iframe :eptIFrame, EPTPortal, "contentIFrame0"
end
