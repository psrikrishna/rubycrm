class KeyPersonnel < SitePrism::Page

element :individualLabel, "#caa_individualid_c"
element :individual, "#caa_individualid_ledit"

element :roleLabel, "#caa_keypersonnelroleid_c"
element :role, "#caa_keypersonnelroleid_ledit"

element :saveAndClose, "span[command*='SaveAndClosePrimary']"

def add_key_personnel (individual_kp, role_kp)
    individualLabel.click
    wait_for_ajax
    individual.set individual_kp
    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

    roleLabel.click
    wait_for_ajax
    role.set role_kp
    page.driver.browser.action.send_keys(:tab).perform
    wait_for_ajax

end

def click_save_and_close
    saveAndClose.click
    wait_for_ajax
end

end
class KeyPersonnelIFrame < SitePrism::Page
  iframe :keyPersonnelIFrame, KeyPersonnel, '#contentIFrame0'
end
