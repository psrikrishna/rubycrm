class PublishedArticle < SitePrism::Page
  element :articleAOCRotartWing, "a[title='Complexity Oversight Baseline - AOC Rotary Wing']"

def open_published_article
  wait_for_articleAOCRotartWing(10)
  page.driver.browser.action.move_to(articleAOCRotartWing.native).click.perform
  articleAOCRotartWing.click
end

end


class PublishedArticleIFrame < SitePrism::Page
  iframe :publishedArticleIFrame, PublishedArticle, '#contentIFrame0'
end
# class PublishedArticleSubContentIFrame < SitePrism::Page
#   iframe :publishedArticleSubContentIFrame, PublishedArticle, '#contentIFrame1'
# end
