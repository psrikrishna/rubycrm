class AddChangeToCurrentPeriod < SitePrism::Page

  element :change, "#caa_name_i"
  element :changeLabel, "#caa_name_i"

  element :teamMember, "#caa_safetyoversightteammemberid_ledit"
  element :teamMemberLabel, "#caa_safetyoversightteammemberid_c"

  element :period, "select[id='caa_period_i']"
  element :periodLabel, "#caa_period_c"

  element :description, "#caa_comment_i"
  element :descriptionLabel, "#caa_comment_c>span>span"

  element :assessmentPrivilegeLabel, "#caa_safetyassessmentprivilegeid_c > span > span"
  element :assessmentPrivilegeInput, "#caa_safetyassessmentprivilegeid_ledit"
  element :assessmentPrivilegeSpan, '#caa_safetyassessmentprivilegeid > div > span:nth-child(1)'

  element :saveAndClose, "li[id*='SaveAndClose']"



  def complete_required_fields_to_add_changes_to_current_period(var_change, oversight_team_member, var_period, var_description, assessment_privilege)
    changeLabel.click
    change.set var_change

    teamMemberLabel.click
    wait_for_ajax
    teamMember.set oversight_team_member

    periodLabel.click
    wait_for_ajax
    period.select(var_period)

    descriptionLabel.click
    wait_for_ajax
    description.set var_description

    if has_assessmentPrivilegeSpan?
      print "Inside Privilege"
    else
      wait_for_assessmentPrivilegeLabel(10)
      assessmentPrivilegeLabel.click
      assessmentPrivilegeInput.set assessment_privilege
    end
  end

  def click_save_and_close
    saveAndClose.click
    wait_for_ajax
  end


end
class AddChangeToCurrentPeriodContentIFrame < SitePrism::Page
  iframe :addChangeToCurrentPeriodContentIFrame, AddChangeToCurrentPeriod, '#contentIFrame0'
end
