#require 'dotenv/load'

class Home < SitePrism::Page



  set_url "https://Krishna.Peddinti:Getaway76!@lgwdevcrm01.dev.internal/atest/main.aspx"
# set_url "https://Krishna.Peddinti:Getaway76!@lgwdevcrm01.dev.internal/atest/main.aspx"

#set_url "https://Nick.Rothera:Automation123@lgwdevcrm01.dev.internal/atest/main.aspx"

  element :addCaseButton, '#CasesImWorkingOn_addImageButtonImage'
  element :homeIcon, "#TabHome"
  element :myCasesSearchTextbox, '#CasesImWorkingOn_findCriteria'
  element :unallocatedCasesSearchTextbox, '#UnallocatedSchedulingCases_findCriteria'
  element :allocatedCasesSearchTextbox,'#Component4675953_findCriteria'
  element :searchRecordsInput, "#CasesImWorkingOn_findCriteria"
  element :divContainingIframe, "body > div:nth-child(8)"
  element :auditCase, 'table[summary="This list contains 1 Case records."]  > tbody > tr > td:nth-child(2) > nobr > a'

  element :createdOnForAllocatedSchedulingCases, "#Component4675953_gridBar > tbody > tr > th:nth-child(2) > table > tbody > tr > td > a"
  element :refreshGrid, "#grid_refresh"
  element :statusOfImportedFileCompleted, "#gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(3) > nobr[title='Completed']"

  element :allocatedMostRecentCase, "#Component4675953_divDataArea  #gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(3) > nobr > a"
  element :unallocatedMostRecentCaseTitle, "#UnallocatedSchedulingCases_divDataArea tr:nth-child(1) > td:nth-child(2) a"

  def click_add_case
    wait_for_addCaseButton(10)
    addCaseButton.click
  end

  def sort_by_created_on_under_allocated_scheduling_cases
    wait_for_createdOnForAllocatedSchedulingCases(10)
    createdOnForAllocatedSchedulingCases.click
  end

  def open_most_recent_allocated_case
    wait_for_allocatedMostRecentCase(10)
    allocatedMostRecentCase.click
  end

  def click_parent_div
    divContainingIframe.click
  end

  def click_search_records_input
    searchRecordsInput.click
  end

  def getNameOfAllocatedMostRecentCase
    allocatedMostRecentCase.text
  end

  def verify_imported_data(title)
    wait_for_allocatedMostRecentCase(10)
      return getNameOfAllocatedMostRecentCase.include? title
  end

  def find_case_working_on(currentCase)
    myCasesSearchTextbox.set(currentCase)
  end

  def click_case_working_on
    auditCase.click
    wait_for_ajax
  end

  def search_unallocated_cases(criteria)
    unallocatedCasesSearchTextbox.set criteria
    page.driver.browser.action.send_keys(:return).perform
    wait_for_ajax
    wait_for_unallocatedMostRecentCaseTitle(10)
    unallocatedMostRecentCaseTitle.click
    wait_for_ajax
  end

  def accept_alert
    if  page.current_url.include?"SYSTEST"
    wait = Selenium::WebDriver::Wait.new ignore: Selenium::WebDriver::Error::NoAlertPresentError
    alert = wait.until { page.driver.browser.switch_to.alert }
    alert.accept
    end
  end

end

 class HomeIframe < SitePrism::Page
   iframe :homeIframe, Home, "#contentIFrame0"
 end

 class DashboardIframe < SitePrism::Page
   iframe :dashboardIframe, Home, "#dashboardFrame"
 end
