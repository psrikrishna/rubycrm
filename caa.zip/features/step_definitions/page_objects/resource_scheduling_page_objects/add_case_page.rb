class AddCase < SitePrism::Page

  #Identify stage elements:

  #Case Title
  element :caseTitleLabel, '#title_c'
  element :caseTitle, '#title_i'

  #Customer ID
  element :customerIDLabel, '#customerid_c'
  element :customerID, '#customerid_ledit'

  #Case Type
  element :caseTypeLabel, 'casetypecode_c'
  element :caseType, '#casetypecode_i'

  #Case Category
  element :caseCategoryLabel, '#caa_casecategory_c'
  element :caseCategory, '#caa_casecategory_i'

  #Case SubCategory
  element :subCategoryLabel, '#new_subcategory_c'
  element :subCategory, '#new_subcategory_i'

  #QPulse Reference
  element :qPulseRefLabel, '#caaci_qpulseref_c'
  element :qPulseRef, '#caaci_qpulseref_i'

#Approval number
  element :approvalNumberLabel, '#caaci_approvalnumber_c'
  element :approvalNumber, '#caaci_approvalnumber_i'

  #Link Case
  element :parentCaseDiv, "#parentcaseid_c > span > span"
  element :parentCaseInput, "#parentcaseid_ledit"

  #Assign Stage elements:
  element :caseNameFromDropdownUnderAssign, "#entity0"

  #Information stage elements:
  element :informationStageTitle, '#stage_2>div.processStageTailContainer>div>div>div>span'

  element :customerContactNameLabel,  "td[id*='caaci_meetingorganisedthroughnametextdesc'] > span > span"
  element :customerContactName, "input[id*='caaci_meetingorganisedthroughnametextdesc'] "

  element :customerSalutationLabel, 'td[id*="caaci_meetingorganisedthroughsalutationtextdesc"] > span > span'
  element :customerSalutation, 'input[id*="caaci_meetingorganisedthroughsalutationtextdesc"]'
  element :orgEmailLabel, 'td[id*="caaci_meetingorganisedthroughemail"] > span > span'
  element :orgEmail, 'input[id*="caaci_meetingorganisedthroughemail"]'
  element :orgPhoneLabel, 'td[id*="caaci_meetingorganisedthroughphone"] > span > span'
  element :orgPhone, 'input[id*="caaci_meetingorganisedthroughphone"]'

  element :aircraftTypeLabel, 'td[id*="caaci_aircrafttypetextdesc"] > span > span'
  element :aircraftType, 'input[id*="caaci_aircrafttypetextdesc"]'

  element :registrationNumberLabel, '#caaci_registrationsoftheavailableaircraft1_c > span > span'
  element :registrationNumber, '#caaci_registrationsoftheavailableaircraft1_i'
  element :locationLabel, 'td[id*="caaci_location"] > span > span'
  element :locationInput, 'input[id*="caaci_location"]'
  element :gaOrAWDTaskLabel, '#caaci_gaorawdtask_c > span > span'
  element :gaOrAWDTask, '#caaci_gaorawdtask_i'

  element :surveyorIDLabel, 'td[id*="caaci_surveyorid"] > span > span'
  element :surveyorID, 'input[id*="caaci_surveyorid"]'
  element :surveyorSearch, 'img[id*="caaci_surveyorid"]' #search button

  # element :surveyorIDLabel, '#caaci_surveyorid2_c > span > span'
  # element :surveyorID, '#caaci_surveyorid2_ledit'

  element :possibleDatesLabel, 'td[id*="caaci_possibledates"] > span > span'
  element :possibleDates, 'input[id*="caaci_possibledates"]'
  element :agreedStartDateLabel, 'td[id*="caaci_agreedstartdate"] > span > span'
  element :agreedStartDate, 'table[id*="caaci_agreedstartdate"] input'
  element :agreedEndDateLabel, 'td[id*="caaci_agreedenddate"] > span > span'
  element :agreedEndDate, 'table[id*="caaci_agreedenddate"] input'

  element :caaPersonalRef, 'input[id*="caaci_caapersonalref_i"]'
  element :caaPersonalRefLabel, 'td[id*="caaci_caapersonalref_c"] > span > span'

  element :jobNumber, '#caaci_jobnumber_i'
  element :jobNumberLabel, 'td[id*="caaci_jobnumber_c"] > span > span'

  element :locationInfoStage, 'input[id*="caaci_location"]'
  element :locationLabelInfoStage, 'td[id*="caaci_location"] > span > span'

  element :inspectionType, "select[id*='caaci_fotiinspectiontype']"
  element :inspectionTypeLabel, "td[id*='caaci_fotiinspectiontype'] > span > span"

  element :requestedDate, '#caaci_requesteddate_i #DateInput'
  element :requestedDateLabel, 'td[id*="caaci_requesteddate_c"] > span > span'

  element :inspector, '#caaci_surveyorid4_ledit'
  element :inspectorLabel, '#caaci_surveyorid4_c>span>span'

  #common elements
  element :assignLink, 'img[alt="Assign"]'
  element :iFrameAssignButton, "#butBegin"
  element :saveIcon, "#savefooter_statuscontrol"
  element :navigateFirstStage, "#stageAdvanceActionContainer > div"
  element :navigateNextStage, "#stageNavigateActionContainer > div"
  element :activityLink, :xpath, "//*[@id='incident|NoRelationship|Form|caaci.incident.ButtonFlyoutActivities.Button']/span/a"
  element :addServiceActivity, "li[title*='Add a New Service Activity'] a"
  element :openSchedulingChecklist, :xpath, '//*[@id="incident|NoRelationship|Form|caaci.incident.ButtonOpenSCL.Button"]/span/a'

  #validation elements:
  #Identify stage validations after clicking Save:
  element :headerTitleIdentifyStage, '#header_process_title>div>span'
  element :headerCustomerIdentifyStage, '#header_process_customerid>div>span'
  element :headerCategoryIdentifyStage, '#header_process_caa_casecategory>div>span'
  element :headerSubCategoryIdentifyStage, '#header_process_new_subcategory>div>span'

  #Assign stage validations (from Identify stage):
  element :assignStageTitle, '#stage_1>div.processStageTailContainer>div>div>div>span'
  element :titleAssignStage, '#title>div>span'
  element :caseTypeCodeAssignStage, '#casetypecode>div>span'
  element :customerAssignStage, '#customerid>div>span'
  element :categoryAssignStage, '#caa_casecategory>div>span'
  element :subCategoryAssignStage, '#new_subcategory>div>span'
  element :qPulseRefAssignStage, '#caaci_qpulseref>div>span'
  element :allocatedByAssignStage, '#FiveDaySLAStatusTimer>div>span:nth-child(2)' #-should eq Succeeded

  #Information stage validations after clicking save:
  element :headerSurveyorNameInfoStage, '#header_process_caaci_surveyorid > div.ms-crm-Inline-Value.ms-crm-Inline-Lookup > span.ms-crm-Lookup-Item'

  #Complete stage validations:
  element :completeStageTitle, '#stage_3>div.processStageTailContainer>div>div>div>span'

  element :statusReasonCompleteStage, '#header_process_statuscode1>div>span'
  element :cancelledStatusReason, '#header_statuscode > div.ms-crm-Inline-Value.ms-crm-HeaderTile > span'
  element :unassignedStatusReason, '#header_statuscode > div.ms-crm-Inline-Value.ms-crm-HeaderTile > span'
  element :statusCompleteStage, '#header_process_statecode>div>span'
  element :titleCompleteStage, '#title>div>span'
  element :caseTypeCodeCompleteStage, '#casetypecode>div>span'

  element :customerCompleteStage, '#customerid>div>span'
  element :subcategoryCompleteStage, '#new_subcategory>div>span'
  element :qPulseRefCompleteStage, '#caaci_qpulseref>div>span'
  element :allocatedByCompleteStage, '#FiveDaySLAStatusTimer>div>span:nth-child(2)' #-should eq Succeeded
  element :statusReason, '#header_process_statuscode1 > div.ms-crm-Inline-Value'

  element :preRescheduleServiceThumbnail, "#tdAreas .post[title*='Test'] img[title='Service Activity']"
  element :postReschedualServiceThumbnail, "#tdAreas .post[title*='Test'] img[title='Service Activity']"

  element :outGoingEmail, '#tdAreas div[statecode = "Open"] > div > div > div > a > img'
  element :validateOutGoingEmail, ' #tdAreas div[statecode = "Open"] > div > div > div > a > img'

  element :prepActivity, '#tdAreas div[title*="Prep:"]'
  element :postActivity,  '#tdAreas div[title*="Post:"]'

  element :childCaseSubgrid, 'table[name="general_section_childcases"]'
  # element :serviceActivity, "#tdAreas div[title*='ACAM']"
  # element :outGoingEmail, " #tdAreas div[title='Survey Confirmation']"

# Email elements
  element :toRecipientLabel, "#to_c"
  element :toRecipientSpan, '#to > div > span:nth-child(1)'
  element :ccDiv, "td > #cc"
  element :ccInnerDiv, "#cc > div > div"
  element :ccFirstEmail, '#cc_lookupDiv > ul > li:nth-child(1) > span > span:nth-child(1) > span'
  element :ccInput, "#cc_ledit_multi"
  element :lastCCEmailSlot, "#cc_lookupDiv > ul > li:nth-last-child(1)"
  element :ccRecipient, "#cc_lookupDiv > ul > li:nth-child(3) > span > span:nth-child(1) > span"
  element :emailStatusReason, "#header_statecode > div > span"
  element :sendEmail, :xpath, '//*[@id="email|NoRelationship|Form|Mscrm.Form.email.Send"]/span/a'
  element :emailBodyDiv, "td > #description_d"
  element :emailBodyText, "p:nth-child(2) > span "

# Unannounced Elements
  element :auditTable, 'table[name="tab_AuditDetails_section_Intermediate"]'
  element :qPulseStatusLabel, "#caaci_qpulseapprovalstatus_c > span > span"
  element :qPulseStatusDropdown, "#caaci_qpulseapprovalstatus_i"

  element :dueDateLabel, "#caaci_auditduedate_c > span > span"
  element :dueDateInput, "#caaci_auditduedate_i > tr > td > input"

  element :qPulseStartDateLabel, "#caaci_currentqpulsestartdate_c > span > span"
  element :qPulseStartDateInput, "#caaci_currentqpulsestartdate_i > tr  > td > input"

  element :qPulseEndDateLabel, "#caaci_currentqpulseenddate_c > span > span"
  element :qPulseEndDateInput, "#caaci_currentqpulseenddate_i > tr > td > input"

  element :auditDurationLabel, "#caaci_auditdurationdays_c > span > span"
  element :auditDurationInput, "#caaci_auditdurationdays_i"

  element :assignToSelf, "span[command*='AssignPrimaryRecord']"

  element :okButton, "#butBegin"

# ----------------- Common Functions ---------------------


  def click_save_icon
    wait_until_saveIcon_visible(10)
    saveIcon.click
  end

  def getAssignStageTitle
    wait_for_assignStageTitle(10)
    wait_for_ajax
    assignStageTitle.text
  end

  def getInformationStageTitle
    wait_for_informationStageTitle(10)
    wait_for_ajax
    informationStageTitle.text
  end

  def navigate_to_complete_stage
    wait_for_completeStageTitle(10)
    completeStageTitle.click
  end

  def click_navigate_next_stage
    navigateNextStage.click
  end

  def open_scheduling_checklist
    openSchedulingChecklist.click
  end

  def check_random_string

    if $random_string == nil
      $random_string = ""
    end
    if $looped == nil
      $looped = 0
    end
    if $looped >= 1
      $random_string = ""
    end
  end

# ----------------- Identify Stage Functions -------------------

  def complete_required_fields_in_identify_stage(title, customer_ID, case_type, case_category, sub_category, reference, approval_number)

    wait_for_caseTitleLabel(10)
    caseTitleLabel.click
    wait_for_caseTitle(10)
    caseTitle.set title

    wait_for_customerIDLabel(10)
    customerIDLabel.click
    wait_for_customerID(10)
    customerID.set customer_ID

    wait_for_caseCategoryLabel(10)
    caseCategoryLabel.click
    wait_for_caseCategory(10)
    caseCategory.select(case_category)

    wait_for_subCategoryLabel(10)
    subCategoryLabel.click
    wait_for_subCategory(10)
    subCategory.select(sub_category)

    wait_for_approvalNumberLabel(10)
    approvalNumberLabel.click
    approvalNumber.set approval_number

    wait_for_qPulseRefLabel(10)
    qPulseRefLabel.click
    wait_for_qPulseRef(10)
    qPulseRef.set reference

  end

  def add_unique_title_identifier(identifier)
    wait_for_caseTitleLabel(10)
    caseTitleLabel.click
    wait_for_caseTitle(10)
    caseTitle.set identifier
  end

#For Identify Stage Validations
  def getHeaderTitleIdentifyStage
    wait_for_headerTitleIdentifyStage(10)
    headerTitleIdentifyStage.text
  end

  def getHeaderCustomerIdentifyStage
    wait_for_headerCustomerIdentifyStage(10)
    headerCustomerIdentifyStage.text
  end

  def getHeaderCategoryIdentifyStage
    wait_for_headerCategoryIdentifyStage(10)
    headerCategoryIdentifyStage.text
  end

  def getHeaderSubCategoryIdentifyStage
    wait_for_headerSubCategoryIdentifyStage(10)
    headerSubCategoryIdentifyStage.text
  end

  def input_parent_case(identifier)
    wait_for_parentCaseDiv(10)
    parentCaseDiv.click
    wait_for_parentCaseInput(10)
    parentCaseInput.set identifier
  end


# -------------- Assign Stage Functions --------------------

  def complete_required_fields_in_assign_stage
    click_navigate_next_stage
    wait_for_caseNameFromDropdownUnderAssign(10)
    caseNameFromDropdownUnderAssign.click
  end

#For Asign stage validations

  def getTitleAssignStage
   wait_for_titleAssignStage(10)
   titleAssignStage.text
  end

  def getCustomerAssignStage
    wait_for_customerAssignStage(10)
    customerAssignStage.text
  end

  def getCategoryAssignStage
    wait_for_categoryAssignStage(10)
    categoryAssignStage.text
  end

  def getSubCategoryAssignStage
    wait_for_subCategoryAssignStage(10)
    subCategoryAssignStage.text
  end

# ---------------- Information Stage Functions -------------------------

def verify_empty_values_for_start_date

  wait_for_agreedStartDateLabel(10)
  agreedStartDateLabel.click
  wait_for_agreedStartDate(10)
  agreedStartDate.value.empty?

end

def verify_empty_values_for_end_date

  wait_for_agreedEndDateLabel(10)
  agreedEndDateLabel.click
  wait_for_agreedEndDate(10)
  agreedEndDate.text.empty?

end

def complete_start_and_end_dates(agreed_start_date, agreed_end_date)

  wait_for_agreedStartDateLabel(10)
  agreedStartDateLabel.click
  wait_for_agreedStartDate(10)
  agreedStartDate.set agreed_start_date

  wait_for_agreedEndDateLabel(10)
  agreedEndDateLabel.click
  wait_for_agreedEndDate(10)
  agreedEndDate.set agreed_end_date

  click_save_icon

end


def complete_required_fields_in_information_stage_for_foti(customer_name, salutation, email, phone,
    caa_ref, job_number, loc, inspection_type, req_date, inspect, aircarft_type,
     agreed_start_date, agreed_end_date)

     wait_for_ajax

     wait_for_customerContactNameLabel(10)
     customerContactNameLabel.click

     wait_for_customerContactName(10)
     customerContactName.set customer_name

     wait_for_customerSalutationLabel(10)
     customerSalutationLabel.click

     wait_for_customerSalutation(10)
     customerSalutation.set salutation

     wait_for_orgEmailLabel(10)
     orgEmailLabel.click

     wait_for_orgEmail(10)
     orgEmail.set email

     wait_for_orgPhoneLabel(10)
     orgPhoneLabel.click
     wait_for_orgPhone(10)
     orgPhone.set phone

     caaPersonalRefLabel.click
     caaPersonalRef.set caa_ref

     jobNumberLabel.click
     jobNumber.set job_number

     locationLabelInfoStage.click
     locationInfoStage.set loc

     inspectionTypeLabel.click
     inspectionType.select inspection_type

     aircraftTypeLabel.click
     aircraftType.set aircarft_type

     requestedDateLabel.click
     requestedDate.set req_date

     wait_for_inspectorLabel(10)
     inspectorLabel.click
     wait_for_ajax
     wait_for_inspector(10)
     inspector.set inspect

     wait_for_agreedStartDateLabel(10)
     agreedStartDateLabel.click
     wait_for_agreedStartDate(10)
     agreedStartDate.set agreed_start_date

     wait_for_agreedEndDateLabel(10)
     agreedEndDateLabel.click
     wait_for_agreedEndDate(10)
     agreedEndDate.set agreed_end_date

     click_save_icon

   end


  def complete_required_fields_in_information_stage(customer_name, salutation, email, phone,
    type,registration, place, task, surveyor_id, possible_dates, agreed_start_date, agreed_end_date)

    wait_for_ajax

    wait_for_customerContactNameLabel(10)
    customerContactNameLabel.click

    wait_for_customerContactName(10)
    customerContactName.set customer_name

    wait_for_customerSalutationLabel(10)
    customerSalutationLabel.click

    wait_for_customerSalutation(10)
    customerSalutation.set salutation

    wait_for_orgEmailLabel(10)
    orgEmailLabel.click

    wait_for_orgEmail(10)
    orgEmail.set email

    wait_for_orgPhoneLabel(10)
    orgPhoneLabel.click
    wait_for_orgPhone(10)
    orgPhone.set phone

    wait_for_aircraftTypeLabel(10)
    aircraftTypeLabel.click
    wait_for_aircraftType(10)
    aircraftType.set type

    wait_for_registrationNumberLabel(10)
    registrationNumberLabel.click
    wait_for_registrationNumber(10)
    registrationNumber.set registration

    wait_for_locationLabel(10)
    locationLabel.click
    wait_for_locationInput(10)
    locationInput.set place

    wait_for_gaOrAWDTaskLabel(10)
    gaOrAWDTaskLabel.click
    wait_for_gaOrAWDTask(10)
    gaOrAWDTask.select(task)

    wait_for_surveyorIDLabel(10)
    surveyorIDLabel.click
    wait_for_surveyorID(10)
    surveyorID.set surveyor_id

    wait_for_possibleDatesLabel(10)
    possibleDatesLabel.click
    wait_for_possibleDates(10)
    possibleDates.set possible_dates

    wait_for_agreedStartDateLabel(10)
    agreedStartDateLabel.click
    wait_for_agreedStartDate(10)
    agreedStartDate.set agreed_start_date

    wait_for_agreedEndDateLabel(10)
    agreedEndDateLabel.click
    wait_for_agreedEndDate(10)
    agreedEndDate.set agreed_end_date

    click_save_icon

  end

  def modify_start_and_end_date(modifiedStartDate, modifiedEndDate)
    wait_for_ajax
    wait_for_agreedStartDateLabel(10)
    agreedStartDateLabel.click
    agreedStartDate.set modifiedStartDate

    wait_for_agreedEndDateLabel(10)
    agreedEndDateLabel.click
    agreedEndDate.set modifiedEndDate
    click_save_icon
  end

  def click_information_stage
    informationStageTitle.click
  end

# -------------- Complete Stage Functions ----------------------

  def add_service_activity
    wait_for_activityLink(10)
    activityLink.click
    wait_for_ajax
  end

  def click_navigate_first_stage
    navigateFirstStage.click
  end

  def getHeaderSurveyorName
    wait_for_headerSurveyorNameInfoStage(10)
    headerSurveyorNameInfoStage.text
  end

  def get_case_status
    wait_for_ajax
    wait_for_statusCompleteStage(10)
    statusCompleteStage.text
  end

  def get_case_status_reason
    wait_for_statusReasonCompleteStage(10)
    statusReasonCompleteStage.text
  end

  def is_prep_activity_displayed
    prepActivity.to be_displayed
  end

  def is_post_activity_displayed
    postActivity.to be_displayed
  end

  def open_pre_scheduled_service_activity
      wait_for_ajax
    wait_for_preRescheduleServiceThumbnail(10)
    preRescheduleServiceThumbnail.click
      wait_for_ajax
  end

  def open_after_rechedule_service_activity
    wait_for_ajax
    wait_for_postReschedualServiceThumbnail(10)
    postReschedualServiceThumbnail.click
    wait_for_ajax
  end

  def getUnassignedStatusReason
    wait_for_ajax
    wait_for_unassignedStatusReason(10)
    unassignedStatusReason.text
  end

  def click_assign_case_to_self
      wait_for_ajax
      assignToSelf.click
      wait_for_ajax

  end

  def accept_assign_to_self
    wait_for_ajax
    wait_for_okButton(10)
      okButton.click
  end



#--------------------------- Email Functions------------------------------

  def open_confirmation_email
    sleep 2
    outGoingEmail.click
  end

  def toRecipientText
    toRecipientSpan.text
  end

  def firstCCRecipientText
    wait_for_ccDiv(10)
    ccDiv.click
    wait_for_lastCCEmailSlot(10)
    lastCCEmailSlot.click
    ccFirstEmail.text
  end

  def add_email_to_cc(email)
    wait_for_ajax
    wait_for_ccDiv(10)

    ccDiv.click
    ccDiv.click

    wait_for_lastCCEmailSlot(10)
    lastCCEmailSlot.click

    wait_for_ccInput(10)
    ccInput.click
    ccInput.set email
    wait_for_ajax
  end

  def add_text_to_body(text)
    wait_for_emailBodyText(10)
    emailBodyText.click
    emailBodyText.set(text)
  end

  def send_email
    wait_for_sendEmail(10)
    sendEmail.click
  end

  def reformat_date_for_email_validation(date)
    date.gsub! "/" ,","
    split_date = date.split(",")
    year = split_date[2].to_i
    month = split_date[1].to_i
    day = split_date[0].to_i
    date = Date.new(year, month, day)
    date.stamp("Wednesday 12th December 2018")
  end


# ------------------------- Unannounced Audit Scenario Functions -------------------------

  def complete_required_fields_in_unannounced_information_stage(qPulseStatus, customer_name, salutation, email, phone, surveyor_id, dueDate, startDate, endDate, duration, place, possible_dates, agreed_start_date, agreed_end_date)

    wait_for_qPulseStatusLabel(10)
    qPulseStatusLabel.click
    qPulseStatusLabel.click
    wait_for_qPulseStatusDropdown(10)
    qPulseStatusDropdown.select(qPulseStatus)

    wait_for_customerContactNameLabel(10)
    customerContactNameLabel.click

    wait_for_customerContactName(10)
    customerContactName.set customer_name

    wait_for_customerSalutationLabel(10)
    customerSalutationLabel.click

    wait_for_customerSalutation(10)
    customerSalutation.set salutation

    wait_for_orgEmailLabel(10)
    orgEmailLabel.click

    wait_for_orgEmail(10)
    orgEmail.set email

    wait_for_orgPhoneLabel(10)
    orgPhoneLabel.click
    wait_for_orgPhone(10)
    orgPhone.set phone

    wait_for_surveyorIDLabel(10)
    surveyorIDLabel.click
    wait_for_surveyorID(10)
    surveyorID.set surveyor_id

    wait_for_dueDateLabel(10)
    dueDateLabel.click
    dueDateInput.set dueDate

    wait_for_qPulseStartDateLabel(10)
    qPulseStartDateLabel.click
    qPulseStartDateInput.set startDate

    wait_for_qPulseEndDateLabel(10)
    qPulseEndDateLabel.click
    qPulseEndDateInput.set endDate

    wait_for_auditDurationLabel(10)
    auditDurationLabel.click
    auditDurationInput.set(duration)

    wait_for_locationLabel(10)
    locationLabel.click
    wait_for_locationInput(10)
    locationInput.set place

    wait_for_possibleDatesLabel(10)
    possibleDatesLabel.click
    wait_for_possibleDates(10)
    possibleDates.set possible_dates

    wait_for_agreedStartDateLabel(10)
    agreedStartDateLabel.click
    wait_for_agreedStartDate(10)
    agreedStartDate.set agreed_start_date

    wait_for_agreedEndDateLabel(10)
    agreedEndDateLabel.click
    wait_for_agreedEndDate(10)
    agreedEndDate.set agreed_end_date

    click_save_icon

  end

  def assignCaseToMe
    wait_for_assignLink(10)
    assignLink.click
  end

  def clickAssignButton
    wait_for_iFrameAssignButton(10)
    iFrameAssignButton.click
  end

  def fillInDates(dueDate, agreed_start_date, agreed_end_date)
    wait_for_ajax
    wait_for_dueDateLabel(10)
    dueDateLabel.click
    wait_for_ajax
    wait_for_dueDateInput(10)
    dueDateInput.set dueDate

    wait_for_agreedStartDateLabel(10)
    agreedStartDateLabel.click
    wait_for_agreedStartDate(10)
    agreedStartDate.set agreed_start_date

    wait_for_agreedEndDateLabel(10)
    agreedEndDateLabel.click
    wait_for_agreedEndDate(10)
    agreedEndDate.set agreed_end_date

    click_save_icon
  end

  def checkIndividualOrOrganisation(individualOrOrg)

    if individualOrOrg == "{Individual}"
          $global_data["Customer ID"]=$ind_first_name+' '+$ind_surname
    else
          $global_data["Customer ID"]=individualOrOrg
    end
  end

end


class AddCaseIFrame < SitePrism::Page
  iframe :addCaseIFrame, AddCase, '#contentIFrame0'
end

class AddCaseInlineDialogIFrame < SitePrism::Page
  iframe :addCaseInlineDialogIFrame, AddCase, '#InlineDialog_Iframe'
end

class EmailIFrame < SitePrism::Page
  iframe :emailIFrame, AddCase, "#contentIFrame0"
end

class EmailBodyIFrame < SitePrism::Page
  iframe :emailBodyIFrame, AddCase, "descriptionIFrame"
end
