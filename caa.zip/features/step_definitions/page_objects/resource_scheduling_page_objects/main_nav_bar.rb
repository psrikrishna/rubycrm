class MainNavBar < SitePrism::Page

  element :home, "#TabHome a"
  element :workplace, "#TabWorkplace .navTabButtonLink"
  element :import_submenu, "#nav_import"

  element :dynamicsCrmLink, "#Tab1 > a"
  element :dropdownWorkplace, '#Workplace'

  element :import_data_tab, 'li[title*="Import Data"]>span'
  element :cmdbar, ".ms-crm-CommandBar-Menu:nth-child(1)"

  element :moveRight, "#rightNavLink"
  element :individuals, "a[id='nav_conts'][title='Individuals']"

  element :entityNavTab, "#TabNode_tab0Tab"
  element :entityDocuments, "#Node_navDocument"

    element :articles, "a[id='nav_answers'][title='Articles']"

  def access_import_data_tab
    wait_for_workplace(10)
    workplace.click
    wait_until_import_submenu_visible(10)
    import_submenu.click

    wait_for_import_data_tab(10)
    page.driver.browser.action.move_to(import_data_tab.native).click.perform
    import_data_tab.click

  end

  def access_articles_tab
    wait_for_workplace(10)
    workplace.click
    wait_until_articles_visible(10)
    articles.click
sleep 10
  end

  def access_individual_tab
    wait_for_workplace(10)
    workplace.click
    wait_for_ajax
    wait_for_moveRight(10)
    moveRight.click
    wait_for_ajax
    wait_for_individuals(10)
    individuals.click
    wait_for_ajax
  end

  def access_home
      wait_for_home(10)
      home.click
      wait_for_ajax
  end

  def access_workplace_homepage
    wait_for_ajax
    dynamicsCrmLink.click
    dropdownWorkplace.click
    wait_for_ajax
  end

  def accessEntityDocuments
    wait_for_entityNavTab(10)
    entityNavTab.click

    wait_for_entityDocuments(10)
    entityDocuments.click
  end

end
