class ImportFile < SitePrism::Page

	element :uploadFileName, '#uploadFileNameId'
	element :nextButton, '#wizardFormFooter #buttonNext'
	element :submitButton, '#wizardFormFooter #buttonNext'
	element :finishButton, 'button[accesskey="F"]'
	element :cancelButton, 'button[title*="Cancel the wizard."]'
	element :dataMap, '#crmDataSource > optgroup:nth-child(4) > option:nth-child(9)'
	element :mapRecordTypes, '#file_1 option[value="caaci_qpulseaudit"]'

	#verify map fields
	element :approvalStatus, "#_Attribute_11 option[value='caaci_qpulseapprovalstatus'][selected='selected']"
	element :audType, "#_Attribute_5 option[value='3-Ignore'][selected='selected']"
	element :auditNote, "#_Attribute_6 option[value='caaci_summary'][selected='selected']"
	element :auditStatus, "#_Attribute_4 option[value='caaci_auditstatus'][selected='selected']"
	element :crmCategory, "#_Attribute_2 option[value='caaci_audtypeshort'][selected='selected']"
	element :crmSubCategory, "#_Attribute_1 option[value='new_qsubcategory'][selected='selected']"
	element :leadAuditor, "#_Attribute_7 option[value='caaci_leadauditor'][selected='selected']"
	element :number, "#_Attribute_8 option[value='caaci_number'][selected='selected']"
	element :organisationName, "#_Attribute_10 option[value='caaci_organisationname'][selected='selected']"
	element :referenceNumber, "#_Attribute_13 option[value='caaci_referencenumber'][selected='selected']"
	element :scheduledStartDate, "#_Attribute_12 option[value='caaci_scheduledstartdate'][selected='selected']"
	element :scheduledEndDate, "#_Attribute_3 option[value='new_schedulingenddate'][selected='selected']"
	element :schedulingOfficer, "#_Attribute_9 option[value='caaci_schedullingofficer'][selected='selected']"
	element :infoBalloonText, "#infoBalloonText1"
	element :loadingIcon, "#DialogLoadingDiv"
	element :importLink, "#showImportStatusLink"


element :statusOnMyImports, "#gridBodyTable > tbody > tr:nth-child(1) > td:nth-child(3)"
element :refreshGrid, "#grid_refresh"

def checkPageLoadComplete
	wait_until_loadingIcon_invisible(10)
end
	def select_a_file
		wait_for_uploadFileName(10)
		attach_file('uploadFileNameId', File.absolute_path('./Files/RS Phase 3 Data Migration Test.csv'))
		wait_for_ajax
	end

	def click_next_button
		wait_for_nextButton(10)
		nextButton.click
		wait_for_ajax
	end

	def click_cancel_button
		wait_for_cancelButton(10)
		cancelButton.click
		wait_for_ajax
	end

	def click_submit_button
		wait_for_submitButton(10)
		submitButton.click
		wait_for_ajax
	end


	def select_monthly_q_pulse_audits
		wait_for_dataMap(10)
		dataMap.click
		wait_for_ajax
	end

	def select_record_types_as_q_pulse_audit
		wait_for_mapRecordTypes(10)
		mapRecordTypes.click
		wait_for_ajax
	end




def verifyApprovalStatusMapping
	sleep 3
	wait_for_ajax
	wait_for_approvalStatus(10)
		approvalStatus['title']
end

def verifyAuditTypeMapping
		audType['title']
end

def verifyAuditNoteMapping
		auditNote['title']
end

def verifyAuditStatus
	 auditStatus['title']
end

def verifyCrmCategory
	crmCategory['title']
end

def verifyCrmSubCategory
	crmSubCategory['title']
end

def verifyLeadAuditor
	leadAuditor['title']
end

def verifyNumber
	number['title']
end

def verifyOrganisationName
	organisationName['title']
end

def verifyReferenceNumber
	referenceNumber['title']
end

def verifyScheduledStartDate
	scheduledStartDate['title']
end

def verifyScheduledEndDate
scheduledEndDate['title']
end

def verifySchedulingOfficer
	schedulingOfficer['title']
end

def verifyStatusOfImport
	statusOnMyImports.text
end

def getInfoBallooonText
	wait_for_ajax
	infoBalloonText.text
end


def refresh_grid_until_file_import_status_is_complete(status)
 time=0

			while time<360 do
				puts "Current status is -> "+verifyStatusOfImport
				 	 if verifyStatusOfImport==status
					 	return true
				 	 end
					 wait_for_refreshGrid(10)
					 refreshGrid.click

						wait_for_ajax
						time=time+10
			end
			return false
	end


end #of class

class ImportIFrame < SitePrism::Page
  iframe :importIFrame, ImportFile, '#contentIFrame0'
end

class DialogIFrame < SitePrism::Page
	iframe :dialogIFrame, ImportFile, "#InlineDialog_Iframe"
end


class WizardIFrame < SitePrism::Page
  iframe :wizardIFrame, ImportFile, '#wizardpageframe'
end

class UploadFileFrame < SitePrism::Page
  iframe :uploadFileFrame, ImportFile, '#uploadFileFrame'
end
