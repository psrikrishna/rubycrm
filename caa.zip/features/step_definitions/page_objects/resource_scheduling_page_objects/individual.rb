class Individual < SitePrism::Page

element :newContact, "span[command*='NewRecordFromGrid']"
element :fullNameLabel, "#fullname_c"

element :firstNameLabel, "#fullname_compositionLinkControl_firstname_c"
element :surNameLabel, "#fullname_compositionLinkControl_lastname_c"

element :firstName, "#fullname_compositionLinkControl_firstname_i"
element :surName, "#fullname_compositionLinkControl_lastname_i"

element :doneButton, "#fullname_compositionLinkControl_flyoutLoadingArea-confirm"

element :saveAndClose, "span[command*='SaveAndClosePrimary']"

element :search, "#crmGrid_findCriteria"

elements :searchResults, "a[id*='gridBodyTable_primaryField']"

element :enteredName, "#fullname > div.ms-crm-Inline-Value > span"

    def search_for_individual(firstname, surname)
        search.set firstname + ' ' + surname
        page.driver.browser.action.send_keys(:return).perform
        wait_for_ajax
        searchResults[0].click
        wait_for_ajax
    end



    def getEnterdName
        enteredName.text
    end


    def add_new_individual
        wait_for_ajax
        wait_for_newContact(10)
        newContact.click
        wait_for_ajax
    end

    def set_name(first_name, surname)
      wait_for_ajax
      fullNameLabel.click
      wait_for_ajax

      wait_for_firstName
      firstNameLabel.click
      firstName.set first_name
      surNameLabel.click
      surName.set surname

      doneButton.click

      wait_for_ajax


    end

    def click_save_and_close
        saveAndClose.click
    end

end

class IndividualIFrame < SitePrism::Page
  iframe :individualIFrame, Individual, '#contentIFrame1'
end

class IndividualSubContentIFrame < SitePrism::Page
  iframe :individualSubContentIFrame, Individual, '#contentIFrame0'
end
